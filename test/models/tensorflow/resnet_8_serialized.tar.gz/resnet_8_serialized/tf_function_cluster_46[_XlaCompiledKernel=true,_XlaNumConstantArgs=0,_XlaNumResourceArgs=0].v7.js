[
    {
        "name": "Function_13",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_806",
                "op": "Parameter",
                "outputs": [
                    "Parameter_806_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_805",
                "op": "Parameter",
                "outputs": [
                    "Parameter_805_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_807",
                "op": "Constant",
                "outputs": [
                    "Constant_807_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "inputs": [
                    "Parameter_805",
                    "Parameter_806"
                ],
                "name": "Divide_809",
                "op": "Divide",
                "outputs": [
                    "Divide_809_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_806",
                    "Constant_807"
                ],
                "name": "Greater_808",
                "op": "Greater",
                "outputs": [
                    "Greater_808_0"
                ]
            },
            {
                "inputs": [
                    "Greater_808",
                    "Divide_809",
                    "Constant_807"
                ],
                "name": "Select_810",
                "op": "Select",
                "outputs": [
                    "Select_810_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_805",
            "Parameter_806"
        ],
        "result": [
            "Select_810",
            "Select_810"
        ]
    }
]