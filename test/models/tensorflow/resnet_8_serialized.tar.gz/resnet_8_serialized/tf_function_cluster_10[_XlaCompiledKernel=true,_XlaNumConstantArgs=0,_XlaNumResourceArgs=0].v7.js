[
    {
        "name": "Function_26",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1440",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1440_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1439",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1439_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1438",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1438_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_1438"
                ],
                "name": "Broadcast_1441",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1441_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_1439",
                    "Broadcast_1441"
                ],
                "name": "Multiply_1442",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1442_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1442",
                    "Parameter_1440"
                ],
                "name": "Add_1443",
                "op": "Add",
                "outputs": [
                    "Add_1443_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1438",
            "Parameter_1439",
            "Parameter_1440"
        ],
        "result": [
            "Add_1443"
        ]
    }
]