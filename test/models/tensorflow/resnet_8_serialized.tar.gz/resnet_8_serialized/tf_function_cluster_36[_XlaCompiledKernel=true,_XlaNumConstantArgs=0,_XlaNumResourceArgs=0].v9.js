[
    {
        "name": "Function_6",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_279",
                "op": "Parameter",
                "outputs": [
                    "Parameter_279_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_278",
                "op": "Parameter",
                "outputs": [
                    "Parameter_278_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_283",
                "op": "Constant",
                "outputs": [
                    "Constant_283_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_280",
                "op": "Constant",
                "outputs": [
                    "Constant_280_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_279"
                ],
                "name": "Reshape_286",
                "op": "Reshape",
                "output_shape": [
                    64,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_286_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_280"
                ],
                "name": "Broadcast_281",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_281_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_281",
                    "Parameter_278"
                ],
                "name": "Maximum_282",
                "op": "Maximum",
                "outputs": [
                    "Maximum_282_0"
                ]
            },
            {
                "inputs": [
                    "Maximum_282",
                    "Constant_283"
                ],
                "name": "Pad_284",
                "op": "Pad",
                "outputs": [
                    "Pad_284_0"
                ],
                "padding_above": [
                    0,
                    1,
                    1,
                    0
                ],
                "padding_below": [
                    0,
                    1,
                    1,
                    0
                ],
                "padding_interior": [
                    0,
                    0,
                    0,
                    0
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Pad_284"
                ],
                "name": "Reshape_285",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    18,
                    18
                ],
                "outputs": [
                    "Reshape_285_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_285",
                    "Reshape_286"
                ],
                "name": "Convolution_287",
                "op": "Convolution",
                "outputs": [
                    "Convolution_287_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    2,
                    2
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_287"
                ],
                "name": "Reshape_288",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_288_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_278",
            "Parameter_279"
        ],
        "result": [
            "Reshape_288",
            "Maximum_282",
            "Pad_284"
        ]
    }
]