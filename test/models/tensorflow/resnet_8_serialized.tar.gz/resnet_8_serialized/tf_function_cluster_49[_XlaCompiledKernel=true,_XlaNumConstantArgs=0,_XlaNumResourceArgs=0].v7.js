[
    {
        "name": "Function_14",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_849",
                "op": "Parameter",
                "outputs": [
                    "Parameter_849_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_848",
                "op": "Parameter",
                "outputs": [
                    "Parameter_848_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_847",
                "op": "Parameter",
                "outputs": [
                    "Parameter_847_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_847"
                ],
                "name": "Broadcast_850",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_850_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_848",
                    "Broadcast_850"
                ],
                "name": "Multiply_851",
                "op": "Multiply",
                "outputs": [
                    "Multiply_851_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_851",
                    "Parameter_849"
                ],
                "name": "Add_852",
                "op": "Add",
                "outputs": [
                    "Add_852_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_847",
            "Parameter_848",
            "Parameter_849"
        ],
        "result": [
            "Add_852"
        ]
    }
]