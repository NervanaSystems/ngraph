[
    {
        "name": "Function_29",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1598",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1598_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1597",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1597_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1596",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1596_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_1596"
                ],
                "name": "Broadcast_1599",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1599_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_1597",
                    "Broadcast_1599"
                ],
                "name": "Multiply_1600",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1600_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1600",
                    "Parameter_1598"
                ],
                "name": "Add_1601",
                "op": "Add",
                "outputs": [
                    "Add_1601_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1596",
            "Parameter_1597",
            "Parameter_1598"
        ],
        "result": [
            "Add_1601"
        ]
    }
]