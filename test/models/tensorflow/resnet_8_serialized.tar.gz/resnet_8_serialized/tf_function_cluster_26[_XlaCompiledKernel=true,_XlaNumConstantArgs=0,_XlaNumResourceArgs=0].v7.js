[
    {
        "name": "Function_24",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1306",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1306_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1305",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1305_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1304",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1304_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_1304"
                ],
                "name": "Broadcast_1307",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1307_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_1305",
                    "Broadcast_1307"
                ],
                "name": "Multiply_1308",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1308_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1308",
                    "Parameter_1306"
                ],
                "name": "Add_1309",
                "op": "Add",
                "outputs": [
                    "Add_1309_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1304",
            "Parameter_1305",
            "Parameter_1306"
        ],
        "result": [
            "Add_1309"
        ]
    }
]