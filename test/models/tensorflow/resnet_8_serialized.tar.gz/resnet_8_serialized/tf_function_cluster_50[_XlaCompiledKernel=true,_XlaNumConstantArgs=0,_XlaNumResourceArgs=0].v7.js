[
    {
        "name": "Function_15",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_908",
                "op": "Parameter",
                "outputs": [
                    "Parameter_908_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_907",
                "op": "Parameter",
                "outputs": [
                    "Parameter_907_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_906",
                "op": "Parameter",
                "outputs": [
                    "Parameter_906_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_906"
                ],
                "name": "Broadcast_909",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_909_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_907",
                    "Broadcast_909"
                ],
                "name": "Multiply_910",
                "op": "Multiply",
                "outputs": [
                    "Multiply_910_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_910",
                    "Parameter_908"
                ],
                "name": "Add_911",
                "op": "Add",
                "outputs": [
                    "Add_911_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_906",
            "Parameter_907",
            "Parameter_908"
        ],
        "result": [
            "Add_911"
        ]
    }
]