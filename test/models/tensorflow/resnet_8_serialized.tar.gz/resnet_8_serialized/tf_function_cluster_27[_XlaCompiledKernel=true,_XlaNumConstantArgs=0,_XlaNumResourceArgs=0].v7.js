[
    {
        "name": "Function_21",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1150",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1150_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1149",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1149_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1148",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1148_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_1148"
                ],
                "name": "Broadcast_1151",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1151_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_1149",
                    "Broadcast_1151"
                ],
                "name": "Multiply_1152",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1152_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1152",
                    "Parameter_1150"
                ],
                "name": "Add_1153",
                "op": "Add",
                "outputs": [
                    "Add_1153_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1148",
            "Parameter_1149",
            "Parameter_1150"
        ],
        "result": [
            "Add_1153"
        ]
    }
]