[
    {
        "name": "Function_7",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_328",
                "op": "Parameter",
                "outputs": [
                    "Parameter_328_0"
                ],
                "shape": [
                    1,
                    1,
                    32,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_327",
                "op": "Parameter",
                "outputs": [
                    "Parameter_327_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_326",
                "op": "Parameter",
                "outputs": [
                    "Parameter_326_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_325",
                "op": "Parameter",
                "outputs": [
                    "Parameter_325_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_329",
                "op": "Constant",
                "outputs": [
                    "Constant_329_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_336",
                "op": "Constant",
                "outputs": [
                    "Constant_336_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_328"
                ],
                "name": "Reshape_339",
                "op": "Reshape",
                "output_shape": [
                    64,
                    32,
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_339_0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_326"
                ],
                "name": "Reshape_333",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_333_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_329"
                ],
                "name": "Broadcast_330",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_330_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_327",
                    "Constant_336"
                ],
                "name": "Pad_337",
                "op": "Pad",
                "outputs": [
                    "Pad_337_0"
                ],
                "padding_above": [
                    0,
                    0,
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0,
                    0,
                    0
                ],
                "padding_interior": [
                    0,
                    0,
                    0,
                    0
                ]
            },
            {
                "inputs": [
                    "Broadcast_330",
                    "Parameter_325"
                ],
                "name": "Maximum_331",
                "op": "Maximum",
                "outputs": [
                    "Maximum_331_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Pad_337"
                ],
                "name": "Reshape_338",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_338_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_331"
                ],
                "name": "Reshape_332",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_332_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_338",
                    "Reshape_339"
                ],
                "name": "Convolution_340",
                "op": "Convolution",
                "outputs": [
                    "Convolution_340_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    2,
                    2
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_332",
                    "Reshape_333"
                ],
                "name": "Convolution_334",
                "op": "Convolution",
                "outputs": [
                    "Convolution_334_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_340"
                ],
                "name": "Reshape_341",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_341_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_334"
                ],
                "name": "Reshape_335",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_335_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_335",
                    "Reshape_341"
                ],
                "name": "Add_342",
                "op": "Add",
                "outputs": [
                    "Add_342_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_325",
            "Parameter_326",
            "Parameter_327",
            "Parameter_328"
        ],
        "result": [
            "Add_342",
            "Pad_337",
            "Maximum_331",
            "Reshape_341",
            "Reshape_335"
        ]
    }
]