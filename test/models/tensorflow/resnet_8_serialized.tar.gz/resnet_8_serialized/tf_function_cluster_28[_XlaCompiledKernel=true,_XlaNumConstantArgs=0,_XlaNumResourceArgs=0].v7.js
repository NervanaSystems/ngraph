[
    {
        "name": "Function_17",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_994",
                "op": "Parameter",
                "outputs": [
                    "Parameter_994_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_993",
                "op": "Parameter",
                "outputs": [
                    "Parameter_993_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_992",
                "op": "Parameter",
                "outputs": [
                    "Parameter_992_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_992"
                ],
                "name": "Broadcast_995",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_995_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_993",
                    "Broadcast_995"
                ],
                "name": "Multiply_996",
                "op": "Multiply",
                "outputs": [
                    "Multiply_996_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_996",
                    "Parameter_994"
                ],
                "name": "Add_997",
                "op": "Add",
                "outputs": [
                    "Add_997_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_992",
            "Parameter_993",
            "Parameter_994"
        ],
        "result": [
            "Add_997"
        ]
    }
]