[
    {
        "name": "Function_23",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1299",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1299_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1298",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1298_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1297",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1297_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_1297"
                ],
                "name": "Broadcast_1300",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1300_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_1298",
                    "Broadcast_1300"
                ],
                "name": "Multiply_1301",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1301_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1301",
                    "Parameter_1299"
                ],
                "name": "Add_1302",
                "op": "Add",
                "outputs": [
                    "Add_1302_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1297",
            "Parameter_1298",
            "Parameter_1299"
        ],
        "result": [
            "Add_1302"
        ]
    }
]