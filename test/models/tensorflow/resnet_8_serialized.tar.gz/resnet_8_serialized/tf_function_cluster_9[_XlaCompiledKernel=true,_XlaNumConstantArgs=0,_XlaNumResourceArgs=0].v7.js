[
    {
        "name": "Function_28",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1556",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1556_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1555",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1555_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1554",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1554_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_1554"
                ],
                "name": "Broadcast_1557",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1557_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_1555",
                    "Broadcast_1557"
                ],
                "name": "Multiply_1558",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1558_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1558",
                    "Parameter_1556"
                ],
                "name": "Add_1559",
                "op": "Add",
                "outputs": [
                    "Add_1559_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1554",
            "Parameter_1555",
            "Parameter_1556"
        ],
        "result": [
            "Add_1559"
        ]
    }
]