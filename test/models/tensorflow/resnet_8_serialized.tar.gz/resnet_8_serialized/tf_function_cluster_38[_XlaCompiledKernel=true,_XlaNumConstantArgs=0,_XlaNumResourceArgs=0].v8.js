[
    {
        "name": "Function_2",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_82",
                "op": "Parameter",
                "outputs": [
                    "Parameter_82_0"
                ],
                "shape": [
                    1,
                    1,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_81",
                "op": "Parameter",
                "outputs": [
                    "Parameter_81_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_80",
                "op": "Parameter",
                "outputs": [
                    "Parameter_80_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_83",
                "op": "Constant",
                "outputs": [
                    "Constant_83_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_82"
                ],
                "name": "Reshape_91",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_91_0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_81"
                ],
                "name": "Reshape_87",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_87_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_83"
                ],
                "name": "Broadcast_84",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_84_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_84",
                    "Parameter_80"
                ],
                "name": "Maximum_85",
                "op": "Maximum",
                "outputs": [
                    "Maximum_85_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_85"
                ],
                "name": "Reshape_90",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_90_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_85"
                ],
                "name": "Reshape_86",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_86_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_90",
                    "Reshape_91"
                ],
                "name": "Convolution_92",
                "op": "Convolution",
                "outputs": [
                    "Convolution_92_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_86",
                    "Reshape_87"
                ],
                "name": "Convolution_88",
                "op": "Convolution",
                "outputs": [
                    "Convolution_88_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_92"
                ],
                "name": "Reshape_93",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_93_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_88"
                ],
                "name": "Reshape_89",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_89_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_80",
            "Parameter_81",
            "Parameter_82"
        ],
        "result": [
            "Reshape_89",
            "Reshape_93",
            "Maximum_85"
        ]
    }
]