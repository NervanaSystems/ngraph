[
    {
        "name": "Function_20",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1143",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1143_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1142",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1142_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1141",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1141_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_1141"
                ],
                "name": "Broadcast_1144",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1144_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_1142",
                    "Broadcast_1144"
                ],
                "name": "Multiply_1145",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1145_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1145",
                    "Parameter_1143"
                ],
                "name": "Add_1146",
                "op": "Add",
                "outputs": [
                    "Add_1146_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1141",
            "Parameter_1142",
            "Parameter_1143"
        ],
        "result": [
            "Add_1146"
        ]
    }
]