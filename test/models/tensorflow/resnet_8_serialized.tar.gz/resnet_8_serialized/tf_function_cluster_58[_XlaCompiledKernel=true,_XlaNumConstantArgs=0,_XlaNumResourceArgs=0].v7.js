[
    {
        "name": "Function_18",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1001",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1001_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1000",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1000_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_999",
                "op": "Parameter",
                "outputs": [
                    "Parameter_999_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_999"
                ],
                "name": "Broadcast_1002",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1002_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_1000",
                    "Broadcast_1002"
                ],
                "name": "Multiply_1003",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1003_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1003",
                    "Parameter_1001"
                ],
                "name": "Add_1004",
                "op": "Add",
                "outputs": [
                    "Add_1004_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_999",
            "Parameter_1000",
            "Parameter_1001"
        ],
        "result": [
            "Add_1004"
        ]
    }
]