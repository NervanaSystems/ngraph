[
    {
        "name": "Function_12",
        "ops": [
            {
                "element_type": "char",
                "inputs": [],
                "name": "Parameter_731",
                "op": "Parameter",
                "outputs": [
                    "Parameter_731_0"
                ],
                "shape": [
                    2
                ]
            },
            {
                "inputs": [
                    "Parameter_731"
                ],
                "name": "Convert_732",
                "op": "Convert",
                "outputs": [
                    "Convert_732_0"
                ],
                "target_type": "float"
            },
            {
                "inputs": [
                    "Convert_732"
                ],
                "name": "Sum_733",
                "op": "Sum",
                "outputs": [
                    "Sum_733_0"
                ],
                "reduction_axes": [
                    0
                ]
            }
        ],
        "parameters": [
            "Parameter_731"
        ],
        "result": [
            "Sum_733"
        ]
    }
]