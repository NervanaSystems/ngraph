[
    {
        "name": "Function_31",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1618",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1618_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1617",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1617_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1616",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1616_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_1616"
                ],
                "name": "Broadcast_1619",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1619_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_1617",
                    "Broadcast_1619"
                ],
                "name": "Multiply_1620",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1620_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1620",
                    "Parameter_1618"
                ],
                "name": "Add_1621",
                "op": "Add",
                "outputs": [
                    "Add_1621_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1616",
            "Parameter_1617",
            "Parameter_1618"
        ],
        "result": [
            "Add_1621"
        ]
    }
]