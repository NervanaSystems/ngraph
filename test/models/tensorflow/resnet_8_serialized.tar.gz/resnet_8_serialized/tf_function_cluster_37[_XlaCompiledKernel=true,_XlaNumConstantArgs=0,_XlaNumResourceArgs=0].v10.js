[
    {
        "name": "Function_5",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_229",
                "op": "Parameter",
                "outputs": [
                    "Parameter_229_0"
                ],
                "shape": [
                    1,
                    1,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_228",
                "op": "Parameter",
                "outputs": [
                    "Parameter_228_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_227",
                "op": "Parameter",
                "outputs": [
                    "Parameter_227_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_226",
                "op": "Parameter",
                "outputs": [
                    "Parameter_226_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_230",
                "op": "Constant",
                "outputs": [
                    "Constant_230_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_229"
                ],
                "name": "Reshape_238",
                "op": "Reshape",
                "output_shape": [
                    32,
                    16,
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_238_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_228"
                ],
                "name": "Reshape_237",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_237_0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_227"
                ],
                "name": "Reshape_234",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_234_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_230"
                ],
                "name": "Broadcast_231",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_231_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_237",
                    "Reshape_238"
                ],
                "name": "Convolution_239",
                "op": "Convolution",
                "outputs": [
                    "Convolution_239_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    2,
                    2
                ]
            },
            {
                "inputs": [
                    "Broadcast_231",
                    "Parameter_226"
                ],
                "name": "Maximum_232",
                "op": "Maximum",
                "outputs": [
                    "Maximum_232_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_239"
                ],
                "name": "Reshape_240",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_240_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_232"
                ],
                "name": "Reshape_233",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_233_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_233",
                    "Reshape_234"
                ],
                "name": "Convolution_235",
                "op": "Convolution",
                "outputs": [
                    "Convolution_235_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_235"
                ],
                "name": "Reshape_236",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_236_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_236",
                    "Reshape_240"
                ],
                "name": "Add_241",
                "op": "Add",
                "outputs": [
                    "Add_241_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_226",
            "Parameter_227",
            "Parameter_228",
            "Parameter_229"
        ],
        "result": [
            "Add_241",
            "Maximum_232",
            "Reshape_240",
            "Reshape_236"
        ]
    }
]