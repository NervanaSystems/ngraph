[
    {
        "name": "Function_30",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1606",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1606_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1605",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1605_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    3
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1604",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1604_0"
                ],
                "shape": [
                    3,
                    3,
                    3,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1603",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1603_0"
                ],
                "shape": []
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_1606"
                ],
                "name": "Reshape_1610",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_1610_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_1605"
                ],
                "name": "Reshape_1609",
                "op": "Reshape",
                "output_shape": [
                    3,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_1609_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_1603"
                ],
                "name": "Broadcast_1607",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1607_0"
                ],
                "shape": [
                    3,
                    3,
                    3,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1609",
                    "Reshape_1610"
                ],
                "name": "Convolution_1611",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1611_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "inputs": [
                    "Parameter_1604",
                    "Broadcast_1607"
                ],
                "name": "Multiply_1608",
                "op": "Multiply",
                "outputs": [
                    "Multiply_1608_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_1611"
                ],
                "name": "Reshape_1612",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1612_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_1612"
                ],
                "name": "Reshape_1613",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_1613_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_1608",
                    "Reshape_1613"
                ],
                "name": "Add_1614",
                "op": "Add",
                "outputs": [
                    "Add_1614_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1603",
            "Parameter_1604",
            "Parameter_1605",
            "Parameter_1606"
        ],
        "result": [
            "Add_1614"
        ]
    }
]