[
    {
        "name": "Function_2",
        "ops": [
            {
                "element_type": "char",
                "inputs": [],
                "name": "Parameter_74",
                "op": "Parameter",
                "outputs": [
                    "Parameter_74_0"
                ],
                "shape": []
            }
        ],
        "parameters": [
            "Parameter_74"
        ],
        "result": [
            "Parameter_74"
        ]
    }
]