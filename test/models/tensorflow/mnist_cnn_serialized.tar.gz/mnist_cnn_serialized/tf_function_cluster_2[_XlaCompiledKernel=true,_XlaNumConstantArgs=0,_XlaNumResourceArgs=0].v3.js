[
    {
        "name": "Function_0",
        "ops": [
            {
                "element_type": "char",
                "inputs": [],
                "name": "Parameter_0",
                "op": "Parameter",
                "outputs": [
                    "Parameter_0_0"
                ],
                "shape": []
            }
        ],
        "parameters": [
            "Parameter_0"
        ],
        "result": [
            "Parameter_0"
        ]
    }
]