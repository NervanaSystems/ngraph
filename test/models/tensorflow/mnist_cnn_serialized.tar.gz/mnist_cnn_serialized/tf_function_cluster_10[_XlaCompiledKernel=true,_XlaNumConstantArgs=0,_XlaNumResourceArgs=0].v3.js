[
    {
        "name": "Function_1",
        "ops": [
            {
                "element_type": "char",
                "inputs": [],
                "name": "Parameter_37",
                "op": "Parameter",
                "outputs": [
                    "Parameter_37_0"
                ],
                "shape": []
            }
        ],
        "parameters": [
            "Parameter_37"
        ],
        "result": [
            "Parameter_37"
        ]
    }
]