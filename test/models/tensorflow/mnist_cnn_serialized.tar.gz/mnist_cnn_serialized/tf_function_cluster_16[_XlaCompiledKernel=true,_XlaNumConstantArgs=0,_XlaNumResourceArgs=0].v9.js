[
    {
        "name": "Function_7",
        "ops": [
            {
                "element_type": "char",
                "inputs": [],
                "name": "Parameter_234",
                "op": "Parameter",
                "outputs": [
                    "Parameter_234_0"
                ],
                "shape": [
                    50
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_237",
                "op": "Constant",
                "outputs": [
                    "Constant_237_0"
                ],
                "shape": [],
                "value": [
                    "50"
                ]
            },
            {
                "inputs": [
                    "Parameter_234"
                ],
                "name": "Convert_235",
                "op": "Convert",
                "outputs": [
                    "Convert_235_0"
                ],
                "target_type": "float"
            },
            {
                "inputs": [
                    "Convert_235"
                ],
                "name": "Sum_236",
                "op": "Sum",
                "outputs": [
                    "Sum_236_0"
                ],
                "reduction_axes": [
                    0
                ]
            },
            {
                "inputs": [
                    "Sum_236",
                    "Constant_237"
                ],
                "name": "Divide_238",
                "op": "Divide",
                "outputs": [
                    "Divide_238_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_234"
        ],
        "result": [
            "Divide_238"
        ]
    }
]