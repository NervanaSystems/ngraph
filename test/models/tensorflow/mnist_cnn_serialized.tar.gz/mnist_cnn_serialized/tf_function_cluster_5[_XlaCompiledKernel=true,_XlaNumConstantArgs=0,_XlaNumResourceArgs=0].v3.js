[
    {
        "name": "Function_3",
        "ops": [
            {
                "element_type": "char",
                "inputs": [],
                "name": "Parameter_111",
                "op": "Parameter",
                "outputs": [
                    "Parameter_111_0"
                ],
                "shape": []
            }
        ],
        "parameters": [
            "Parameter_111"
        ],
        "result": [
            "Parameter_111"
        ]
    }
]