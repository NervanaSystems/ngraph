[
    {
        "name": "Function_132",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7215",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7215_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7214",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7214_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7213",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7213_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7213"
                ],
                "name": "Broadcast_7216",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7216_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7214",
                    "Broadcast_7216"
                ],
                "name": "Multiply_7217",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7217_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7217",
                    "Parameter_7215"
                ],
                "name": "Add_7218",
                "op": "Add",
                "outputs": [
                    "Add_7218_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7213",
            "Parameter_7214",
            "Parameter_7215"
        ],
        "result": [
            "Add_7218"
        ]
    }
]