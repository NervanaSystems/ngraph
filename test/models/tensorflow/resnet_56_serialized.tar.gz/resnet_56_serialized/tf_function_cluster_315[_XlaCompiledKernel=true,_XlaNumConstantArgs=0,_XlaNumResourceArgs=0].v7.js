[
    {
        "name": "Function_77",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4616",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4616_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4615",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4615_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4614",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4614_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4614"
                ],
                "name": "Broadcast_4617",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4617_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4615",
                    "Broadcast_4617"
                ],
                "name": "Multiply_4618",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4618_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4618",
                    "Parameter_4616"
                ],
                "name": "Add_4619",
                "op": "Add",
                "outputs": [
                    "Add_4619_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4614",
            "Parameter_4615",
            "Parameter_4616"
        ],
        "result": [
            "Add_4619"
        ]
    }
]