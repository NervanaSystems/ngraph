[
    {
        "name": "Function_10",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_454",
                "op": "Parameter",
                "outputs": [
                    "Parameter_454_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_453",
                "op": "Parameter",
                "outputs": [
                    "Parameter_453_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_455",
                "op": "Constant",
                "outputs": [
                    "Constant_455_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_454"
                ],
                "name": "Reshape_459",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_459_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_455"
                ],
                "name": "Broadcast_456",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_456_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_456",
                    "Parameter_453"
                ],
                "name": "Maximum_457",
                "op": "Maximum",
                "outputs": [
                    "Maximum_457_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_457"
                ],
                "name": "Reshape_458",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_458_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_458",
                    "Reshape_459"
                ],
                "name": "Convolution_460",
                "op": "Convolution",
                "outputs": [
                    "Convolution_460_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_460"
                ],
                "name": "Reshape_461",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_461_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_453",
            "Parameter_454"
        ],
        "result": [
            "Reshape_461",
            "Maximum_457"
        ]
    }
]