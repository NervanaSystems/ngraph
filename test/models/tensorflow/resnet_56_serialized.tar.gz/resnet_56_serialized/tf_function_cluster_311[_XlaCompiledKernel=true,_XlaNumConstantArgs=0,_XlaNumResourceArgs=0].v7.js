[
    {
        "name": "Function_188",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9945",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9945_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9944",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9944_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9943",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9943_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9943"
                ],
                "name": "Broadcast_9946",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9946_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9944",
                    "Broadcast_9946"
                ],
                "name": "Multiply_9947",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9947_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9947",
                    "Parameter_9945"
                ],
                "name": "Add_9948",
                "op": "Add",
                "outputs": [
                    "Add_9948_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9943",
            "Parameter_9944",
            "Parameter_9945"
        ],
        "result": [
            "Add_9948"
        ]
    }
]