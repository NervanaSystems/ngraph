[
    {
        "name": "Function_209",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10944",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10944_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10943",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10943_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10942",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10942_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10942"
                ],
                "name": "Broadcast_10945",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10945_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10943",
                    "Broadcast_10945"
                ],
                "name": "Multiply_10946",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10946_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10946",
                    "Parameter_10944"
                ],
                "name": "Add_10947",
                "op": "Add",
                "outputs": [
                    "Add_10947_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10942",
            "Parameter_10943",
            "Parameter_10944"
        ],
        "result": [
            "Add_10947"
        ]
    }
]