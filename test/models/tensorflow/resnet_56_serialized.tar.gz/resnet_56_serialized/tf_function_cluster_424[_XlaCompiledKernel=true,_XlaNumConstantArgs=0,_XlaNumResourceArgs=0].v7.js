[
    {
        "name": "Function_171",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9129",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9129_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9128",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9128_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9127",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9127_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9127"
                ],
                "name": "Broadcast_9130",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9130_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9128",
                    "Broadcast_9130"
                ],
                "name": "Multiply_9131",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9131_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9131",
                    "Parameter_9129"
                ],
                "name": "Add_9132",
                "op": "Add",
                "outputs": [
                    "Add_9132_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9127",
            "Parameter_9128",
            "Parameter_9129"
        ],
        "result": [
            "Add_9132"
        ]
    }
]