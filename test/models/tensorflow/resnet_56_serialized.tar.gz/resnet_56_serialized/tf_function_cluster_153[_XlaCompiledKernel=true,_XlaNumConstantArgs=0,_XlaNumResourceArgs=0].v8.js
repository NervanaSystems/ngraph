[
    {
        "name": "Function_11",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_500",
                "op": "Parameter",
                "outputs": [
                    "Parameter_500_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_499",
                "op": "Parameter",
                "outputs": [
                    "Parameter_499_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_498",
                "op": "Parameter",
                "outputs": [
                    "Parameter_498_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_501",
                "op": "Constant",
                "outputs": [
                    "Constant_501_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_499"
                ],
                "name": "Reshape_505",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_505_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_501"
                ],
                "name": "Broadcast_502",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_502_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_502",
                    "Parameter_498"
                ],
                "name": "Maximum_503",
                "op": "Maximum",
                "outputs": [
                    "Maximum_503_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_503"
                ],
                "name": "Reshape_504",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_504_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_504",
                    "Reshape_505"
                ],
                "name": "Convolution_506",
                "op": "Convolution",
                "outputs": [
                    "Convolution_506_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_506"
                ],
                "name": "Reshape_507",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_507_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_507",
                    "Parameter_500"
                ],
                "name": "Add_508",
                "op": "Add",
                "outputs": [
                    "Add_508_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_498",
            "Parameter_499",
            "Parameter_500"
        ],
        "result": [
            "Add_508",
            "Maximum_503",
            "Reshape_507"
        ]
    }
]