[
    {
        "name": "Function_80",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4761",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4761_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4760",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4760_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4759",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4759_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4759"
                ],
                "name": "Broadcast_4762",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4762_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4760",
                    "Broadcast_4762"
                ],
                "name": "Multiply_4763",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4763_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4763",
                    "Parameter_4761"
                ],
                "name": "Add_4764",
                "op": "Add",
                "outputs": [
                    "Add_4764_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4759",
            "Parameter_4760",
            "Parameter_4761"
        ],
        "result": [
            "Add_4764"
        ]
    }
]