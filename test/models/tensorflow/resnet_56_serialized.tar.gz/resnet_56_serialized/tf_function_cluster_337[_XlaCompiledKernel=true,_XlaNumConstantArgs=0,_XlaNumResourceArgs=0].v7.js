[
    {
        "name": "Function_155",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8352",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8352_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8351",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8351_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8350",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8350_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8350"
                ],
                "name": "Broadcast_8353",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8353_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8351",
                    "Broadcast_8353"
                ],
                "name": "Multiply_8354",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8354_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8354",
                    "Parameter_8352"
                ],
                "name": "Add_8355",
                "op": "Add",
                "outputs": [
                    "Add_8355_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8350",
            "Parameter_8351",
            "Parameter_8352"
        ],
        "result": [
            "Add_8355"
        ]
    }
]