[
    {
        "name": "Function_204",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10700",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10700_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10699",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10699_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10698",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10698_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10698"
                ],
                "name": "Broadcast_10701",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10701_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10699",
                    "Broadcast_10701"
                ],
                "name": "Multiply_10702",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10702_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10702",
                    "Parameter_10700"
                ],
                "name": "Add_10703",
                "op": "Add",
                "outputs": [
                    "Add_10703_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10698",
            "Parameter_10699",
            "Parameter_10700"
        ],
        "result": [
            "Add_10703"
        ]
    }
]