[
    {
        "name": "Function_50",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2312",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2312_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2311",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2311_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2313",
                "op": "Constant",
                "outputs": [
                    "Constant_2313_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2312"
                ],
                "name": "Reshape_2317",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2317_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2313"
                ],
                "name": "Broadcast_2314",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2314_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2314",
                    "Parameter_2311"
                ],
                "name": "Maximum_2315",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2315_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2315"
                ],
                "name": "Reshape_2316",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2316_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2316",
                    "Reshape_2317"
                ],
                "name": "Convolution_2318",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2318_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2318"
                ],
                "name": "Reshape_2319",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2319_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2311",
            "Parameter_2312"
        ],
        "result": [
            "Reshape_2319",
            "Maximum_2315"
        ]
    }
]