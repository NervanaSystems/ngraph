[
    {
        "name": "Function_75",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4483",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4483_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4482",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4482_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4481",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4481_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4480",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4480_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_4484",
                "op": "Constant",
                "outputs": [
                    "Constant_4484_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4483"
                ],
                "name": "Reshape_4496",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4496_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4483"
                ],
                "name": "Reshape_4488",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4488_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4482"
                ],
                "name": "Reshape_4495",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4495_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4481"
                ],
                "name": "Reverse_4487",
                "op": "Reverse",
                "outputs": [
                    "Reverse_4487_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_4480"
                ],
                "name": "Broadcast_4493",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4493_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_4484"
                ],
                "name": "Broadcast_4485",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4485_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4495",
                    "Reshape_4496"
                ],
                "name": "Convolution_4497",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4497_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_4487"
                ],
                "name": "Reshape_4489",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_4489_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4481",
                    "Broadcast_4493"
                ],
                "name": "Multiply_4494",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4494_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4482",
                    "Broadcast_4485"
                ],
                "name": "Greater_4486",
                "op": "Greater",
                "outputs": [
                    "Greater_4486_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_4497"
                ],
                "name": "Reshape_4499",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_4499_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4488",
                    "Reshape_4489"
                ],
                "name": "Convolution_4490",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4490_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_4499"
                ],
                "name": "Reshape_4504",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_4504_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_4490"
                ],
                "name": "Reshape_4491",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4491_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4494",
                    "Reshape_4504"
                ],
                "name": "Add_4508",
                "op": "Add",
                "outputs": [
                    "Add_4508_0"
                ]
            },
            {
                "inputs": [
                    "Greater_4486",
                    "Reshape_4491",
                    "Broadcast_4485"
                ],
                "name": "Select_4492",
                "op": "Select",
                "outputs": [
                    "Select_4492_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4480",
            "Parameter_4481",
            "Parameter_4482",
            "Parameter_4483"
        ],
        "result": [
            "Select_4492",
            "Add_4508"
        ]
    }
]