[
    {
        "name": "Function_195",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10239",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10239_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10238",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10238_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10237",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10237_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10236",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10236_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_10240",
                "op": "Constant",
                "outputs": [
                    "Constant_10240_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10239"
                ],
                "name": "Reshape_10252",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10252_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10239"
                ],
                "name": "Reshape_10244",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10244_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10238"
                ],
                "name": "Reshape_10251",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10251_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10237"
                ],
                "name": "Reverse_10243",
                "op": "Reverse",
                "outputs": [
                    "Reverse_10243_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_10236"
                ],
                "name": "Broadcast_10249",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10249_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_10240"
                ],
                "name": "Broadcast_10241",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10241_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10251",
                    "Reshape_10252"
                ],
                "name": "Convolution_10253",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10253_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_10243"
                ],
                "name": "Reshape_10245",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_10245_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10237",
                    "Broadcast_10249"
                ],
                "name": "Multiply_10250",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10250_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10238",
                    "Broadcast_10241"
                ],
                "name": "Greater_10242",
                "op": "Greater",
                "outputs": [
                    "Greater_10242_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_10253"
                ],
                "name": "Reshape_10254",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_10254_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10244",
                    "Reshape_10245"
                ],
                "name": "Convolution_10246",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10246_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_10254"
                ],
                "name": "Reshape_10255",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_10255_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_10246"
                ],
                "name": "Reshape_10247",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10247_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10250",
                    "Reshape_10255"
                ],
                "name": "Add_10256",
                "op": "Add",
                "outputs": [
                    "Add_10256_0"
                ]
            },
            {
                "inputs": [
                    "Greater_10242",
                    "Reshape_10247",
                    "Broadcast_10241"
                ],
                "name": "Select_10248",
                "op": "Select",
                "outputs": [
                    "Select_10248_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10236",
            "Parameter_10237",
            "Parameter_10238",
            "Parameter_10239"
        ],
        "result": [
            "Select_10248",
            "Add_10256"
        ]
    }
]