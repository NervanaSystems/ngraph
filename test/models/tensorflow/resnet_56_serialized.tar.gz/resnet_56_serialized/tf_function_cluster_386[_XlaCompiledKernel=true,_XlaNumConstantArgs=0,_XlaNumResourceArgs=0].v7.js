[
    {
        "name": "Function_121",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6739",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6739_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6738",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6738_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6737",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6737_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6737"
                ],
                "name": "Broadcast_6740",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6740_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6738",
                    "Broadcast_6740"
                ],
                "name": "Multiply_6741",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6741_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6741",
                    "Parameter_6739"
                ],
                "name": "Add_6742",
                "op": "Add",
                "outputs": [
                    "Add_6742_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6737",
            "Parameter_6738",
            "Parameter_6739"
        ],
        "result": [
            "Add_6742"
        ]
    }
]