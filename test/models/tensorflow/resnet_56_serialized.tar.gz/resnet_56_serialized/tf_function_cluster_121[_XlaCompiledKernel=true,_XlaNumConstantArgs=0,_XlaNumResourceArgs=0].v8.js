[
    {
        "name": "Function_45",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2082",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2082_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2081",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2081_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2080",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2080_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2083",
                "op": "Constant",
                "outputs": [
                    "Constant_2083_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2081"
                ],
                "name": "Reshape_2087",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2087_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2083"
                ],
                "name": "Broadcast_2084",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2084_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2084",
                    "Parameter_2080"
                ],
                "name": "Maximum_2085",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2085_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2085"
                ],
                "name": "Reshape_2086",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2086_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2086",
                    "Reshape_2087"
                ],
                "name": "Convolution_2088",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2088_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2088"
                ],
                "name": "Reshape_2089",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2089_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_2089",
                    "Parameter_2082"
                ],
                "name": "Add_2090",
                "op": "Add",
                "outputs": [
                    "Add_2090_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2080",
            "Parameter_2081",
            "Parameter_2082"
        ],
        "result": [
            "Add_2090",
            "Maximum_2085",
            "Reshape_2089"
        ]
    }
]