[
    {
        "name": "Function_94",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5383",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5383_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5382",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5382_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5381",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5381_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5380",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5380_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_5384",
                "op": "Constant",
                "outputs": [
                    "Constant_5384_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5383"
                ],
                "name": "Reshape_5396",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5396_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5383"
                ],
                "name": "Reshape_5388",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5388_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5382"
                ],
                "name": "Reshape_5395",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5395_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5381"
                ],
                "name": "Reverse_5387",
                "op": "Reverse",
                "outputs": [
                    "Reverse_5387_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_5380"
                ],
                "name": "Broadcast_5393",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5393_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_5384"
                ],
                "name": "Broadcast_5385",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5385_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5395",
                    "Reshape_5396"
                ],
                "name": "Convolution_5397",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5397_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_5387"
                ],
                "name": "Reshape_5389",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_5389_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5381",
                    "Broadcast_5393"
                ],
                "name": "Multiply_5394",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5394_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5382",
                    "Broadcast_5385"
                ],
                "name": "Greater_5386",
                "op": "Greater",
                "outputs": [
                    "Greater_5386_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_5397"
                ],
                "name": "Reshape_5398",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_5398_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5388",
                    "Reshape_5389"
                ],
                "name": "Convolution_5390",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5390_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_5398"
                ],
                "name": "Reshape_5399",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_5399_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_5390"
                ],
                "name": "Reshape_5391",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5391_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5394",
                    "Reshape_5399"
                ],
                "name": "Add_5400",
                "op": "Add",
                "outputs": [
                    "Add_5400_0"
                ]
            },
            {
                "inputs": [
                    "Greater_5386",
                    "Reshape_5391",
                    "Broadcast_5385"
                ],
                "name": "Select_5392",
                "op": "Select",
                "outputs": [
                    "Select_5392_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5380",
            "Parameter_5381",
            "Parameter_5382",
            "Parameter_5383"
        ],
        "result": [
            "Select_5392",
            "Add_5400"
        ]
    }
]