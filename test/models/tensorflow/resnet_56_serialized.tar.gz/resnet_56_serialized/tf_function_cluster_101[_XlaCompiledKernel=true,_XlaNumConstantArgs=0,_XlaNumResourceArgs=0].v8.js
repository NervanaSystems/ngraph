[
    {
        "name": "Function_49",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2266",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2266_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2265",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2265_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2264",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2264_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2267",
                "op": "Constant",
                "outputs": [
                    "Constant_2267_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2265"
                ],
                "name": "Reshape_2271",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2271_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2267"
                ],
                "name": "Broadcast_2268",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2268_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2268",
                    "Parameter_2264"
                ],
                "name": "Maximum_2269",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2269_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2269"
                ],
                "name": "Reshape_2270",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2270_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2270",
                    "Reshape_2271"
                ],
                "name": "Convolution_2272",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2272_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2272"
                ],
                "name": "Reshape_2273",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2273_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_2273",
                    "Parameter_2266"
                ],
                "name": "Add_2274",
                "op": "Add",
                "outputs": [
                    "Add_2274_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2264",
            "Parameter_2265",
            "Parameter_2266"
        ],
        "result": [
            "Add_2274",
            "Maximum_2269",
            "Reshape_2273"
        ]
    }
]