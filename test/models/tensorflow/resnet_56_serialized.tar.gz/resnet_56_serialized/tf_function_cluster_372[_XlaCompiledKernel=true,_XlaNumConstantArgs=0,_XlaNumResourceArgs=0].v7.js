[
    {
        "name": "Function_76",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4539",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4539_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4538",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4538_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4537",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4537_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4537"
                ],
                "name": "Broadcast_4540",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4540_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4538",
                    "Broadcast_4540"
                ],
                "name": "Multiply_4541",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4541_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4541",
                    "Parameter_4539"
                ],
                "name": "Add_4542",
                "op": "Add",
                "outputs": [
                    "Add_4542_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4537",
            "Parameter_4538",
            "Parameter_4539"
        ],
        "result": [
            "Add_4542"
        ]
    }
]