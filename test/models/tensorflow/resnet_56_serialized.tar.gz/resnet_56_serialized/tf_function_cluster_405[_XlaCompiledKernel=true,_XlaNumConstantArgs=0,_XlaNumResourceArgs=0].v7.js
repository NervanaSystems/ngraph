[
    {
        "name": "Function_183",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9701",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9701_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9700",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9700_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9699",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9699_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9699"
                ],
                "name": "Broadcast_9702",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9702_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9700",
                    "Broadcast_9702"
                ],
                "name": "Multiply_9703",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9703_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9703",
                    "Parameter_9701"
                ],
                "name": "Add_9704",
                "op": "Add",
                "outputs": [
                    "Add_9704_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9699",
            "Parameter_9700",
            "Parameter_9701"
        ],
        "result": [
            "Add_9704"
        ]
    }
]