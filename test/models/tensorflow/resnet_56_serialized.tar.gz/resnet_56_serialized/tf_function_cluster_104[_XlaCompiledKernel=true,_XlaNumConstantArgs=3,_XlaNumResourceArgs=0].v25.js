[
    {
        "name": "Function_78",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4660",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4660_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4659",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4659_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4658",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4658_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4657",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4657_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4656",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4656_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_4663",
                "op": "Constant",
                "outputs": [
                    "Constant_4663_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4660"
                ],
                "name": "Reshape_4675",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4675_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4658",
                    "Parameter_4659"
                ],
                "name": "Add_4661",
                "op": "Add",
                "outputs": [
                    "Add_4661_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4657"
                ],
                "name": "Reverse_4667",
                "op": "Reverse",
                "outputs": [
                    "Reverse_4667_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_4656"
                ],
                "name": "Broadcast_4673",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4673_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_4663"
                ],
                "name": "Broadcast_4664",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4664_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_4661"
                ],
                "name": "Reshape_4666",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4666_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_4661"
                ],
                "name": "Reshape_4662",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4662_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_4667"
                ],
                "name": "Reshape_4669",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_4669_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4657",
                    "Broadcast_4673"
                ],
                "name": "Multiply_4674",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4674_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4660",
                    "Broadcast_4664"
                ],
                "name": "Greater_4665",
                "op": "Greater",
                "outputs": [
                    "Greater_4665_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_4666"
                ],
                "name": "Reshape_4668",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4668_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_4666"
                ],
                "name": "Reshape_4676",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4676_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4668",
                    "Reshape_4669"
                ],
                "name": "Convolution_4670",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4670_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4675",
                    "Reshape_4676"
                ],
                "name": "Convolution_4677",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4677_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_4670"
                ],
                "name": "Reshape_4671",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4671_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_4677"
                ],
                "name": "Reshape_4678",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_4678_0"
                ]
            },
            {
                "inputs": [
                    "Greater_4665",
                    "Reshape_4671",
                    "Broadcast_4664"
                ],
                "name": "Select_4672",
                "op": "Select",
                "outputs": [
                    "Select_4672_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_4678"
                ],
                "name": "Reshape_4679",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_4679_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4674",
                    "Reshape_4679"
                ],
                "name": "Add_4680",
                "op": "Add",
                "outputs": [
                    "Add_4680_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4656",
            "Parameter_4657",
            "Parameter_4658",
            "Parameter_4659",
            "Parameter_4660"
        ],
        "result": [
            "Reshape_4662",
            "Select_4672",
            "Add_4680"
        ]
    }
]