[
    {
        "name": "Function_156",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8359",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8359_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8358",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8358_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8357",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8357_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8357"
                ],
                "name": "Broadcast_8360",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8360_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8358",
                    "Broadcast_8360"
                ],
                "name": "Multiply_8361",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8361_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8361",
                    "Parameter_8359"
                ],
                "name": "Add_8362",
                "op": "Add",
                "outputs": [
                    "Add_8362_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8357",
            "Parameter_8358",
            "Parameter_8359"
        ],
        "result": [
            "Add_8362"
        ]
    }
]