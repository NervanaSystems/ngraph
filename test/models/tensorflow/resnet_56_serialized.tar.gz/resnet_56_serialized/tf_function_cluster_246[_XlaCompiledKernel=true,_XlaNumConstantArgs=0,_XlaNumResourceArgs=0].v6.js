[
    {
        "name": "Function_16",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_730",
                "op": "Parameter",
                "outputs": [
                    "Parameter_730_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_729",
                "op": "Parameter",
                "outputs": [
                    "Parameter_729_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_731",
                "op": "Constant",
                "outputs": [
                    "Constant_731_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_730"
                ],
                "name": "Reshape_735",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_735_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_731"
                ],
                "name": "Broadcast_732",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_732_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_732",
                    "Parameter_729"
                ],
                "name": "Maximum_733",
                "op": "Maximum",
                "outputs": [
                    "Maximum_733_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_733"
                ],
                "name": "Reshape_734",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_734_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_734",
                    "Reshape_735"
                ],
                "name": "Convolution_736",
                "op": "Convolution",
                "outputs": [
                    "Convolution_736_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_736"
                ],
                "name": "Reshape_737",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_737_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_729",
            "Parameter_730"
        ],
        "result": [
            "Reshape_737",
            "Maximum_733"
        ]
    }
]