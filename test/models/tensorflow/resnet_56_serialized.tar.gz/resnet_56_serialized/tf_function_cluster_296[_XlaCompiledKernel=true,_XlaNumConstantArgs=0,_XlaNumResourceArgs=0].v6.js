[
    {
        "name": "Function_12",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_546",
                "op": "Parameter",
                "outputs": [
                    "Parameter_546_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_545",
                "op": "Parameter",
                "outputs": [
                    "Parameter_545_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_547",
                "op": "Constant",
                "outputs": [
                    "Constant_547_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_546"
                ],
                "name": "Reshape_551",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_551_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_547"
                ],
                "name": "Broadcast_548",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_548_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_548",
                    "Parameter_545"
                ],
                "name": "Maximum_549",
                "op": "Maximum",
                "outputs": [
                    "Maximum_549_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_549"
                ],
                "name": "Reshape_550",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_550_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_550",
                    "Reshape_551"
                ],
                "name": "Convolution_552",
                "op": "Convolution",
                "outputs": [
                    "Convolution_552_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_552"
                ],
                "name": "Reshape_553",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_553_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_545",
            "Parameter_546"
        ],
        "result": [
            "Reshape_553",
            "Maximum_549"
        ]
    }
]