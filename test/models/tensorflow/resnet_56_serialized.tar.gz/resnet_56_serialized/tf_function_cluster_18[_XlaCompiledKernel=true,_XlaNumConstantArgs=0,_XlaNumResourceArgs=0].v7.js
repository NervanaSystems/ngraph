[
    {
        "name": "Function_201",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10559",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10559_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10558",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10558_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10557",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10557_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10557"
                ],
                "name": "Broadcast_10560",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10560_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10558",
                    "Broadcast_10560"
                ],
                "name": "Multiply_10561",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10561_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10561",
                    "Parameter_10559"
                ],
                "name": "Add_10562",
                "op": "Add",
                "outputs": [
                    "Add_10562_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10557",
            "Parameter_10558",
            "Parameter_10559"
        ],
        "result": [
            "Add_10562"
        ]
    }
]