[
    {
        "name": "Function_216",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11256",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11256_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11255",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11255_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11254",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11254_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_11254"
                ],
                "name": "Broadcast_11257",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11257_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_11255",
                    "Broadcast_11257"
                ],
                "name": "Multiply_11258",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11258_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11258",
                    "Parameter_11256"
                ],
                "name": "Add_11259",
                "op": "Add",
                "outputs": [
                    "Add_11259_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_11254",
            "Parameter_11255",
            "Parameter_11256"
        ],
        "result": [
            "Add_11259"
        ]
    }
]