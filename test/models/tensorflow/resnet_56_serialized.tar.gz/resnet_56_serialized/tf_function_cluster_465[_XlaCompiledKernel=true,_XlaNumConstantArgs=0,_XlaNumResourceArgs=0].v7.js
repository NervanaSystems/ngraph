[
    {
        "name": "Function_81",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4803",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4803_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4802",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4802_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4801",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4801_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4801"
                ],
                "name": "Broadcast_4804",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4804_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4802",
                    "Broadcast_4804"
                ],
                "name": "Multiply_4805",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4805_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4805",
                    "Parameter_4803"
                ],
                "name": "Add_4806",
                "op": "Add",
                "outputs": [
                    "Add_4806_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4801",
            "Parameter_4802",
            "Parameter_4803"
        ],
        "result": [
            "Add_4806"
        ]
    }
]