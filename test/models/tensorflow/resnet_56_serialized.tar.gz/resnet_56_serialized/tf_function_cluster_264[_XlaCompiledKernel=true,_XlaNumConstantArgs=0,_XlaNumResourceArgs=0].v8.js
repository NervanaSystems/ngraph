[
    {
        "name": "Function_19",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_868",
                "op": "Parameter",
                "outputs": [
                    "Parameter_868_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_867",
                "op": "Parameter",
                "outputs": [
                    "Parameter_867_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_866",
                "op": "Parameter",
                "outputs": [
                    "Parameter_866_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_869",
                "op": "Constant",
                "outputs": [
                    "Constant_869_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_867"
                ],
                "name": "Reshape_873",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_873_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_869"
                ],
                "name": "Broadcast_870",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_870_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_870",
                    "Parameter_866"
                ],
                "name": "Maximum_871",
                "op": "Maximum",
                "outputs": [
                    "Maximum_871_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_871"
                ],
                "name": "Reshape_872",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_872_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_872",
                    "Reshape_873"
                ],
                "name": "Convolution_874",
                "op": "Convolution",
                "outputs": [
                    "Convolution_874_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_874"
                ],
                "name": "Reshape_875",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_875_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_875",
                    "Parameter_868"
                ],
                "name": "Add_876",
                "op": "Add",
                "outputs": [
                    "Add_876_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_866",
            "Parameter_867",
            "Parameter_868"
        ],
        "result": [
            "Add_876",
            "Maximum_871",
            "Reshape_875"
        ]
    }
]