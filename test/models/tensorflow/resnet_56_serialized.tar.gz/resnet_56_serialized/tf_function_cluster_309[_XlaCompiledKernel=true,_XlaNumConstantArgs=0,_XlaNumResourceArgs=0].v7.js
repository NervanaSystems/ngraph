[
    {
        "name": "Function_136",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7382",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7382_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7381",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7381_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7380",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7380_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7380"
                ],
                "name": "Broadcast_7383",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7383_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7381",
                    "Broadcast_7383"
                ],
                "name": "Multiply_7384",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7384_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7384",
                    "Parameter_7382"
                ],
                "name": "Add_7385",
                "op": "Add",
                "outputs": [
                    "Add_7385_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7380",
            "Parameter_7381",
            "Parameter_7382"
        ],
        "result": [
            "Add_7385"
        ]
    }
]