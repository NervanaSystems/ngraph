[
    {
        "name": "Function_64",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3918",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3918_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3917",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3917_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3916",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3916_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3915",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3915_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_3919",
                "op": "Constant",
                "outputs": [
                    "Constant_3919_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_3918"
                ],
                "name": "Reshape_3931",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_3931_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_3918"
                ],
                "name": "Reshape_3923",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_3923_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_3917"
                ],
                "name": "Reshape_3930",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_3930_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3916"
                ],
                "name": "Reverse_3922",
                "op": "Reverse",
                "outputs": [
                    "Reverse_3922_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_3915"
                ],
                "name": "Broadcast_3928",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3928_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_3919"
                ],
                "name": "Broadcast_3920",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3920_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_3930",
                    "Reshape_3931"
                ],
                "name": "Convolution_3932",
                "op": "Convolution",
                "outputs": [
                    "Convolution_3932_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_3922"
                ],
                "name": "Reshape_3924",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_3924_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3916",
                    "Broadcast_3928"
                ],
                "name": "Multiply_3929",
                "op": "Multiply",
                "outputs": [
                    "Multiply_3929_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3917",
                    "Broadcast_3920"
                ],
                "name": "Greater_3921",
                "op": "Greater",
                "outputs": [
                    "Greater_3921_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_3932"
                ],
                "name": "Reshape_3933",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_3933_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_3923",
                    "Reshape_3924"
                ],
                "name": "Convolution_3925",
                "op": "Convolution",
                "outputs": [
                    "Convolution_3925_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_3933"
                ],
                "name": "Reshape_3934",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_3934_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_3925"
                ],
                "name": "Reshape_3926",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_3926_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_3929",
                    "Reshape_3934"
                ],
                "name": "Add_3935",
                "op": "Add",
                "outputs": [
                    "Add_3935_0"
                ]
            },
            {
                "inputs": [
                    "Greater_3921",
                    "Reshape_3926",
                    "Broadcast_3920"
                ],
                "name": "Select_3927",
                "op": "Select",
                "outputs": [
                    "Select_3927_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_3915",
            "Parameter_3916",
            "Parameter_3917",
            "Parameter_3918"
        ],
        "result": [
            "Select_3927",
            "Add_3935"
        ]
    }
]