[
    {
        "name": "Function_114",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6376",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6376_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6375",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6375_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6374",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6374_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6374"
                ],
                "name": "Broadcast_6377",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6377_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6375",
                    "Broadcast_6377"
                ],
                "name": "Multiply_6378",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6378_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6378",
                    "Parameter_6376"
                ],
                "name": "Add_6379",
                "op": "Add",
                "outputs": [
                    "Add_6379_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6374",
            "Parameter_6375",
            "Parameter_6376"
        ],
        "result": [
            "Add_6379"
        ]
    }
]