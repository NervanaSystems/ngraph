[
    {
        "name": "Function_166",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8837",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8837_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8836",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8836_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8835",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8835_0"
                ],
                "shape": [
                    2,
                    34,
                    34,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8834",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8834_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8833",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8833_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8832",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8832_0"
                ],
                "shape": [
                    1,
                    1,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8831",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8831_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8830",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8830_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_8838",
                "op": "Constant",
                "outputs": [
                    "Constant_8838_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8836"
                ],
                "name": "Reshape_8847",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8847_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8836"
                ],
                "name": "Reshape_8857",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8857_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8835"
                ],
                "name": "Reshape_8856",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    34,
                    34
                ],
                "outputs": [
                    "Reshape_8856_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8834"
                ],
                "name": "Reshape_8865",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_8865_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8833"
                ],
                "name": "Reshape_8842",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8842_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8833"
                ],
                "name": "Reshape_8866",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8866_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8832"
                ],
                "name": "Reverse_8841",
                "op": "Reverse",
                "outputs": [
                    "Reverse_8841_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "inputs": [
                    "Parameter_8831"
                ],
                "name": "Reverse_8846",
                "op": "Reverse",
                "outputs": [
                    "Reverse_8846_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "input_order": [],
                "inputs": [
                    "Parameter_8830"
                ],
                "name": "Reshape_8862",
                "op": "Reshape",
                "output_shape": [
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_8862_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_8830"
                ],
                "name": "Broadcast_8854",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8854_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_8838"
                ],
                "name": "Broadcast_8839",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8839_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8856",
                    "Reshape_8857"
                ],
                "name": "Convolution_8858",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8858_0"
                ],
                "padding_above": [
                    -1,
                    -1
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    2,
                    2
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8865",
                    "Reshape_8866"
                ],
                "name": "Convolution_8867",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8867_0"
                ],
                "padding_above": [
                    -1,
                    -1
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    2,
                    2
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_8841"
                ],
                "name": "Reshape_8843",
                "op": "Reshape",
                "output_shape": [
                    16,
                    32,
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_8843_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_8846"
                ],
                "name": "Reshape_8848",
                "op": "Reshape",
                "output_shape": [
                    16,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_8848_0"
                ]
            },
            {
                "axes": [
                    2,
                    3
                ],
                "inputs": [
                    "Reshape_8862"
                ],
                "name": "Broadcast_8863",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8863_0"
                ],
                "shape": [
                    1,
                    1,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8831",
                    "Broadcast_8854"
                ],
                "name": "Multiply_8855",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8855_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8837",
                    "Broadcast_8839"
                ],
                "name": "Greater_8840",
                "op": "Greater",
                "outputs": [
                    "Greater_8840_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_8858"
                ],
                "name": "Reshape_8859",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_8859_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_8867"
                ],
                "name": "Reshape_8868",
                "op": "Reshape",
                "output_shape": [
                    32,
                    1,
                    1,
                    16
                ],
                "outputs": [
                    "Reshape_8868_0"
                ]
            },
            {
                "data_dilation_strides": [
                    2,
                    2
                ],
                "inputs": [
                    "Reshape_8842",
                    "Reshape_8843"
                ],
                "name": "Convolution_8844",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8844_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    2,
                    2
                ],
                "inputs": [
                    "Reshape_8847",
                    "Reshape_8848"
                ],
                "name": "Convolution_8849",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8849_0"
                ],
                "padding_above": [
                    3,
                    3
                ],
                "padding_below": [
                    2,
                    2
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "inputs": [
                    "Parameter_8832",
                    "Broadcast_8863"
                ],
                "name": "Multiply_8864",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8864_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_8859"
                ],
                "name": "Reshape_8860",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8860_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_8868"
                ],
                "name": "Reshape_8869",
                "op": "Reshape",
                "output_shape": [
                    1,
                    1,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8869_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_8844"
                ],
                "name": "Reshape_8845",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_8845_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_8849"
                ],
                "name": "Reshape_8850",
                "op": "Reshape",
                "output_shape": [
                    2,
                    34,
                    34,
                    16
                ],
                "outputs": [
                    "Reshape_8850_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8855",
                    "Reshape_8860"
                ],
                "name": "Add_8861",
                "op": "Add",
                "outputs": [
                    "Add_8861_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8864",
                    "Reshape_8869"
                ],
                "name": "Add_8870",
                "op": "Add",
                "outputs": [
                    "Add_8870_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_8850"
                ],
                "lower_bounds": [
                    0,
                    1,
                    1,
                    0
                ],
                "name": "Slice_8851",
                "op": "Slice",
                "outputs": [
                    "Slice_8851_0"
                ],
                "strides": [
                    1,
                    1,
                    1,
                    1
                ],
                "upper_bounds": [
                    2,
                    33,
                    33,
                    16
                ]
            },
            {
                "inputs": [
                    "Reshape_8845",
                    "Slice_8851"
                ],
                "name": "Add_8852",
                "op": "Add",
                "outputs": [
                    "Add_8852_0"
                ]
            },
            {
                "inputs": [
                    "Greater_8840",
                    "Add_8852",
                    "Broadcast_8839"
                ],
                "name": "Select_8853",
                "op": "Select",
                "outputs": [
                    "Select_8853_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8830",
            "Parameter_8831",
            "Parameter_8832",
            "Parameter_8833",
            "Parameter_8834",
            "Parameter_8835",
            "Parameter_8836",
            "Parameter_8837"
        ],
        "result": [
            "Select_8853",
            "Add_8861",
            "Add_8870"
        ]
    }
]