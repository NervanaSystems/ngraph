[
    {
        "name": "Function_182",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9659",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9659_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9658",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9658_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9657",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9657_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9657"
                ],
                "name": "Broadcast_9660",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9660_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9658",
                    "Broadcast_9660"
                ],
                "name": "Multiply_9661",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9661_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9661",
                    "Parameter_9659"
                ],
                "name": "Add_9662",
                "op": "Add",
                "outputs": [
                    "Add_9662_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9657",
            "Parameter_9658",
            "Parameter_9659"
        ],
        "result": [
            "Add_9662"
        ]
    }
]