[
    {
        "name": "Function_138",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7503",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7503_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7502",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7502_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7501",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7501_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7500",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7500_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7499",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7499_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_7506",
                "op": "Constant",
                "outputs": [
                    "Constant_7506_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7503"
                ],
                "name": "Reshape_7518",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7518_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7501",
                    "Parameter_7502"
                ],
                "name": "Add_7504",
                "op": "Add",
                "outputs": [
                    "Add_7504_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7500"
                ],
                "name": "Reverse_7510",
                "op": "Reverse",
                "outputs": [
                    "Reverse_7510_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_7499"
                ],
                "name": "Broadcast_7516",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7516_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_7506"
                ],
                "name": "Broadcast_7507",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7507_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_7504"
                ],
                "name": "Reshape_7505",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7505_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_7504"
                ],
                "name": "Reshape_7509",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7509_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_7510"
                ],
                "name": "Reshape_7512",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_7512_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7500",
                    "Broadcast_7516"
                ],
                "name": "Multiply_7517",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7517_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7503",
                    "Broadcast_7507"
                ],
                "name": "Greater_7508",
                "op": "Greater",
                "outputs": [
                    "Greater_7508_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_7509"
                ],
                "name": "Reshape_7519",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7519_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_7509"
                ],
                "name": "Reshape_7511",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7511_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7518",
                    "Reshape_7519"
                ],
                "name": "Convolution_7520",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7520_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7511",
                    "Reshape_7512"
                ],
                "name": "Convolution_7513",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7513_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_7520"
                ],
                "name": "Reshape_7521",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_7521_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_7513"
                ],
                "name": "Reshape_7514",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7514_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_7521"
                ],
                "name": "Reshape_7522",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_7522_0"
                ]
            },
            {
                "inputs": [
                    "Greater_7508",
                    "Reshape_7514",
                    "Broadcast_7507"
                ],
                "name": "Select_7515",
                "op": "Select",
                "outputs": [
                    "Select_7515_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7517",
                    "Reshape_7522"
                ],
                "name": "Add_7523",
                "op": "Add",
                "outputs": [
                    "Add_7523_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7499",
            "Parameter_7500",
            "Parameter_7501",
            "Parameter_7502",
            "Parameter_7503"
        ],
        "result": [
            "Reshape_7505",
            "Select_7515",
            "Add_7523"
        ]
    }
]