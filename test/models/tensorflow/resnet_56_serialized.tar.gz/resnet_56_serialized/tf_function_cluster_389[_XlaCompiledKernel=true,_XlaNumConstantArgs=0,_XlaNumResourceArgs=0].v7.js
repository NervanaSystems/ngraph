[
    {
        "name": "Function_179",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9514",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9514_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9513",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9513_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9512",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9512_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9512"
                ],
                "name": "Broadcast_9515",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9515_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9513",
                    "Broadcast_9515"
                ],
                "name": "Multiply_9516",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9516_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9516",
                    "Parameter_9514"
                ],
                "name": "Add_9517",
                "op": "Add",
                "outputs": [
                    "Add_9517_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9512",
            "Parameter_9513",
            "Parameter_9514"
        ],
        "result": [
            "Add_9517"
        ]
    }
]