[
    {
        "name": "Function_206",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10804",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10804_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10803",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10803_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10802",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10802_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10801",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10801_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_10805",
                "op": "Constant",
                "outputs": [
                    "Constant_10805_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10804"
                ],
                "name": "Reshape_10809",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10809_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10804"
                ],
                "name": "Reshape_10817",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10817_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10803"
                ],
                "name": "Reshape_10816",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10816_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10802"
                ],
                "name": "Reverse_10808",
                "op": "Reverse",
                "outputs": [
                    "Reverse_10808_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_10801"
                ],
                "name": "Broadcast_10814",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10814_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_10805"
                ],
                "name": "Broadcast_10806",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10806_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10816",
                    "Reshape_10817"
                ],
                "name": "Convolution_10818",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10818_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_10808"
                ],
                "name": "Reshape_10810",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_10810_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10802",
                    "Broadcast_10814"
                ],
                "name": "Multiply_10815",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10815_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10803",
                    "Broadcast_10806"
                ],
                "name": "Greater_10807",
                "op": "Greater",
                "outputs": [
                    "Greater_10807_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_10818"
                ],
                "name": "Reshape_10819",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_10819_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10809",
                    "Reshape_10810"
                ],
                "name": "Convolution_10811",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10811_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_10819"
                ],
                "name": "Reshape_10820",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_10820_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_10811"
                ],
                "name": "Reshape_10812",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10812_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10815",
                    "Reshape_10820"
                ],
                "name": "Add_10821",
                "op": "Add",
                "outputs": [
                    "Add_10821_0"
                ]
            },
            {
                "inputs": [
                    "Greater_10807",
                    "Reshape_10812",
                    "Broadcast_10806"
                ],
                "name": "Select_10813",
                "op": "Select",
                "outputs": [
                    "Select_10813_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10801",
            "Parameter_10802",
            "Parameter_10803",
            "Parameter_10804"
        ],
        "result": [
            "Select_10813",
            "Add_10821"
        ]
    }
]