[
    {
        "name": "Function_97",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5560",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5560_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5559",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5559_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5558",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5558_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5557",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5557_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5556",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5556_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_5563",
                "op": "Constant",
                "outputs": [
                    "Constant_5563_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5560"
                ],
                "name": "Reshape_5575",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5575_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5558",
                    "Parameter_5559"
                ],
                "name": "Add_5561",
                "op": "Add",
                "outputs": [
                    "Add_5561_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5557"
                ],
                "name": "Reverse_5567",
                "op": "Reverse",
                "outputs": [
                    "Reverse_5567_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_5556"
                ],
                "name": "Broadcast_5573",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5573_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_5563"
                ],
                "name": "Broadcast_5564",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5564_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_5561"
                ],
                "name": "Reshape_5566",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5566_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_5561"
                ],
                "name": "Reshape_5562",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5562_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_5567"
                ],
                "name": "Reshape_5569",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_5569_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5557",
                    "Broadcast_5573"
                ],
                "name": "Multiply_5574",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5574_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5560",
                    "Broadcast_5564"
                ],
                "name": "Greater_5565",
                "op": "Greater",
                "outputs": [
                    "Greater_5565_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_5566"
                ],
                "name": "Reshape_5568",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5568_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_5566"
                ],
                "name": "Reshape_5576",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5576_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5568",
                    "Reshape_5569"
                ],
                "name": "Convolution_5570",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5570_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5575",
                    "Reshape_5576"
                ],
                "name": "Convolution_5577",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5577_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_5570"
                ],
                "name": "Reshape_5571",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5571_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_5577"
                ],
                "name": "Reshape_5578",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_5578_0"
                ]
            },
            {
                "inputs": [
                    "Greater_5565",
                    "Reshape_5571",
                    "Broadcast_5564"
                ],
                "name": "Select_5572",
                "op": "Select",
                "outputs": [
                    "Select_5572_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_5578"
                ],
                "name": "Reshape_5579",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_5579_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5574",
                    "Reshape_5579"
                ],
                "name": "Add_5580",
                "op": "Add",
                "outputs": [
                    "Add_5580_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5556",
            "Parameter_5557",
            "Parameter_5558",
            "Parameter_5559",
            "Parameter_5560"
        ],
        "result": [
            "Reshape_5562",
            "Select_5572",
            "Add_5580"
        ]
    }
]