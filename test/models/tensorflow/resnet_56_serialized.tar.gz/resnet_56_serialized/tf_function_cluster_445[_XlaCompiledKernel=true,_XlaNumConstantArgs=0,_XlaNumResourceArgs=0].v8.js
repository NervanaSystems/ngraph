[
    {
        "name": "Function_51",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2358",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2358_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2357",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2357_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2356",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2356_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2359",
                "op": "Constant",
                "outputs": [
                    "Constant_2359_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2357"
                ],
                "name": "Reshape_2363",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2363_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2359"
                ],
                "name": "Broadcast_2360",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2360_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2360",
                    "Parameter_2356"
                ],
                "name": "Maximum_2361",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2361_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2361"
                ],
                "name": "Reshape_2362",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2362_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2362",
                    "Reshape_2363"
                ],
                "name": "Convolution_2364",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2364_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2364"
                ],
                "name": "Reshape_2365",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2365_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_2365",
                    "Parameter_2358"
                ],
                "name": "Add_2366",
                "op": "Add",
                "outputs": [
                    "Add_2366_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2356",
            "Parameter_2357",
            "Parameter_2358"
        ],
        "result": [
            "Add_2366",
            "Maximum_2361",
            "Reshape_2365"
        ]
    }
]