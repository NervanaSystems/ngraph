[
    {
        "name": "Function_124",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6810",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6810_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6809",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6809_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6808",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6808_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6808"
                ],
                "name": "Broadcast_6811",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6811_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6809",
                    "Broadcast_6811"
                ],
                "name": "Multiply_6812",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6812_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6812",
                    "Parameter_6810"
                ],
                "name": "Add_6813",
                "op": "Add",
                "outputs": [
                    "Add_6813_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6808",
            "Parameter_6809",
            "Parameter_6810"
        ],
        "result": [
            "Add_6813"
        ]
    }
]