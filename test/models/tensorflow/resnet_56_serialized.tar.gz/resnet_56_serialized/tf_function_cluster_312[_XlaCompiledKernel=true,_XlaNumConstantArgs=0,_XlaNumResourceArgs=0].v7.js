[
    {
        "name": "Function_165",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8825",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8825_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8824",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8824_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8823",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8823_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8823"
                ],
                "name": "Broadcast_8826",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8826_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8824",
                    "Broadcast_8826"
                ],
                "name": "Multiply_8827",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8827_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8827",
                    "Parameter_8825"
                ],
                "name": "Add_8828",
                "op": "Add",
                "outputs": [
                    "Add_8828_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8823",
            "Parameter_8824",
            "Parameter_8825"
        ],
        "result": [
            "Add_8828"
        ]
    }
]