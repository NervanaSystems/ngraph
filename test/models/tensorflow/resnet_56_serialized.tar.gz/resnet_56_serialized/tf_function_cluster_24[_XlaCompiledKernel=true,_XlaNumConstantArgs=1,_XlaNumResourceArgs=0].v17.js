[
    {
        "name": "Function_190",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10030",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10030_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10029",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10029_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10028",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10028_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10027",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10027_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_10031",
                "op": "Constant",
                "outputs": [
                    "Constant_10031_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10030"
                ],
                "name": "Reshape_10043",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10043_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10030"
                ],
                "name": "Reshape_10035",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10035_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10029"
                ],
                "name": "Reshape_10042",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10042_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10028"
                ],
                "name": "Reverse_10034",
                "op": "Reverse",
                "outputs": [
                    "Reverse_10034_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_10027"
                ],
                "name": "Broadcast_10040",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10040_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_10031"
                ],
                "name": "Broadcast_10032",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10032_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10042",
                    "Reshape_10043"
                ],
                "name": "Convolution_10044",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10044_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_10034"
                ],
                "name": "Reshape_10036",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_10036_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10028",
                    "Broadcast_10040"
                ],
                "name": "Multiply_10041",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10041_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10029",
                    "Broadcast_10032"
                ],
                "name": "Greater_10033",
                "op": "Greater",
                "outputs": [
                    "Greater_10033_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_10044"
                ],
                "name": "Reshape_10045",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_10045_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10035",
                    "Reshape_10036"
                ],
                "name": "Convolution_10037",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10037_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_10045"
                ],
                "name": "Reshape_10046",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_10046_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_10037"
                ],
                "name": "Reshape_10038",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10038_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10041",
                    "Reshape_10046"
                ],
                "name": "Add_10047",
                "op": "Add",
                "outputs": [
                    "Add_10047_0"
                ]
            },
            {
                "inputs": [
                    "Greater_10033",
                    "Reshape_10038",
                    "Broadcast_10032"
                ],
                "name": "Select_10039",
                "op": "Select",
                "outputs": [
                    "Select_10039_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10027",
            "Parameter_10028",
            "Parameter_10029",
            "Parameter_10030"
        ],
        "result": [
            "Select_10039",
            "Add_10047"
        ]
    }
]