[
    {
        "name": "Function_122",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6782",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6782_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6781",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6781_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6780",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6780_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6779",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6779_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_6783",
                "op": "Constant",
                "outputs": [
                    "Constant_6783_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6782"
                ],
                "name": "Reshape_6795",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6795_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6782"
                ],
                "name": "Reshape_6787",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6787_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6781"
                ],
                "name": "Reshape_6794",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6794_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6780"
                ],
                "name": "Reverse_6786",
                "op": "Reverse",
                "outputs": [
                    "Reverse_6786_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_6779"
                ],
                "name": "Broadcast_6792",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6792_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_6783"
                ],
                "name": "Broadcast_6784",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6784_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6794",
                    "Reshape_6795"
                ],
                "name": "Convolution_6796",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6796_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_6786"
                ],
                "name": "Reshape_6788",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_6788_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6780",
                    "Broadcast_6792"
                ],
                "name": "Multiply_6793",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6793_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6781",
                    "Broadcast_6784"
                ],
                "name": "Greater_6785",
                "op": "Greater",
                "outputs": [
                    "Greater_6785_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_6796"
                ],
                "name": "Reshape_6797",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_6797_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6787",
                    "Reshape_6788"
                ],
                "name": "Convolution_6789",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6789_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_6797"
                ],
                "name": "Reshape_6798",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_6798_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_6789"
                ],
                "name": "Reshape_6790",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_6790_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6793",
                    "Reshape_6798"
                ],
                "name": "Add_6799",
                "op": "Add",
                "outputs": [
                    "Add_6799_0"
                ]
            },
            {
                "inputs": [
                    "Greater_6785",
                    "Reshape_6790",
                    "Broadcast_6784"
                ],
                "name": "Select_6791",
                "op": "Select",
                "outputs": [
                    "Select_6791_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6779",
            "Parameter_6780",
            "Parameter_6781",
            "Parameter_6782"
        ],
        "result": [
            "Select_6791",
            "Add_6799"
        ]
    }
]