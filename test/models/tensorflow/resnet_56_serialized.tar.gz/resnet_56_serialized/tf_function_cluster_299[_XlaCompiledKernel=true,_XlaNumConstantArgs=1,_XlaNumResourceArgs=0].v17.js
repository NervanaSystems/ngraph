[
    {
        "name": "Function_172",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9137",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9137_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9136",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9136_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9135",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9135_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9134",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9134_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_9138",
                "op": "Constant",
                "outputs": [
                    "Constant_9138_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9137"
                ],
                "name": "Reshape_9142",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9142_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9137"
                ],
                "name": "Reshape_9150",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9150_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9136"
                ],
                "name": "Reshape_9149",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9149_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9135"
                ],
                "name": "Reverse_9141",
                "op": "Reverse",
                "outputs": [
                    "Reverse_9141_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_9134"
                ],
                "name": "Broadcast_9147",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9147_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_9138"
                ],
                "name": "Broadcast_9139",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9139_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9149",
                    "Reshape_9150"
                ],
                "name": "Convolution_9151",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9151_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_9141"
                ],
                "name": "Reshape_9143",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_9143_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9135",
                    "Broadcast_9147"
                ],
                "name": "Multiply_9148",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9148_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9136",
                    "Broadcast_9139"
                ],
                "name": "Greater_9140",
                "op": "Greater",
                "outputs": [
                    "Greater_9140_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_9151"
                ],
                "name": "Reshape_9152",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_9152_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9142",
                    "Reshape_9143"
                ],
                "name": "Convolution_9144",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9144_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_9152"
                ],
                "name": "Reshape_9153",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_9153_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_9144"
                ],
                "name": "Reshape_9145",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9145_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9148",
                    "Reshape_9153"
                ],
                "name": "Add_9154",
                "op": "Add",
                "outputs": [
                    "Add_9154_0"
                ]
            },
            {
                "inputs": [
                    "Greater_9140",
                    "Reshape_9145",
                    "Broadcast_9139"
                ],
                "name": "Select_9146",
                "op": "Select",
                "outputs": [
                    "Select_9146_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9134",
            "Parameter_9135",
            "Parameter_9136",
            "Parameter_9137"
        ],
        "result": [
            "Select_9146",
            "Add_9154"
        ]
    }
]