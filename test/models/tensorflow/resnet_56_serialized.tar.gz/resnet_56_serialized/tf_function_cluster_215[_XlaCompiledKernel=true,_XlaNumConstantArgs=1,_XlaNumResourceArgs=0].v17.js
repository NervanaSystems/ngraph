[
    {
        "name": "Function_105",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5948",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5948_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5947",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5947_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5946",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5946_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5945",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5945_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_5949",
                "op": "Constant",
                "outputs": [
                    "Constant_5949_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5948"
                ],
                "name": "Reshape_5953",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5953_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5948"
                ],
                "name": "Reshape_5961",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5961_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5947"
                ],
                "name": "Reshape_5960",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5960_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5946"
                ],
                "name": "Reverse_5952",
                "op": "Reverse",
                "outputs": [
                    "Reverse_5952_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_5945"
                ],
                "name": "Broadcast_5958",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5958_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_5949"
                ],
                "name": "Broadcast_5950",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5950_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5960",
                    "Reshape_5961"
                ],
                "name": "Convolution_5962",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5962_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_5952"
                ],
                "name": "Reshape_5954",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_5954_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5946",
                    "Broadcast_5958"
                ],
                "name": "Multiply_5959",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5959_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5947",
                    "Broadcast_5950"
                ],
                "name": "Greater_5951",
                "op": "Greater",
                "outputs": [
                    "Greater_5951_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_5962"
                ],
                "name": "Reshape_5963",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_5963_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5953",
                    "Reshape_5954"
                ],
                "name": "Convolution_5955",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5955_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_5963"
                ],
                "name": "Reshape_5964",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_5964_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_5955"
                ],
                "name": "Reshape_5956",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5956_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5959",
                    "Reshape_5964"
                ],
                "name": "Add_5965",
                "op": "Add",
                "outputs": [
                    "Add_5965_0"
                ]
            },
            {
                "inputs": [
                    "Greater_5951",
                    "Reshape_5956",
                    "Broadcast_5950"
                ],
                "name": "Select_5957",
                "op": "Select",
                "outputs": [
                    "Select_5957_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5945",
            "Parameter_5946",
            "Parameter_5947",
            "Parameter_5948"
        ],
        "result": [
            "Select_5957",
            "Add_5965"
        ]
    }
]