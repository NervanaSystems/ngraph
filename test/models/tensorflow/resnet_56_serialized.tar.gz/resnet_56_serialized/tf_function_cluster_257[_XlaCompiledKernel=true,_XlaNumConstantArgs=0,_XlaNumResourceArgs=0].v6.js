[
    {
        "name": "Function_44",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2036",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2036_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2035",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2035_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2037",
                "op": "Constant",
                "outputs": [
                    "Constant_2037_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2036"
                ],
                "name": "Reshape_2041",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2041_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2037"
                ],
                "name": "Broadcast_2038",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2038_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2038",
                    "Parameter_2035"
                ],
                "name": "Maximum_2039",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2039_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2039"
                ],
                "name": "Reshape_2040",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2040_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2040",
                    "Reshape_2041"
                ],
                "name": "Convolution_2042",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2042_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2042"
                ],
                "name": "Reshape_2043",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2043_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2035",
            "Parameter_2036"
        ],
        "result": [
            "Reshape_2043",
            "Maximum_2039"
        ]
    }
]