[
    {
        "name": "Function_217",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11263",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11263_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11262",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11262_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11261",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11261_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_11261"
                ],
                "name": "Broadcast_11264",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11264_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_11262",
                    "Broadcast_11264"
                ],
                "name": "Multiply_11265",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11265_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11265",
                    "Parameter_11263"
                ],
                "name": "Add_11266",
                "op": "Add",
                "outputs": [
                    "Add_11266_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_11261",
            "Parameter_11262",
            "Parameter_11263"
        ],
        "result": [
            "Add_11266"
        ]
    }
]