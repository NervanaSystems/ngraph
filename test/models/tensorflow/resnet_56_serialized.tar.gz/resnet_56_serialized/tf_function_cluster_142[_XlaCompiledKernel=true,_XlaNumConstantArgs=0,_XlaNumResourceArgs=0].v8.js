[
    {
        "name": "Function_29",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1337",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1337_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1336",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1336_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1335",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1335_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1338",
                "op": "Constant",
                "outputs": [
                    "Constant_1338_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1336"
                ],
                "name": "Reshape_1342",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1342_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1338"
                ],
                "name": "Broadcast_1339",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1339_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1339",
                    "Parameter_1335"
                ],
                "name": "Maximum_1340",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1340_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1340"
                ],
                "name": "Reshape_1341",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1341_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1341",
                    "Reshape_1342"
                ],
                "name": "Convolution_1343",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1343_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1343"
                ],
                "name": "Reshape_1344",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1344_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_1344",
                    "Parameter_1337"
                ],
                "name": "Add_1345",
                "op": "Add",
                "outputs": [
                    "Add_1345_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1335",
            "Parameter_1336",
            "Parameter_1337"
        ],
        "result": [
            "Add_1345",
            "Maximum_1340",
            "Reshape_1344"
        ]
    }
]