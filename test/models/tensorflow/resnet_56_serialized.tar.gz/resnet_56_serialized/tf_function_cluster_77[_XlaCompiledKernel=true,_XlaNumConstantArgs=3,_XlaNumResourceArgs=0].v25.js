[
    {
        "name": "Function_161",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8640",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8640_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8639",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8639_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8638",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8638_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8637",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8637_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8636",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8636_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_8643",
                "op": "Constant",
                "outputs": [
                    "Constant_8643_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8640"
                ],
                "name": "Reshape_8655",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8655_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8638",
                    "Parameter_8639"
                ],
                "name": "Add_8641",
                "op": "Add",
                "outputs": [
                    "Add_8641_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8637"
                ],
                "name": "Reverse_8647",
                "op": "Reverse",
                "outputs": [
                    "Reverse_8647_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_8636"
                ],
                "name": "Broadcast_8653",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8653_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_8643"
                ],
                "name": "Broadcast_8644",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8644_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_8641"
                ],
                "name": "Reshape_8642",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8642_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_8641"
                ],
                "name": "Reshape_8646",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8646_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_8647"
                ],
                "name": "Reshape_8649",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_8649_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8637",
                    "Broadcast_8653"
                ],
                "name": "Multiply_8654",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8654_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8640",
                    "Broadcast_8644"
                ],
                "name": "Greater_8645",
                "op": "Greater",
                "outputs": [
                    "Greater_8645_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_8646"
                ],
                "name": "Reshape_8656",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8656_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_8646"
                ],
                "name": "Reshape_8648",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8648_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8655",
                    "Reshape_8656"
                ],
                "name": "Convolution_8657",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8657_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8648",
                    "Reshape_8649"
                ],
                "name": "Convolution_8650",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8650_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_8657"
                ],
                "name": "Reshape_8658",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_8658_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_8650"
                ],
                "name": "Reshape_8651",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8651_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_8658"
                ],
                "name": "Reshape_8659",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_8659_0"
                ]
            },
            {
                "inputs": [
                    "Greater_8645",
                    "Reshape_8651",
                    "Broadcast_8644"
                ],
                "name": "Select_8652",
                "op": "Select",
                "outputs": [
                    "Select_8652_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8654",
                    "Reshape_8659"
                ],
                "name": "Add_8660",
                "op": "Add",
                "outputs": [
                    "Add_8660_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8636",
            "Parameter_8637",
            "Parameter_8638",
            "Parameter_8639",
            "Parameter_8640"
        ],
        "result": [
            "Reshape_8642",
            "Select_8652",
            "Add_8660"
        ]
    }
]