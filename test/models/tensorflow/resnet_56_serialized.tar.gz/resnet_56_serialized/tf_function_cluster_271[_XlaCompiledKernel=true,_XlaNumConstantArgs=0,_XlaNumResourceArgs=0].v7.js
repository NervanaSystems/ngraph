[
    {
        "name": "Function_170",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9087",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9087_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9086",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9086_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9085",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9085_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9085"
                ],
                "name": "Broadcast_9088",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9088_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9086",
                    "Broadcast_9088"
                ],
                "name": "Multiply_9089",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9089_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9089",
                    "Parameter_9087"
                ],
                "name": "Add_9090",
                "op": "Add",
                "outputs": [
                    "Add_9090_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9085",
            "Parameter_9086",
            "Parameter_9087"
        ],
        "result": [
            "Add_9090"
        ]
    }
]