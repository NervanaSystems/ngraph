[
    {
        "name": "Function_207",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10825",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10825_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10824",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10824_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10823",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10823_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10823"
                ],
                "name": "Broadcast_10826",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10826_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10824",
                    "Broadcast_10826"
                ],
                "name": "Multiply_10827",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10827_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10827",
                    "Parameter_10825"
                ],
                "name": "Add_10828",
                "op": "Add",
                "outputs": [
                    "Add_10828_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10823",
            "Parameter_10824",
            "Parameter_10825"
        ],
        "result": [
            "Add_10828"
        ]
    }
]