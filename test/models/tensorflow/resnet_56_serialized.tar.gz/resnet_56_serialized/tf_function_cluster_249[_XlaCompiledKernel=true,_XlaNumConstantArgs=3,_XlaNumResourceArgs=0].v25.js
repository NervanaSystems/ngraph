[
    {
        "name": "Function_175",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9244",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9244_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9243",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9243_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9242",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9242_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9241",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9241_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9240",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9240_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_9245",
                "op": "Constant",
                "outputs": [
                    "Constant_9245_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9244"
                ],
                "name": "Reshape_9259",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9259_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9242",
                    "Parameter_9243"
                ],
                "name": "Add_9248",
                "op": "Add",
                "outputs": [
                    "Add_9248_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9241"
                ],
                "name": "Reverse_9250",
                "op": "Reverse",
                "outputs": [
                    "Reverse_9250_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_9240"
                ],
                "name": "Broadcast_9257",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9257_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_9245"
                ],
                "name": "Broadcast_9246",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9246_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_9248"
                ],
                "name": "Reshape_9256",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9256_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_9248"
                ],
                "name": "Reshape_9249",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9249_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_9250"
                ],
                "name": "Reshape_9252",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_9252_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9241",
                    "Broadcast_9257"
                ],
                "name": "Multiply_9258",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9258_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9244",
                    "Broadcast_9246"
                ],
                "name": "Greater_9247",
                "op": "Greater",
                "outputs": [
                    "Greater_9247_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_9249"
                ],
                "name": "Reshape_9260",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9260_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_9249"
                ],
                "name": "Reshape_9251",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9251_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9259",
                    "Reshape_9260"
                ],
                "name": "Convolution_9261",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9261_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9251",
                    "Reshape_9252"
                ],
                "name": "Convolution_9253",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9253_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_9261"
                ],
                "name": "Reshape_9262",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_9262_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_9253"
                ],
                "name": "Reshape_9254",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9254_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_9262"
                ],
                "name": "Reshape_9263",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_9263_0"
                ]
            },
            {
                "inputs": [
                    "Greater_9247",
                    "Reshape_9254",
                    "Broadcast_9246"
                ],
                "name": "Select_9255",
                "op": "Select",
                "outputs": [
                    "Select_9255_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9258",
                    "Reshape_9263"
                ],
                "name": "Add_9264",
                "op": "Add",
                "outputs": [
                    "Add_9264_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9240",
            "Parameter_9241",
            "Parameter_9242",
            "Parameter_9243",
            "Parameter_9244"
        ],
        "result": [
            "Select_9255",
            "Reshape_9256",
            "Add_9264"
        ]
    }
]