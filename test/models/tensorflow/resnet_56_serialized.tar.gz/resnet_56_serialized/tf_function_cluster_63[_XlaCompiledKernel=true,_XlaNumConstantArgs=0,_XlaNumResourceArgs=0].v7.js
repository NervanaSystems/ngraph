[
    {
        "name": "Function_63",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3910",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3910_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3909",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3909_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3908",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3908_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_3908"
                ],
                "name": "Broadcast_3911",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3911_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_3909",
                    "Broadcast_3911"
                ],
                "name": "Multiply_3912",
                "op": "Multiply",
                "outputs": [
                    "Multiply_3912_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_3912",
                    "Parameter_3910"
                ],
                "name": "Add_3913",
                "op": "Add",
                "outputs": [
                    "Add_3913_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_3908",
            "Parameter_3909",
            "Parameter_3910"
        ],
        "result": [
            "Add_3913"
        ]
    }
]