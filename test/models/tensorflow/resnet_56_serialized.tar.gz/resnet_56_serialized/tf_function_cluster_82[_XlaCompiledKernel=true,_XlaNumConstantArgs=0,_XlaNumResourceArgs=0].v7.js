[
    {
        "name": "Function_167",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8944",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8944_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8943",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8943_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8942",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8942_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8942"
                ],
                "name": "Broadcast_8945",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8945_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_8943",
                    "Broadcast_8945"
                ],
                "name": "Multiply_8946",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8946_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8946",
                    "Parameter_8944"
                ],
                "name": "Add_8947",
                "op": "Add",
                "outputs": [
                    "Add_8947_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8942",
            "Parameter_8943",
            "Parameter_8944"
        ],
        "result": [
            "Add_8947"
        ]
    }
]