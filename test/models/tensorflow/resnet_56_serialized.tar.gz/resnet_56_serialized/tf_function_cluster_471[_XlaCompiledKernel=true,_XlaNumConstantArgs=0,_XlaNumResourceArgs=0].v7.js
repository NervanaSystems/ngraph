[
    {
        "name": "Function_96",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5481",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5481_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5480",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5480_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5479",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5479_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5479"
                ],
                "name": "Broadcast_5482",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5482_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5480",
                    "Broadcast_5482"
                ],
                "name": "Multiply_5483",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5483_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5483",
                    "Parameter_5481"
                ],
                "name": "Add_5484",
                "op": "Add",
                "outputs": [
                    "Add_5484_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5479",
            "Parameter_5480",
            "Parameter_5481"
        ],
        "result": [
            "Add_5484"
        ]
    }
]