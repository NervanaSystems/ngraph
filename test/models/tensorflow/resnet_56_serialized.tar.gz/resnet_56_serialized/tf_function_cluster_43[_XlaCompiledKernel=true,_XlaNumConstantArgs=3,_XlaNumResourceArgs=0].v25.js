[
    {
        "name": "Function_65",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4046",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4046_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4045",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4045_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4044",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4044_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4043",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4043_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4042",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4042_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_4047",
                "op": "Constant",
                "outputs": [
                    "Constant_4047_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4046"
                ],
                "name": "Reshape_4061",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4061_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4044",
                    "Parameter_4045"
                ],
                "name": "Add_4050",
                "op": "Add",
                "outputs": [
                    "Add_4050_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4043"
                ],
                "name": "Reverse_4052",
                "op": "Reverse",
                "outputs": [
                    "Reverse_4052_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_4042"
                ],
                "name": "Broadcast_4059",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4059_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_4047"
                ],
                "name": "Broadcast_4048",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4048_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_4050"
                ],
                "name": "Reshape_4051",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4051_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_4050"
                ],
                "name": "Reshape_4058",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4058_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_4052"
                ],
                "name": "Reshape_4054",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_4054_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4043",
                    "Broadcast_4059"
                ],
                "name": "Multiply_4060",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4060_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4046",
                    "Broadcast_4048"
                ],
                "name": "Greater_4049",
                "op": "Greater",
                "outputs": [
                    "Greater_4049_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_4051"
                ],
                "name": "Reshape_4062",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4062_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_4051"
                ],
                "name": "Reshape_4053",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4053_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4061",
                    "Reshape_4062"
                ],
                "name": "Convolution_4063",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4063_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4053",
                    "Reshape_4054"
                ],
                "name": "Convolution_4055",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4055_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_4063"
                ],
                "name": "Reshape_4064",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_4064_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_4055"
                ],
                "name": "Reshape_4056",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4056_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_4064"
                ],
                "name": "Reshape_4065",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_4065_0"
                ]
            },
            {
                "inputs": [
                    "Greater_4049",
                    "Reshape_4056",
                    "Broadcast_4048"
                ],
                "name": "Select_4057",
                "op": "Select",
                "outputs": [
                    "Select_4057_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4060",
                    "Reshape_4065"
                ],
                "name": "Add_4066",
                "op": "Add",
                "outputs": [
                    "Add_4066_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4042",
            "Parameter_4043",
            "Parameter_4044",
            "Parameter_4045",
            "Parameter_4046"
        ],
        "result": [
            "Select_4057",
            "Reshape_4058",
            "Add_4066"
        ]
    }
]