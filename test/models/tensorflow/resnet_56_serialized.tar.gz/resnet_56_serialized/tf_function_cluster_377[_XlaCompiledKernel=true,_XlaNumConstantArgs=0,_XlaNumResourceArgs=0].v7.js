[
    {
        "name": "Function_88",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5146",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5146_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5145",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5145_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5144",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5144_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5144"
                ],
                "name": "Broadcast_5147",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5147_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5145",
                    "Broadcast_5147"
                ],
                "name": "Multiply_5148",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5148_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5148",
                    "Parameter_5146"
                ],
                "name": "Add_5149",
                "op": "Add",
                "outputs": [
                    "Add_5149_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5144",
            "Parameter_5145",
            "Parameter_5146"
        ],
        "result": [
            "Add_5149"
        ]
    }
]