[
    {
        "name": "Function_186",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9809",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9809_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9808",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9808_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9807",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9807_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9806",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9806_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9805",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9805_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_9812",
                "op": "Constant",
                "outputs": [
                    "Constant_9812_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9809"
                ],
                "name": "Reshape_9824",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9824_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9807",
                    "Parameter_9808"
                ],
                "name": "Add_9810",
                "op": "Add",
                "outputs": [
                    "Add_9810_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9806"
                ],
                "name": "Reverse_9816",
                "op": "Reverse",
                "outputs": [
                    "Reverse_9816_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_9805"
                ],
                "name": "Broadcast_9822",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9822_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_9812"
                ],
                "name": "Broadcast_9813",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9813_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_9810"
                ],
                "name": "Reshape_9815",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9815_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_9810"
                ],
                "name": "Reshape_9811",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9811_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_9816"
                ],
                "name": "Reshape_9818",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_9818_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9806",
                    "Broadcast_9822"
                ],
                "name": "Multiply_9823",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9823_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9809",
                    "Broadcast_9813"
                ],
                "name": "Greater_9814",
                "op": "Greater",
                "outputs": [
                    "Greater_9814_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_9815"
                ],
                "name": "Reshape_9825",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9825_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_9815"
                ],
                "name": "Reshape_9817",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9817_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9824",
                    "Reshape_9825"
                ],
                "name": "Convolution_9826",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9826_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9817",
                    "Reshape_9818"
                ],
                "name": "Convolution_9819",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9819_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_9826"
                ],
                "name": "Reshape_9827",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_9827_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_9819"
                ],
                "name": "Reshape_9820",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9820_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_9827"
                ],
                "name": "Reshape_9828",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_9828_0"
                ]
            },
            {
                "inputs": [
                    "Greater_9814",
                    "Reshape_9820",
                    "Broadcast_9813"
                ],
                "name": "Select_9821",
                "op": "Select",
                "outputs": [
                    "Select_9821_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9823",
                    "Reshape_9828"
                ],
                "name": "Add_9829",
                "op": "Add",
                "outputs": [
                    "Add_9829_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9805",
            "Parameter_9806",
            "Parameter_9807",
            "Parameter_9808",
            "Parameter_9809"
        ],
        "result": [
            "Reshape_9811",
            "Select_9821",
            "Add_9829"
        ]
    }
]