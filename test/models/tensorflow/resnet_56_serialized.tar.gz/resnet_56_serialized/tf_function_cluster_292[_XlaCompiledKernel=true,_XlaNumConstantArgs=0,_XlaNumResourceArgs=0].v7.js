[
    {
        "name": "Function_145",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7822",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7822_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7820",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7820_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7818",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7818_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7818"
                ],
                "name": "Broadcast_7826",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7826_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7820",
                    "Broadcast_7826"
                ],
                "name": "Multiply_7829",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7829_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7829",
                    "Parameter_7822"
                ],
                "name": "Add_7836",
                "op": "Add",
                "outputs": [
                    "Add_7836_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7818",
            "Parameter_7820",
            "Parameter_7822"
        ],
        "result": [
            "Add_7836"
        ]
    }
]