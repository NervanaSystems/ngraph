[
    {
        "name": "Function_67",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4077",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4077_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4076",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4076_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4075",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4075_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4075"
                ],
                "name": "Broadcast_4078",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4078_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4076",
                    "Broadcast_4078"
                ],
                "name": "Multiply_4079",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4079_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4079",
                    "Parameter_4077"
                ],
                "name": "Add_4080",
                "op": "Add",
                "outputs": [
                    "Add_4080_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4075",
            "Parameter_4076",
            "Parameter_4077"
        ],
        "result": [
            "Add_4080"
        ]
    }
]