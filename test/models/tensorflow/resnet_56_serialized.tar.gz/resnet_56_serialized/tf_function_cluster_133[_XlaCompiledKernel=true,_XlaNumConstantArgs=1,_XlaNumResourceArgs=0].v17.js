[
    {
        "name": "Function_146",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7926",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7926_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7925",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7925_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7924",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7924_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7923",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7923_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_7927",
                "op": "Constant",
                "outputs": [
                    "Constant_7927_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7926"
                ],
                "name": "Reshape_7939",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7939_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7926"
                ],
                "name": "Reshape_7931",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7931_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7925"
                ],
                "name": "Reshape_7938",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7938_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7924"
                ],
                "name": "Reverse_7930",
                "op": "Reverse",
                "outputs": [
                    "Reverse_7930_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_7923"
                ],
                "name": "Broadcast_7936",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7936_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_7927"
                ],
                "name": "Broadcast_7928",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7928_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7938",
                    "Reshape_7939"
                ],
                "name": "Convolution_7940",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7940_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_7930"
                ],
                "name": "Reshape_7932",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_7932_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7924",
                    "Broadcast_7936"
                ],
                "name": "Multiply_7937",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7937_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7925",
                    "Broadcast_7928"
                ],
                "name": "Greater_7929",
                "op": "Greater",
                "outputs": [
                    "Greater_7929_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_7940"
                ],
                "name": "Reshape_7941",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_7941_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7931",
                    "Reshape_7932"
                ],
                "name": "Convolution_7933",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7933_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_7941"
                ],
                "name": "Reshape_7942",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_7942_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_7933"
                ],
                "name": "Reshape_7934",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7934_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7937",
                    "Reshape_7942"
                ],
                "name": "Add_7943",
                "op": "Add",
                "outputs": [
                    "Add_7943_0"
                ]
            },
            {
                "inputs": [
                    "Greater_7929",
                    "Reshape_7934",
                    "Broadcast_7928"
                ],
                "name": "Select_7935",
                "op": "Select",
                "outputs": [
                    "Select_7935_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7923",
            "Parameter_7924",
            "Parameter_7925",
            "Parameter_7926"
        ],
        "result": [
            "Select_7935",
            "Add_7943"
        ]
    }
]