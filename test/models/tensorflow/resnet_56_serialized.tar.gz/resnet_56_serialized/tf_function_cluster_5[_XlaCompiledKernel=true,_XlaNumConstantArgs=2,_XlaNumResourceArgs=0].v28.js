[
    {
        "name": "Function_218",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11378",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11378_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11377",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11377_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11376",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11376_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11375",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11375_0"
                ],
                "shape": [
                    1,
                    1,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11374",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11374_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11373",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11373_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_11379",
                "op": "Constant",
                "outputs": [
                    "Constant_11379_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11378"
                ],
                "name": "Reshape_11397",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11397_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11378"
                ],
                "name": "Reshape_11388",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11388_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11377"
                ],
                "name": "Reshape_11396",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11396_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11377"
                ],
                "name": "Reshape_11405",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11405_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11376"
                ],
                "name": "Reshape_11406",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11406_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11376"
                ],
                "name": "Reshape_11383",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11383_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_11375"
                ],
                "name": "Reverse_11382",
                "op": "Reverse",
                "outputs": [
                    "Reverse_11382_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "inputs": [
                    "Parameter_11374"
                ],
                "name": "Reverse_11387",
                "op": "Reverse",
                "outputs": [
                    "Reverse_11387_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_11373"
                ],
                "name": "Broadcast_11394",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11394_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "input_order": [],
                "inputs": [
                    "Parameter_11373"
                ],
                "name": "Reshape_11402",
                "op": "Reshape",
                "output_shape": [
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_11402_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_11379"
                ],
                "name": "Broadcast_11380",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11380_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11396",
                    "Reshape_11397"
                ],
                "name": "Convolution_11398",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11398_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11405",
                    "Reshape_11406"
                ],
                "name": "Convolution_11407",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11407_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_11382"
                ],
                "name": "Reshape_11384",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_11384_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_11387"
                ],
                "name": "Reshape_11389",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_11389_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_11374",
                    "Broadcast_11394"
                ],
                "name": "Multiply_11395",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11395_0"
                ]
            },
            {
                "axes": [
                    2,
                    3
                ],
                "inputs": [
                    "Reshape_11402"
                ],
                "name": "Broadcast_11403",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11403_0"
                ],
                "shape": [
                    1,
                    1,
                    16,
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_11377",
                    "Broadcast_11380"
                ],
                "name": "Greater_11381",
                "op": "Greater",
                "outputs": [
                    "Greater_11381_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_11398"
                ],
                "name": "Reshape_11399",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_11399_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_11407"
                ],
                "name": "Reshape_11408",
                "op": "Reshape",
                "output_shape": [
                    16,
                    1,
                    1,
                    16
                ],
                "outputs": [
                    "Reshape_11408_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11383",
                    "Reshape_11384"
                ],
                "name": "Convolution_11385",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11385_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11388",
                    "Reshape_11389"
                ],
                "name": "Convolution_11390",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11390_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "inputs": [
                    "Parameter_11375",
                    "Broadcast_11403"
                ],
                "name": "Multiply_11404",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11404_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_11399"
                ],
                "name": "Reshape_11400",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_11400_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_11408"
                ],
                "name": "Reshape_11409",
                "op": "Reshape",
                "output_shape": [
                    1,
                    1,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_11409_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_11385"
                ],
                "name": "Reshape_11386",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_11386_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_11390"
                ],
                "name": "Reshape_11391",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_11391_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11395",
                    "Reshape_11400"
                ],
                "name": "Add_11401",
                "op": "Add",
                "outputs": [
                    "Add_11401_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11404",
                    "Reshape_11409"
                ],
                "name": "Add_11410",
                "op": "Add",
                "outputs": [
                    "Add_11410_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_11386",
                    "Reshape_11391"
                ],
                "name": "Add_11392",
                "op": "Add",
                "outputs": [
                    "Add_11392_0"
                ]
            },
            {
                "inputs": [
                    "Greater_11381",
                    "Add_11392",
                    "Broadcast_11380"
                ],
                "name": "Select_11393",
                "op": "Select",
                "outputs": [
                    "Select_11393_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_11373",
            "Parameter_11374",
            "Parameter_11375",
            "Parameter_11376",
            "Parameter_11377",
            "Parameter_11378"
        ],
        "result": [
            "Select_11393",
            "Add_11401",
            "Add_11410"
        ]
    }
]