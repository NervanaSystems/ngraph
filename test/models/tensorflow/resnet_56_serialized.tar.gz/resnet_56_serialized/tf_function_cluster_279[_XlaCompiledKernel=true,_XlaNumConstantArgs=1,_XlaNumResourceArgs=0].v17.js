[
    {
        "name": "Function_128",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7068",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7068_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7067",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7067_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7066",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7066_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7065",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7065_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_7069",
                "op": "Constant",
                "outputs": [
                    "Constant_7069_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7068"
                ],
                "name": "Reshape_7073",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7073_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7068"
                ],
                "name": "Reshape_7081",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7081_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7067"
                ],
                "name": "Reshape_7080",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7080_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7066"
                ],
                "name": "Reverse_7072",
                "op": "Reverse",
                "outputs": [
                    "Reverse_7072_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_7065"
                ],
                "name": "Broadcast_7078",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7078_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_7069"
                ],
                "name": "Broadcast_7070",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7070_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7080",
                    "Reshape_7081"
                ],
                "name": "Convolution_7082",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7082_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_7072"
                ],
                "name": "Reshape_7074",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_7074_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7066",
                    "Broadcast_7078"
                ],
                "name": "Multiply_7079",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7079_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7067",
                    "Broadcast_7070"
                ],
                "name": "Greater_7071",
                "op": "Greater",
                "outputs": [
                    "Greater_7071_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_7082"
                ],
                "name": "Reshape_7083",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_7083_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7073",
                    "Reshape_7074"
                ],
                "name": "Convolution_7075",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7075_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_7083"
                ],
                "name": "Reshape_7084",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_7084_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_7075"
                ],
                "name": "Reshape_7076",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7076_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7079",
                    "Reshape_7084"
                ],
                "name": "Add_7085",
                "op": "Add",
                "outputs": [
                    "Add_7085_0"
                ]
            },
            {
                "inputs": [
                    "Greater_7071",
                    "Reshape_7076",
                    "Broadcast_7070"
                ],
                "name": "Select_7077",
                "op": "Select",
                "outputs": [
                    "Select_7077_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7065",
            "Parameter_7066",
            "Parameter_7067",
            "Parameter_7068"
        ],
        "result": [
            "Select_7077",
            "Add_7085"
        ]
    }
]