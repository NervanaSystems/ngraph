[
    {
        "name": "Function_83",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4902",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4902_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4901",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4901_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4900",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4900_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4900"
                ],
                "name": "Broadcast_4903",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4903_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4901",
                    "Broadcast_4903"
                ],
                "name": "Multiply_4904",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4904_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4904",
                    "Parameter_4902"
                ],
                "name": "Add_4905",
                "op": "Add",
                "outputs": [
                    "Add_4905_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4900",
            "Parameter_4901",
            "Parameter_4902"
        ],
        "result": [
            "Add_4905"
        ]
    }
]