[
    {
        "name": "Function_141",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7647",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7647_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7646",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7646_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7645",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7645_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7644",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7644_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_7648",
                "op": "Constant",
                "outputs": [
                    "Constant_7648_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7647"
                ],
                "name": "Reshape_7652",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7652_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7647"
                ],
                "name": "Reshape_7660",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7660_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7646"
                ],
                "name": "Reshape_7659",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7659_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7645"
                ],
                "name": "Reverse_7651",
                "op": "Reverse",
                "outputs": [
                    "Reverse_7651_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_7644"
                ],
                "name": "Broadcast_7657",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7657_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_7648"
                ],
                "name": "Broadcast_7649",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7649_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7659",
                    "Reshape_7660"
                ],
                "name": "Convolution_7661",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7661_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_7651"
                ],
                "name": "Reshape_7653",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_7653_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7645",
                    "Broadcast_7657"
                ],
                "name": "Multiply_7658",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7658_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7646",
                    "Broadcast_7649"
                ],
                "name": "Greater_7650",
                "op": "Greater",
                "outputs": [
                    "Greater_7650_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_7661"
                ],
                "name": "Reshape_7662",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_7662_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7652",
                    "Reshape_7653"
                ],
                "name": "Convolution_7654",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7654_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_7662"
                ],
                "name": "Reshape_7663",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_7663_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_7654"
                ],
                "name": "Reshape_7655",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7655_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7658",
                    "Reshape_7663"
                ],
                "name": "Add_7664",
                "op": "Add",
                "outputs": [
                    "Add_7664_0"
                ]
            },
            {
                "inputs": [
                    "Greater_7650",
                    "Reshape_7655",
                    "Broadcast_7649"
                ],
                "name": "Select_7656",
                "op": "Select",
                "outputs": [
                    "Select_7656_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7644",
            "Parameter_7645",
            "Parameter_7646",
            "Parameter_7647"
        ],
        "result": [
            "Select_7656",
            "Add_7664"
        ]
    }
]