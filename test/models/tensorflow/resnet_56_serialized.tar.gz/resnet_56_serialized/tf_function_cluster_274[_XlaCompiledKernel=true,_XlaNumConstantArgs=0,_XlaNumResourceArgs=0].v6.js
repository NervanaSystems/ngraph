[
    {
        "name": "Function_14",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_638",
                "op": "Parameter",
                "outputs": [
                    "Parameter_638_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_637",
                "op": "Parameter",
                "outputs": [
                    "Parameter_637_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_639",
                "op": "Constant",
                "outputs": [
                    "Constant_639_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_638"
                ],
                "name": "Reshape_643",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_643_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_639"
                ],
                "name": "Broadcast_640",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_640_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_640",
                    "Parameter_637"
                ],
                "name": "Maximum_641",
                "op": "Maximum",
                "outputs": [
                    "Maximum_641_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_641"
                ],
                "name": "Reshape_642",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_642_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_642",
                    "Reshape_643"
                ],
                "name": "Convolution_644",
                "op": "Convolution",
                "outputs": [
                    "Convolution_644_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_644"
                ],
                "name": "Reshape_645",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_645_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_637",
            "Parameter_638"
        ],
        "result": [
            "Reshape_645",
            "Maximum_641"
        ]
    }
]