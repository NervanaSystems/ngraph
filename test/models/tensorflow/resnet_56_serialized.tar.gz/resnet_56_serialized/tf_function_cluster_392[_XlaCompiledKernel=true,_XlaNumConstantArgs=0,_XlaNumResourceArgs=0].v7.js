[
    {
        "name": "Function_181",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9582",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9582_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9581",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9581_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9580",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9580_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9580"
                ],
                "name": "Broadcast_9583",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9583_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9581",
                    "Broadcast_9583"
                ],
                "name": "Multiply_9584",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9584_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9584",
                    "Parameter_9582"
                ],
                "name": "Add_9585",
                "op": "Add",
                "outputs": [
                    "Add_9585_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9580",
            "Parameter_9581",
            "Parameter_9582"
        ],
        "result": [
            "Add_9585"
        ]
    }
]