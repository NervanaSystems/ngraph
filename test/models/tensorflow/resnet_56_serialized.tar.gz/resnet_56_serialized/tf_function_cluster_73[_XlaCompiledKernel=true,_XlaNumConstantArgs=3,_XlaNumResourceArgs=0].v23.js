[
    {
        "name": "Function_168",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8952",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8952_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8951",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8951_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8950",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8950_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8949",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8949_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_8953",
                "op": "Constant",
                "outputs": [
                    "Constant_8953_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8952"
                ],
                "name": "Reshape_8966",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_8966_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_8951"
                ],
                "name": "Reshape_8956",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_8956_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_8951"
                ],
                "name": "Reshape_8963",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_8963_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8950"
                ],
                "name": "Reverse_8957",
                "op": "Reverse",
                "outputs": [
                    "Reverse_8957_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_8949"
                ],
                "name": "Broadcast_8964",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8964_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_8953"
                ],
                "name": "Broadcast_8954",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8954_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_8956"
                ],
                "name": "Reshape_8967",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_8967_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_8956"
                ],
                "name": "Reshape_8958",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_8958_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_8957"
                ],
                "name": "Reshape_8959",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_8959_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8950",
                    "Broadcast_8964"
                ],
                "name": "Multiply_8965",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8965_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8952",
                    "Broadcast_8954"
                ],
                "name": "Greater_8955",
                "op": "Greater",
                "outputs": [
                    "Greater_8955_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8966",
                    "Reshape_8967"
                ],
                "name": "Convolution_8968",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8968_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8958",
                    "Reshape_8959"
                ],
                "name": "Convolution_8960",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8960_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_8968"
                ],
                "name": "Reshape_8969",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_8969_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_8960"
                ],
                "name": "Reshape_8961",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_8961_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_8969"
                ],
                "name": "Reshape_8970",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8970_0"
                ]
            },
            {
                "inputs": [
                    "Greater_8955",
                    "Reshape_8961",
                    "Broadcast_8954"
                ],
                "name": "Select_8962",
                "op": "Select",
                "outputs": [
                    "Select_8962_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8965",
                    "Reshape_8970"
                ],
                "name": "Add_8971",
                "op": "Add",
                "outputs": [
                    "Add_8971_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8949",
            "Parameter_8950",
            "Parameter_8951",
            "Parameter_8952"
        ],
        "result": [
            "Select_8962",
            "Reshape_8963",
            "Add_8971"
        ]
    }
]