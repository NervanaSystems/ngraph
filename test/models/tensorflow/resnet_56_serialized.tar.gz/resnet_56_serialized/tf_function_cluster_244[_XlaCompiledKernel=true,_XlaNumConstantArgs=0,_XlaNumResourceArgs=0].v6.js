[
    {
        "name": "Function_54",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2496",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2496_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2495",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2495_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2497",
                "op": "Constant",
                "outputs": [
                    "Constant_2497_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2496"
                ],
                "name": "Reshape_2501",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2501_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2497"
                ],
                "name": "Broadcast_2498",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2498_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2498",
                    "Parameter_2495"
                ],
                "name": "Maximum_2499",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2499_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2499"
                ],
                "name": "Reshape_2500",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2500_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2500",
                    "Reshape_2501"
                ],
                "name": "Convolution_2502",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2502_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2502"
                ],
                "name": "Reshape_2503",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2503_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2495",
            "Parameter_2496"
        ],
        "result": [
            "Reshape_2503",
            "Maximum_2499"
        ]
    }
]