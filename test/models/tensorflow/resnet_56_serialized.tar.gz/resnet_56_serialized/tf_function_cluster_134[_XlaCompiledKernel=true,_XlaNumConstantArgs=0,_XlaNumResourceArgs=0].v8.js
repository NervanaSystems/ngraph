[
    {
        "name": "Function_33",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1521",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1521_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1520",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1520_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1519",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1519_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1522",
                "op": "Constant",
                "outputs": [
                    "Constant_1522_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1520"
                ],
                "name": "Reshape_1526",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1526_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1522"
                ],
                "name": "Broadcast_1523",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1523_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1523",
                    "Parameter_1519"
                ],
                "name": "Maximum_1524",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1524_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1524"
                ],
                "name": "Reshape_1525",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1525_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1525",
                    "Reshape_1526"
                ],
                "name": "Convolution_1527",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1527_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1527"
                ],
                "name": "Reshape_1528",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1528_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_1528",
                    "Parameter_1521"
                ],
                "name": "Add_1529",
                "op": "Add",
                "outputs": [
                    "Add_1529_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1519",
            "Parameter_1520",
            "Parameter_1521"
        ],
        "result": [
            "Add_1529",
            "Maximum_1524",
            "Reshape_1528"
        ]
    }
]