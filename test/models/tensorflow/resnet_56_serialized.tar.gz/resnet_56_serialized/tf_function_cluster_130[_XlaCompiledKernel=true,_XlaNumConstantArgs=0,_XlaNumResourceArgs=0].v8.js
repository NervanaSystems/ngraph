[
    {
        "name": "Function_35",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1613",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1613_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1612",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1612_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1611",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1611_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1614",
                "op": "Constant",
                "outputs": [
                    "Constant_1614_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1612"
                ],
                "name": "Reshape_1618",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1618_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1614"
                ],
                "name": "Broadcast_1615",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1615_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1615",
                    "Parameter_1611"
                ],
                "name": "Maximum_1616",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1616_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1616"
                ],
                "name": "Reshape_1617",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1617_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1617",
                    "Reshape_1618"
                ],
                "name": "Convolution_1619",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1619_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1619"
                ],
                "name": "Reshape_1620",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1620_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_1620",
                    "Parameter_1613"
                ],
                "name": "Add_1621",
                "op": "Add",
                "outputs": [
                    "Add_1621_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1611",
            "Parameter_1612",
            "Parameter_1613"
        ],
        "result": [
            "Add_1621",
            "Maximum_1616",
            "Reshape_1620"
        ]
    }
]