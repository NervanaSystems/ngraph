[
    {
        "name": "Function_38",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1751",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1751_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1750",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1750_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1755",
                "op": "Constant",
                "outputs": [
                    "Constant_1755_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1752",
                "op": "Constant",
                "outputs": [
                    "Constant_1752_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1751"
                ],
                "name": "Reshape_1758",
                "op": "Reshape",
                "output_shape": [
                    64,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1758_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1752"
                ],
                "name": "Broadcast_1753",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1753_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1753",
                    "Parameter_1750"
                ],
                "name": "Maximum_1754",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1754_0"
                ]
            },
            {
                "inputs": [
                    "Maximum_1754",
                    "Constant_1755"
                ],
                "name": "Pad_1756",
                "op": "Pad",
                "outputs": [
                    "Pad_1756_0"
                ],
                "padding_above": [
                    0,
                    1,
                    1,
                    0
                ],
                "padding_below": [
                    0,
                    1,
                    1,
                    0
                ],
                "padding_interior": [
                    0,
                    0,
                    0,
                    0
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Pad_1756"
                ],
                "name": "Reshape_1757",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    18,
                    18
                ],
                "outputs": [
                    "Reshape_1757_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1757",
                    "Reshape_1758"
                ],
                "name": "Convolution_1759",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1759_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    2,
                    2
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1759"
                ],
                "name": "Reshape_1760",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_1760_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1750",
            "Parameter_1751"
        ],
        "result": [
            "Reshape_1760",
            "Maximum_1754",
            "Pad_1756"
        ]
    }
]