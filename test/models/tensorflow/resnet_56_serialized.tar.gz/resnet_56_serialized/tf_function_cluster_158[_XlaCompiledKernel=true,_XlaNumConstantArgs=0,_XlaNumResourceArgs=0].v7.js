[
    {
        "name": "Function_192",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10093",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10093_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10092",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10092_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10091",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10091_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10091"
                ],
                "name": "Broadcast_10094",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10094_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10092",
                    "Broadcast_10094"
                ],
                "name": "Multiply_10095",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10095_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10095",
                    "Parameter_10093"
                ],
                "name": "Add_10096",
                "op": "Add",
                "outputs": [
                    "Add_10096_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10091",
            "Parameter_10092",
            "Parameter_10093"
        ],
        "result": [
            "Add_10096"
        ]
    }
]