[
    {
        "name": "Function_40",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1852",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1852_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1851",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1851_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1853",
                "op": "Constant",
                "outputs": [
                    "Constant_1853_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1852"
                ],
                "name": "Reshape_1857",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1857_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1853"
                ],
                "name": "Broadcast_1854",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1854_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_1854",
                    "Parameter_1851"
                ],
                "name": "Maximum_1855",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1855_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1855"
                ],
                "name": "Reshape_1856",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_1856_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1856",
                    "Reshape_1857"
                ],
                "name": "Convolution_1858",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1858_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1858"
                ],
                "name": "Reshape_1859",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_1859_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1851",
            "Parameter_1852"
        ],
        "result": [
            "Reshape_1859",
            "Maximum_1855"
        ]
    }
]