[
    {
        "name": "Function_72",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4372",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4372_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4371",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4371_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4370",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4370_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4370"
                ],
                "name": "Broadcast_4373",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4373_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4371",
                    "Broadcast_4373"
                ],
                "name": "Multiply_4374",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4374_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4374",
                    "Parameter_4372"
                ],
                "name": "Add_4375",
                "op": "Add",
                "outputs": [
                    "Add_4375_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4370",
            "Parameter_4371",
            "Parameter_4372"
        ],
        "result": [
            "Add_4375"
        ]
    }
]