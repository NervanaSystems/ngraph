[
    {
        "name": "Function_100",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5690",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5690_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5687",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5687_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5682",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5682_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5682"
                ],
                "name": "Broadcast_5697",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5697_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5687",
                    "Broadcast_5697"
                ],
                "name": "Multiply_5700",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5700_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5700",
                    "Parameter_5690"
                ],
                "name": "Add_5709",
                "op": "Add",
                "outputs": [
                    "Add_5709_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5682",
            "Parameter_5687",
            "Parameter_5690"
        ],
        "result": [
            "Add_5709"
        ]
    }
]