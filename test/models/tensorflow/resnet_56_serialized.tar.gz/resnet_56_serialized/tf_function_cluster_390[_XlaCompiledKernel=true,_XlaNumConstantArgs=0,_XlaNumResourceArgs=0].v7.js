[
    {
        "name": "Function_98",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5619",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5619_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5618",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5618_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5617",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5617_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5617"
                ],
                "name": "Broadcast_5620",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5620_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5618",
                    "Broadcast_5620"
                ],
                "name": "Multiply_5621",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5621_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5621",
                    "Parameter_5619"
                ],
                "name": "Add_5622",
                "op": "Add",
                "outputs": [
                    "Add_5622_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5617",
            "Parameter_5618",
            "Parameter_5619"
        ],
        "result": [
            "Add_5622"
        ]
    }
]