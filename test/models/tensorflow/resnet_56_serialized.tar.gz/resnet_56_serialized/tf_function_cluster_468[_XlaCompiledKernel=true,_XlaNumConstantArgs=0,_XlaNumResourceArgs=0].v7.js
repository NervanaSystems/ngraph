[
    {
        "name": "Function_178",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9472",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9472_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9471",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9471_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9470",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9470_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9470"
                ],
                "name": "Broadcast_9473",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9473_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9471",
                    "Broadcast_9473"
                ],
                "name": "Multiply_9474",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9474_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9474",
                    "Parameter_9472"
                ],
                "name": "Add_9475",
                "op": "Add",
                "outputs": [
                    "Add_9475_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9470",
            "Parameter_9471",
            "Parameter_9472"
        ],
        "result": [
            "Add_9475"
        ]
    }
]