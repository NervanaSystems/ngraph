[
    {
        "name": "Function_205",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10744",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10744_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10743",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10743_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10742",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10742_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10741",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10741_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10740",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10740_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_10747",
                "op": "Constant",
                "outputs": [
                    "Constant_10747_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10744"
                ],
                "name": "Reshape_10759",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10759_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10742",
                    "Parameter_10743"
                ],
                "name": "Add_10745",
                "op": "Add",
                "outputs": [
                    "Add_10745_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10741"
                ],
                "name": "Reverse_10751",
                "op": "Reverse",
                "outputs": [
                    "Reverse_10751_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_10740"
                ],
                "name": "Broadcast_10757",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10757_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_10747"
                ],
                "name": "Broadcast_10748",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10748_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_10745"
                ],
                "name": "Reshape_10746",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10746_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_10745"
                ],
                "name": "Reshape_10750",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10750_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_10751"
                ],
                "name": "Reshape_10753",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_10753_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10741",
                    "Broadcast_10757"
                ],
                "name": "Multiply_10758",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10758_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10744",
                    "Broadcast_10748"
                ],
                "name": "Greater_10749",
                "op": "Greater",
                "outputs": [
                    "Greater_10749_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_10750"
                ],
                "name": "Reshape_10760",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10760_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_10750"
                ],
                "name": "Reshape_10752",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10752_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10759",
                    "Reshape_10760"
                ],
                "name": "Convolution_10761",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10761_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10752",
                    "Reshape_10753"
                ],
                "name": "Convolution_10754",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10754_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_10761"
                ],
                "name": "Reshape_10762",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_10762_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_10754"
                ],
                "name": "Reshape_10755",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10755_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_10762"
                ],
                "name": "Reshape_10763",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_10763_0"
                ]
            },
            {
                "inputs": [
                    "Greater_10749",
                    "Reshape_10755",
                    "Broadcast_10748"
                ],
                "name": "Select_10756",
                "op": "Select",
                "outputs": [
                    "Select_10756_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10758",
                    "Reshape_10763"
                ],
                "name": "Add_10764",
                "op": "Add",
                "outputs": [
                    "Add_10764_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10740",
            "Parameter_10741",
            "Parameter_10742",
            "Parameter_10743",
            "Parameter_10744"
        ],
        "result": [
            "Reshape_10746",
            "Select_10756",
            "Add_10764"
        ]
    }
]