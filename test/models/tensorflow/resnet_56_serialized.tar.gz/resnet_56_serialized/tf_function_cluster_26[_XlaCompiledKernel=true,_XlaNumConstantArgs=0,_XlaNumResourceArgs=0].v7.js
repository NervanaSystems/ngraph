[
    {
        "name": "Function_185",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9800",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9800_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9799",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9799_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9798",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9798_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9798"
                ],
                "name": "Broadcast_9801",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9801_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9799",
                    "Broadcast_9801"
                ],
                "name": "Multiply_9802",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9802_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9802",
                    "Parameter_9800"
                ],
                "name": "Add_9803",
                "op": "Add",
                "outputs": [
                    "Add_9803_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9798",
            "Parameter_9799",
            "Parameter_9800"
        ],
        "result": [
            "Add_9803"
        ]
    }
]