[
    {
        "name": "Function_180",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9558",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9558_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9557",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9557_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9556",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9556_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9555",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9555_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9554",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9554_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_9561",
                "op": "Constant",
                "outputs": [
                    "Constant_9561_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9558"
                ],
                "name": "Reshape_9573",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9573_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9556",
                    "Parameter_9557"
                ],
                "name": "Add_9559",
                "op": "Add",
                "outputs": [
                    "Add_9559_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9555"
                ],
                "name": "Reverse_9565",
                "op": "Reverse",
                "outputs": [
                    "Reverse_9565_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_9554"
                ],
                "name": "Broadcast_9571",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9571_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_9561"
                ],
                "name": "Broadcast_9562",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9562_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_9559"
                ],
                "name": "Reshape_9564",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9564_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_9559"
                ],
                "name": "Reshape_9560",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9560_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_9565"
                ],
                "name": "Reshape_9567",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_9567_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9555",
                    "Broadcast_9571"
                ],
                "name": "Multiply_9572",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9572_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9558",
                    "Broadcast_9562"
                ],
                "name": "Greater_9563",
                "op": "Greater",
                "outputs": [
                    "Greater_9563_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_9564"
                ],
                "name": "Reshape_9566",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9566_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_9564"
                ],
                "name": "Reshape_9574",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9574_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9566",
                    "Reshape_9567"
                ],
                "name": "Convolution_9568",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9568_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9573",
                    "Reshape_9574"
                ],
                "name": "Convolution_9575",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9575_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_9568"
                ],
                "name": "Reshape_9569",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9569_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_9575"
                ],
                "name": "Reshape_9576",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_9576_0"
                ]
            },
            {
                "inputs": [
                    "Greater_9563",
                    "Reshape_9569",
                    "Broadcast_9562"
                ],
                "name": "Select_9570",
                "op": "Select",
                "outputs": [
                    "Select_9570_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_9576"
                ],
                "name": "Reshape_9577",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_9577_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9572",
                    "Reshape_9577"
                ],
                "name": "Add_9578",
                "op": "Add",
                "outputs": [
                    "Add_9578_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9554",
            "Parameter_9555",
            "Parameter_9556",
            "Parameter_9557",
            "Parameter_9558"
        ],
        "result": [
            "Reshape_9560",
            "Select_9570",
            "Add_9578"
        ]
    }
]