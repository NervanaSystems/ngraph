[
    {
        "name": "Function_104",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5905",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5905_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5904",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5904_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5903",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5903_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5903"
                ],
                "name": "Broadcast_5906",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5906_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5904",
                    "Broadcast_5906"
                ],
                "name": "Multiply_5907",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5907_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5907",
                    "Parameter_5905"
                ],
                "name": "Add_5908",
                "op": "Add",
                "outputs": [
                    "Add_5908_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5903",
            "Parameter_5904",
            "Parameter_5905"
        ],
        "result": [
            "Add_5908"
        ]
    }
]