[
    {
        "name": "Function_152",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8211",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8211_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8210",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8210_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8209",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8209_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8209"
                ],
                "name": "Broadcast_8212",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8212_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8210",
                    "Broadcast_8212"
                ],
                "name": "Multiply_8213",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8213_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8213",
                    "Parameter_8211"
                ],
                "name": "Add_8214",
                "op": "Add",
                "outputs": [
                    "Add_8214_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8209",
            "Parameter_8210",
            "Parameter_8211"
        ],
        "result": [
            "Add_8214"
        ]
    }
]