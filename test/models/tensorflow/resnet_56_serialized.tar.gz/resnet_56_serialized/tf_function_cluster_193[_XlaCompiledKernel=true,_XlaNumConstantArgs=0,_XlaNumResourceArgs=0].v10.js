[
    {
        "name": "Function_3",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_128",
                "op": "Parameter",
                "outputs": [
                    "Parameter_128_0"
                ],
                "shape": [
                    1,
                    1,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_127",
                "op": "Parameter",
                "outputs": [
                    "Parameter_127_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_126",
                "op": "Parameter",
                "outputs": [
                    "Parameter_126_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_125",
                "op": "Parameter",
                "outputs": [
                    "Parameter_125_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_129",
                "op": "Constant",
                "outputs": [
                    "Constant_129_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_128"
                ],
                "name": "Reshape_137",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_137_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_127"
                ],
                "name": "Reshape_136",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_136_0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_126"
                ],
                "name": "Reshape_133",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_133_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_129"
                ],
                "name": "Broadcast_130",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_130_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_136",
                    "Reshape_137"
                ],
                "name": "Convolution_138",
                "op": "Convolution",
                "outputs": [
                    "Convolution_138_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "inputs": [
                    "Broadcast_130",
                    "Parameter_125"
                ],
                "name": "Maximum_131",
                "op": "Maximum",
                "outputs": [
                    "Maximum_131_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_138"
                ],
                "name": "Reshape_139",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_139_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_131"
                ],
                "name": "Reshape_132",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_132_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_132",
                    "Reshape_133"
                ],
                "name": "Convolution_134",
                "op": "Convolution",
                "outputs": [
                    "Convolution_134_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_134"
                ],
                "name": "Reshape_135",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_135_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_135",
                    "Reshape_139"
                ],
                "name": "Add_140",
                "op": "Add",
                "outputs": [
                    "Add_140_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_125",
            "Parameter_126",
            "Parameter_127",
            "Parameter_128"
        ],
        "result": [
            "Add_140",
            "Maximum_131",
            "Reshape_139",
            "Reshape_135"
        ]
    }
]