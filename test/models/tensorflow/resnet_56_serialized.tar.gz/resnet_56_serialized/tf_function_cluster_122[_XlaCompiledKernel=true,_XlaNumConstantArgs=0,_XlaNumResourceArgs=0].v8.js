[
    {
        "name": "Function_43",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1990",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1990_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1989",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1989_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1988",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1988_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1991",
                "op": "Constant",
                "outputs": [
                    "Constant_1991_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1989"
                ],
                "name": "Reshape_1995",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1995_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1991"
                ],
                "name": "Broadcast_1992",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1992_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_1992",
                    "Parameter_1988"
                ],
                "name": "Maximum_1993",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1993_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1993"
                ],
                "name": "Reshape_1994",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_1994_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1994",
                    "Reshape_1995"
                ],
                "name": "Convolution_1996",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1996_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1996"
                ],
                "name": "Reshape_1997",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_1997_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_1997",
                    "Parameter_1990"
                ],
                "name": "Add_1998",
                "op": "Add",
                "outputs": [
                    "Add_1998_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1988",
            "Parameter_1989",
            "Parameter_1990"
        ],
        "result": [
            "Add_1998",
            "Maximum_1993",
            "Reshape_1997"
        ]
    }
]