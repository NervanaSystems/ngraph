[
    {
        "name": "Function_85",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5005",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5005_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5004",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5004_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5003",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5003_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5003"
                ],
                "name": "Broadcast_5006",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5006_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5004",
                    "Broadcast_5006"
                ],
                "name": "Multiply_5007",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5007_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5007",
                    "Parameter_5005"
                ],
                "name": "Add_5008",
                "op": "Add",
                "outputs": [
                    "Add_5008_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5003",
            "Parameter_5004",
            "Parameter_5005"
        ],
        "result": [
            "Add_5008"
        ]
    }
]