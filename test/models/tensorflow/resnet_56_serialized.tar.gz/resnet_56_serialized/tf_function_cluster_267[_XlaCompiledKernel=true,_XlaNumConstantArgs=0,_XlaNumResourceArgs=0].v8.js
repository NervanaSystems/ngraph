[
    {
        "name": "Function_15",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_684",
                "op": "Parameter",
                "outputs": [
                    "Parameter_684_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_683",
                "op": "Parameter",
                "outputs": [
                    "Parameter_683_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_682",
                "op": "Parameter",
                "outputs": [
                    "Parameter_682_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_685",
                "op": "Constant",
                "outputs": [
                    "Constant_685_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_683"
                ],
                "name": "Reshape_689",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_689_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_685"
                ],
                "name": "Broadcast_686",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_686_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_686",
                    "Parameter_682"
                ],
                "name": "Maximum_687",
                "op": "Maximum",
                "outputs": [
                    "Maximum_687_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_687"
                ],
                "name": "Reshape_688",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_688_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_688",
                    "Reshape_689"
                ],
                "name": "Convolution_690",
                "op": "Convolution",
                "outputs": [
                    "Convolution_690_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_690"
                ],
                "name": "Reshape_691",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_691_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_691",
                    "Parameter_684"
                ],
                "name": "Add_692",
                "op": "Add",
                "outputs": [
                    "Add_692_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_682",
            "Parameter_683",
            "Parameter_684"
        ],
        "result": [
            "Add_692",
            "Maximum_687",
            "Reshape_691"
        ]
    }
]