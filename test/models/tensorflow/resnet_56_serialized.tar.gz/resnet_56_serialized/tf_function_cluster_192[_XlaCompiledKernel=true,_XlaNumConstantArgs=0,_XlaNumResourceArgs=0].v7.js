[
    {
        "name": "Function_71",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4330",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4330_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4329",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4329_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4328",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4328_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4328"
                ],
                "name": "Broadcast_4331",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4331_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4329",
                    "Broadcast_4331"
                ],
                "name": "Multiply_4332",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4332_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4332",
                    "Parameter_4330"
                ],
                "name": "Add_4333",
                "op": "Add",
                "outputs": [
                    "Add_4333_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4328",
            "Parameter_4329",
            "Parameter_4330"
        ],
        "result": [
            "Add_4333"
        ]
    }
]