[
    {
        "name": "Function_148",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7989",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7989_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7988",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7988_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7987",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7987_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7987"
                ],
                "name": "Broadcast_7990",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7990_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7988",
                    "Broadcast_7990"
                ],
                "name": "Multiply_7991",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7991_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7991",
                    "Parameter_7989"
                ],
                "name": "Add_7992",
                "op": "Add",
                "outputs": [
                    "Add_7992_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7987",
            "Parameter_7988",
            "Parameter_7989"
        ],
        "result": [
            "Add_7992"
        ]
    }
]