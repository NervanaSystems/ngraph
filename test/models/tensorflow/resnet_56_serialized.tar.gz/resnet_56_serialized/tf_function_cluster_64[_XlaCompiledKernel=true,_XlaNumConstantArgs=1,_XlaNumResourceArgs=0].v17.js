[
    {
        "name": "Function_158",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8498",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8498_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8497",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8497_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8496",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8496_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8495",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8495_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_8499",
                "op": "Constant",
                "outputs": [
                    "Constant_8499_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8498"
                ],
                "name": "Reshape_8511",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8511_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8498"
                ],
                "name": "Reshape_8503",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8503_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8497"
                ],
                "name": "Reshape_8510",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8510_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8496"
                ],
                "name": "Reverse_8502",
                "op": "Reverse",
                "outputs": [
                    "Reverse_8502_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_8495"
                ],
                "name": "Broadcast_8508",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8508_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_8499"
                ],
                "name": "Broadcast_8500",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8500_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8510",
                    "Reshape_8511"
                ],
                "name": "Convolution_8512",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8512_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_8502"
                ],
                "name": "Reshape_8504",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_8504_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8496",
                    "Broadcast_8508"
                ],
                "name": "Multiply_8509",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8509_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8497",
                    "Broadcast_8500"
                ],
                "name": "Greater_8501",
                "op": "Greater",
                "outputs": [
                    "Greater_8501_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_8512"
                ],
                "name": "Reshape_8513",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_8513_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8503",
                    "Reshape_8504"
                ],
                "name": "Convolution_8505",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8505_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_8513"
                ],
                "name": "Reshape_8514",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_8514_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_8505"
                ],
                "name": "Reshape_8506",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8506_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8509",
                    "Reshape_8514"
                ],
                "name": "Add_8515",
                "op": "Add",
                "outputs": [
                    "Add_8515_0"
                ]
            },
            {
                "inputs": [
                    "Greater_8501",
                    "Reshape_8506",
                    "Broadcast_8500"
                ],
                "name": "Select_8507",
                "op": "Select",
                "outputs": [
                    "Select_8507_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8495",
            "Parameter_8496",
            "Parameter_8497",
            "Parameter_8498"
        ],
        "result": [
            "Select_8507",
            "Add_8515"
        ]
    }
]