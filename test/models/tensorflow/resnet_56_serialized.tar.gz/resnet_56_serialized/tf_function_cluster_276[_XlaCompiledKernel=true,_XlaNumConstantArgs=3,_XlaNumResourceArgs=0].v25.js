[
    {
        "name": "Function_127",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7008",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7008_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7007",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7007_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7006",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7006_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7005",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7005_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7004",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7004_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_7011",
                "op": "Constant",
                "outputs": [
                    "Constant_7011_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7008"
                ],
                "name": "Reshape_7023",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7023_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7006",
                    "Parameter_7007"
                ],
                "name": "Add_7009",
                "op": "Add",
                "outputs": [
                    "Add_7009_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7005"
                ],
                "name": "Reverse_7015",
                "op": "Reverse",
                "outputs": [
                    "Reverse_7015_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_7004"
                ],
                "name": "Broadcast_7021",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7021_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_7011"
                ],
                "name": "Broadcast_7012",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7012_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_7009"
                ],
                "name": "Reshape_7010",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7010_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_7009"
                ],
                "name": "Reshape_7014",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7014_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_7015"
                ],
                "name": "Reshape_7017",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_7017_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7005",
                    "Broadcast_7021"
                ],
                "name": "Multiply_7022",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7022_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7008",
                    "Broadcast_7012"
                ],
                "name": "Greater_7013",
                "op": "Greater",
                "outputs": [
                    "Greater_7013_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_7014"
                ],
                "name": "Reshape_7024",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7024_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_7014"
                ],
                "name": "Reshape_7016",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7016_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7023",
                    "Reshape_7024"
                ],
                "name": "Convolution_7025",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7025_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7016",
                    "Reshape_7017"
                ],
                "name": "Convolution_7018",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7018_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_7025"
                ],
                "name": "Reshape_7026",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_7026_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_7018"
                ],
                "name": "Reshape_7019",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7019_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_7026"
                ],
                "name": "Reshape_7027",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_7027_0"
                ]
            },
            {
                "inputs": [
                    "Greater_7013",
                    "Reshape_7019",
                    "Broadcast_7012"
                ],
                "name": "Select_7020",
                "op": "Select",
                "outputs": [
                    "Select_7020_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7022",
                    "Reshape_7027"
                ],
                "name": "Add_7028",
                "op": "Add",
                "outputs": [
                    "Add_7028_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7004",
            "Parameter_7005",
            "Parameter_7006",
            "Parameter_7007",
            "Parameter_7008"
        ],
        "result": [
            "Reshape_7010",
            "Select_7020",
            "Add_7028"
        ]
    }
]