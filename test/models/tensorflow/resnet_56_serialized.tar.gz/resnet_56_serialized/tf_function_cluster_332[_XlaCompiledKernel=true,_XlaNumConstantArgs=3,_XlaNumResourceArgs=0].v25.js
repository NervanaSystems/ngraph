[
    {
        "name": "Function_119",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6638",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6638_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6637",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6637_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6636",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6636_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6635",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6635_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6634",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6634_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_6641",
                "op": "Constant",
                "outputs": [
                    "Constant_6641_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6638"
                ],
                "name": "Reshape_6653",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6653_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6636",
                    "Parameter_6637"
                ],
                "name": "Add_6639",
                "op": "Add",
                "outputs": [
                    "Add_6639_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6635"
                ],
                "name": "Reverse_6645",
                "op": "Reverse",
                "outputs": [
                    "Reverse_6645_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_6634"
                ],
                "name": "Broadcast_6651",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6651_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_6641"
                ],
                "name": "Broadcast_6642",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6642_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_6639"
                ],
                "name": "Reshape_6640",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_6640_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_6639"
                ],
                "name": "Reshape_6644",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_6644_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_6645"
                ],
                "name": "Reshape_6647",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_6647_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6635",
                    "Broadcast_6651"
                ],
                "name": "Multiply_6652",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6652_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6638",
                    "Broadcast_6642"
                ],
                "name": "Greater_6643",
                "op": "Greater",
                "outputs": [
                    "Greater_6643_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_6644"
                ],
                "name": "Reshape_6646",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6646_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_6644"
                ],
                "name": "Reshape_6654",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6654_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6646",
                    "Reshape_6647"
                ],
                "name": "Convolution_6648",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6648_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6653",
                    "Reshape_6654"
                ],
                "name": "Convolution_6655",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6655_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_6648"
                ],
                "name": "Reshape_6649",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_6649_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_6655"
                ],
                "name": "Reshape_6656",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_6656_0"
                ]
            },
            {
                "inputs": [
                    "Greater_6643",
                    "Reshape_6649",
                    "Broadcast_6642"
                ],
                "name": "Select_6650",
                "op": "Select",
                "outputs": [
                    "Select_6650_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_6656"
                ],
                "name": "Reshape_6657",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_6657_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6652",
                    "Reshape_6657"
                ],
                "name": "Add_6658",
                "op": "Add",
                "outputs": [
                    "Add_6658_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6634",
            "Parameter_6635",
            "Parameter_6636",
            "Parameter_6637",
            "Parameter_6638"
        ],
        "result": [
            "Reshape_6640",
            "Select_6650",
            "Add_6658"
        ]
    }
]