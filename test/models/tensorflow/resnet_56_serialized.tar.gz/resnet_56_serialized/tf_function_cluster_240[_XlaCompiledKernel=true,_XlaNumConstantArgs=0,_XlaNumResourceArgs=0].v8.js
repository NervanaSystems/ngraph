[
    {
        "name": "Function_9",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_408",
                "op": "Parameter",
                "outputs": [
                    "Parameter_408_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_407",
                "op": "Parameter",
                "outputs": [
                    "Parameter_407_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_406",
                "op": "Parameter",
                "outputs": [
                    "Parameter_406_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_409",
                "op": "Constant",
                "outputs": [
                    "Constant_409_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_407"
                ],
                "name": "Reshape_413",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_413_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_409"
                ],
                "name": "Broadcast_410",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_410_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_410",
                    "Parameter_406"
                ],
                "name": "Maximum_411",
                "op": "Maximum",
                "outputs": [
                    "Maximum_411_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_411"
                ],
                "name": "Reshape_412",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_412_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_412",
                    "Reshape_413"
                ],
                "name": "Convolution_414",
                "op": "Convolution",
                "outputs": [
                    "Convolution_414_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_414"
                ],
                "name": "Reshape_415",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_415_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_415",
                    "Parameter_408"
                ],
                "name": "Add_416",
                "op": "Add",
                "outputs": [
                    "Add_416_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_406",
            "Parameter_407",
            "Parameter_408"
        ],
        "result": [
            "Add_416",
            "Maximum_411",
            "Reshape_415"
        ]
    }
]