[
    {
        "name": "Function_210",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10986",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10986_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10985",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10985_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10984",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10984_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10984"
                ],
                "name": "Broadcast_10987",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10987_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10985",
                    "Broadcast_10987"
                ],
                "name": "Multiply_10988",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10988_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10988",
                    "Parameter_10986"
                ],
                "name": "Add_10989",
                "op": "Add",
                "outputs": [
                    "Add_10989_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10984",
            "Parameter_10985",
            "Parameter_10986"
        ],
        "result": [
            "Add_10989"
        ]
    }
]