[
    {
        "name": "Function_169",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9010",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9010_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9009",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9009_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9008",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9008_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9008"
                ],
                "name": "Broadcast_9011",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9011_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9009",
                    "Broadcast_9011"
                ],
                "name": "Multiply_9012",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9012_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9012",
                    "Parameter_9010"
                ],
                "name": "Add_9013",
                "op": "Add",
                "outputs": [
                    "Add_9013_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9008",
            "Parameter_9009",
            "Parameter_9010"
        ],
        "result": [
            "Add_9013"
        ]
    }
]