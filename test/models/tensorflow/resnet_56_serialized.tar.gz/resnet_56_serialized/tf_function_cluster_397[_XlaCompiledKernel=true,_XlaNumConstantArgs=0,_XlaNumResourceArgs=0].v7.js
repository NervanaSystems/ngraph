[
    {
        "name": "Function_125",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6922",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6922_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6921",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6921_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6920",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6920_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6920"
                ],
                "name": "Broadcast_6923",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6923_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6921",
                    "Broadcast_6923"
                ],
                "name": "Multiply_6924",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6924_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6924",
                    "Parameter_6922"
                ],
                "name": "Add_6925",
                "op": "Add",
                "outputs": [
                    "Add_6925_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6920",
            "Parameter_6921",
            "Parameter_6922"
        ],
        "result": [
            "Add_6925"
        ]
    }
]