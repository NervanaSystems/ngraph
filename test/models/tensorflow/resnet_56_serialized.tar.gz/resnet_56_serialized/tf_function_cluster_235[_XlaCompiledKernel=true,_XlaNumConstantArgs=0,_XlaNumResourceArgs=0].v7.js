[
    {
        "name": "Function_149",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8066",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8066_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8065",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8065_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8064",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8064_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8064"
                ],
                "name": "Broadcast_8067",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8067_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8065",
                    "Broadcast_8067"
                ],
                "name": "Multiply_8068",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8068_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8068",
                    "Parameter_8066"
                ],
                "name": "Add_8069",
                "op": "Add",
                "outputs": [
                    "Add_8069_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8064",
            "Parameter_8065",
            "Parameter_8066"
        ],
        "result": [
            "Add_8069"
        ]
    }
]