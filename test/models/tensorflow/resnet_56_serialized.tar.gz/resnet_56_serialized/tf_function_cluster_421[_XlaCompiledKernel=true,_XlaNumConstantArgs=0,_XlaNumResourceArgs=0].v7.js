[
    {
        "name": "Function_151",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8169",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8169_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8168",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8168_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8167",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8167_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8167"
                ],
                "name": "Broadcast_8170",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8170_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8168",
                    "Broadcast_8170"
                ],
                "name": "Multiply_8171",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8171_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8171",
                    "Parameter_8169"
                ],
                "name": "Add_8172",
                "op": "Add",
                "outputs": [
                    "Add_8172_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8167",
            "Parameter_8168",
            "Parameter_8169"
        ],
        "result": [
            "Add_8172"
        ]
    }
]