[
    {
        "name": "Function_91",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5256",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5256_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5255",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5255_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5254",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5254_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5254"
                ],
                "name": "Broadcast_5257",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5257_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5255",
                    "Broadcast_5257"
                ],
                "name": "Multiply_5258",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5258_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5258",
                    "Parameter_5256"
                ],
                "name": "Add_5259",
                "op": "Add",
                "outputs": [
                    "Add_5259_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5254",
            "Parameter_5255",
            "Parameter_5256"
        ],
        "result": [
            "Add_5259"
        ]
    }
]