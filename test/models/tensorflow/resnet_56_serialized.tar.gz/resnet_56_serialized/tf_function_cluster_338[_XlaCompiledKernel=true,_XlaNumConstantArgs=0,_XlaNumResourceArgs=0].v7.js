[
    {
        "name": "Function_164",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8783",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8783_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8782",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8782_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8781",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8781_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8781"
                ],
                "name": "Broadcast_8784",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8784_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8782",
                    "Broadcast_8784"
                ],
                "name": "Multiply_8785",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8785_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8785",
                    "Parameter_8783"
                ],
                "name": "Add_8786",
                "op": "Add",
                "outputs": [
                    "Add_8786_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8781",
            "Parameter_8782",
            "Parameter_8783"
        ],
        "result": [
            "Add_8786"
        ]
    }
]