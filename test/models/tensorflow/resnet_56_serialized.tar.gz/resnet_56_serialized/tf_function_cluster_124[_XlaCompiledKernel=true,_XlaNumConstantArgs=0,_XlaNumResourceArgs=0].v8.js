[
    {
        "name": "Function_41",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1898",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1898_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1897",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1897_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1896",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1896_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1899",
                "op": "Constant",
                "outputs": [
                    "Constant_1899_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1897"
                ],
                "name": "Reshape_1903",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1903_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1899"
                ],
                "name": "Broadcast_1900",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1900_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_1900",
                    "Parameter_1896"
                ],
                "name": "Maximum_1901",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1901_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1901"
                ],
                "name": "Reshape_1902",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_1902_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1902",
                    "Reshape_1903"
                ],
                "name": "Convolution_1904",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1904_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1904"
                ],
                "name": "Reshape_1905",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_1905_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_1905",
                    "Parameter_1898"
                ],
                "name": "Add_1906",
                "op": "Add",
                "outputs": [
                    "Add_1906_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1896",
            "Parameter_1897",
            "Parameter_1898"
        ],
        "result": [
            "Add_1906",
            "Maximum_1901",
            "Reshape_1905"
        ]
    }
]