[
    {
        "name": "Function_59",
        "ops": [
            {
                "element_type": "char",
                "inputs": [],
                "name": "Parameter_3737",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3737_0"
                ],
                "shape": [
                    2
                ]
            },
            {
                "inputs": [
                    "Parameter_3737"
                ],
                "name": "Convert_3738",
                "op": "Convert",
                "outputs": [
                    "Convert_3738_0"
                ],
                "target_type": "float"
            },
            {
                "inputs": [
                    "Convert_3738"
                ],
                "name": "Sum_3739",
                "op": "Sum",
                "outputs": [
                    "Sum_3739_0"
                ],
                "reduction_axes": [
                    0
                ]
            }
        ],
        "parameters": [
            "Parameter_3737"
        ],
        "result": [
            "Sum_3739"
        ]
    }
]