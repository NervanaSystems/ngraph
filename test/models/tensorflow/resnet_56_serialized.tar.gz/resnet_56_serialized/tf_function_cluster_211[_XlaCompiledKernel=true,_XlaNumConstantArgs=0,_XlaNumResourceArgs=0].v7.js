[
    {
        "name": "Function_111",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6220",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6220_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6218",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6218_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6213",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6213_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6213"
                ],
                "name": "Broadcast_6227",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6227_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_6218",
                    "Broadcast_6227"
                ],
                "name": "Multiply_6231",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6231_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6231",
                    "Parameter_6220"
                ],
                "name": "Add_6236",
                "op": "Add",
                "outputs": [
                    "Add_6236_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6213",
            "Parameter_6218",
            "Parameter_6220"
        ],
        "result": [
            "Add_6236"
        ]
    }
]