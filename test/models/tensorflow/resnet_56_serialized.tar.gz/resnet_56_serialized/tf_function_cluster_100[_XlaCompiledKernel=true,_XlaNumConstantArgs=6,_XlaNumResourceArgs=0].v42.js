[
    {
        "name": "Function_112",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6280",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6280_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6279",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6279_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6278",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6278_0"
                ],
                "shape": [
                    2,
                    18,
                    18,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6277",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6277_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6276",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6276_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6275",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6275_0"
                ],
                "shape": [
                    1,
                    1,
                    32,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6274",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6274_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6273",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6273_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_6281",
                "op": "Constant",
                "outputs": [
                    "Constant_6281_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6279"
                ],
                "name": "Reshape_6300",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_6300_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6279"
                ],
                "name": "Reshape_6290",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_6290_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6278"
                ],
                "name": "Reshape_6299",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    18,
                    18
                ],
                "outputs": [
                    "Reshape_6299_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6277"
                ],
                "name": "Reshape_6308",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6308_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6276"
                ],
                "name": "Reshape_6285",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_6285_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6276"
                ],
                "name": "Reshape_6309",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_6309_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6275"
                ],
                "name": "Reverse_6284",
                "op": "Reverse",
                "outputs": [
                    "Reverse_6284_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "inputs": [
                    "Parameter_6274"
                ],
                "name": "Reverse_6289",
                "op": "Reverse",
                "outputs": [
                    "Reverse_6289_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_6273"
                ],
                "name": "Broadcast_6297",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6297_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    64
                ]
            },
            {
                "input_order": [],
                "inputs": [
                    "Parameter_6273"
                ],
                "name": "Reshape_6305",
                "op": "Reshape",
                "output_shape": [
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_6305_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_6281"
                ],
                "name": "Broadcast_6282",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6282_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6299",
                    "Reshape_6300"
                ],
                "name": "Convolution_6301",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6301_0"
                ],
                "padding_above": [
                    -1,
                    -1
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    2,
                    2
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6308",
                    "Reshape_6309"
                ],
                "name": "Convolution_6310",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6310_0"
                ],
                "padding_above": [
                    -1,
                    -1
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    2,
                    2
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_6284"
                ],
                "name": "Reshape_6286",
                "op": "Reshape",
                "output_shape": [
                    32,
                    64,
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_6286_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_6289"
                ],
                "name": "Reshape_6291",
                "op": "Reshape",
                "output_shape": [
                    32,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_6291_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6274",
                    "Broadcast_6297"
                ],
                "name": "Multiply_6298",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6298_0"
                ]
            },
            {
                "axes": [
                    2,
                    3
                ],
                "inputs": [
                    "Reshape_6305"
                ],
                "name": "Broadcast_6306",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6306_0"
                ],
                "shape": [
                    1,
                    1,
                    32,
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_6280",
                    "Broadcast_6282"
                ],
                "name": "Greater_6283",
                "op": "Greater",
                "outputs": [
                    "Greater_6283_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_6301"
                ],
                "name": "Reshape_6302",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_6302_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_6310"
                ],
                "name": "Reshape_6311",
                "op": "Reshape",
                "output_shape": [
                    64,
                    1,
                    1,
                    32
                ],
                "outputs": [
                    "Reshape_6311_0"
                ]
            },
            {
                "data_dilation_strides": [
                    2,
                    2
                ],
                "inputs": [
                    "Reshape_6285",
                    "Reshape_6286"
                ],
                "name": "Convolution_6287",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6287_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    2,
                    2
                ],
                "inputs": [
                    "Reshape_6290",
                    "Reshape_6291"
                ],
                "name": "Convolution_6292",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6292_0"
                ],
                "padding_above": [
                    3,
                    3
                ],
                "padding_below": [
                    2,
                    2
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "inputs": [
                    "Parameter_6275",
                    "Broadcast_6306"
                ],
                "name": "Multiply_6307",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6307_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_6302"
                ],
                "name": "Reshape_6303",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    64
                ],
                "outputs": [
                    "Reshape_6303_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_6311"
                ],
                "name": "Reshape_6312",
                "op": "Reshape",
                "output_shape": [
                    1,
                    1,
                    32,
                    64
                ],
                "outputs": [
                    "Reshape_6312_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_6287"
                ],
                "name": "Reshape_6288",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_6288_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_6292"
                ],
                "name": "Reshape_6293",
                "op": "Reshape",
                "output_shape": [
                    2,
                    18,
                    18,
                    32
                ],
                "outputs": [
                    "Reshape_6293_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6298",
                    "Reshape_6303"
                ],
                "name": "Add_6304",
                "op": "Add",
                "outputs": [
                    "Add_6304_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6307",
                    "Reshape_6312"
                ],
                "name": "Add_6313",
                "op": "Add",
                "outputs": [
                    "Add_6313_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_6293"
                ],
                "lower_bounds": [
                    0,
                    1,
                    1,
                    0
                ],
                "name": "Slice_6294",
                "op": "Slice",
                "outputs": [
                    "Slice_6294_0"
                ],
                "strides": [
                    1,
                    1,
                    1,
                    1
                ],
                "upper_bounds": [
                    2,
                    17,
                    17,
                    32
                ]
            },
            {
                "inputs": [
                    "Reshape_6288",
                    "Slice_6294"
                ],
                "name": "Add_6295",
                "op": "Add",
                "outputs": [
                    "Add_6295_0"
                ]
            },
            {
                "inputs": [
                    "Greater_6283",
                    "Add_6295",
                    "Broadcast_6282"
                ],
                "name": "Select_6296",
                "op": "Select",
                "outputs": [
                    "Select_6296_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6273",
            "Parameter_6274",
            "Parameter_6275",
            "Parameter_6276",
            "Parameter_6277",
            "Parameter_6278",
            "Parameter_6279",
            "Parameter_6280"
        ],
        "result": [
            "Select_6296",
            "Add_6304",
            "Add_6313"
        ]
    }
]