[
    {
        "name": "Function_199",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10458",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10458_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10457",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10457_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10456",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10456_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10455",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10455_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10454",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10454_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_10461",
                "op": "Constant",
                "outputs": [
                    "Constant_10461_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10458"
                ],
                "name": "Reshape_10473",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10473_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10456",
                    "Parameter_10457"
                ],
                "name": "Add_10459",
                "op": "Add",
                "outputs": [
                    "Add_10459_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10455"
                ],
                "name": "Reverse_10465",
                "op": "Reverse",
                "outputs": [
                    "Reverse_10465_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_10454"
                ],
                "name": "Broadcast_10471",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10471_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_10461"
                ],
                "name": "Broadcast_10462",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10462_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_10459"
                ],
                "name": "Reshape_10460",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10460_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_10459"
                ],
                "name": "Reshape_10464",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10464_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_10465"
                ],
                "name": "Reshape_10467",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_10467_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10455",
                    "Broadcast_10471"
                ],
                "name": "Multiply_10472",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10472_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10458",
                    "Broadcast_10462"
                ],
                "name": "Greater_10463",
                "op": "Greater",
                "outputs": [
                    "Greater_10463_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_10464"
                ],
                "name": "Reshape_10466",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10466_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_10464"
                ],
                "name": "Reshape_10474",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10474_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10466",
                    "Reshape_10467"
                ],
                "name": "Convolution_10468",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10468_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10473",
                    "Reshape_10474"
                ],
                "name": "Convolution_10475",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10475_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_10468"
                ],
                "name": "Reshape_10469",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10469_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_10475"
                ],
                "name": "Reshape_10476",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_10476_0"
                ]
            },
            {
                "inputs": [
                    "Greater_10463",
                    "Reshape_10469",
                    "Broadcast_10462"
                ],
                "name": "Select_10470",
                "op": "Select",
                "outputs": [
                    "Select_10470_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_10476"
                ],
                "name": "Reshape_10477",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_10477_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10472",
                    "Reshape_10477"
                ],
                "name": "Add_10478",
                "op": "Add",
                "outputs": [
                    "Add_10478_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10454",
            "Parameter_10455",
            "Parameter_10456",
            "Parameter_10457",
            "Parameter_10458"
        ],
        "result": [
            "Reshape_10460",
            "Select_10470",
            "Add_10478"
        ]
    }
]