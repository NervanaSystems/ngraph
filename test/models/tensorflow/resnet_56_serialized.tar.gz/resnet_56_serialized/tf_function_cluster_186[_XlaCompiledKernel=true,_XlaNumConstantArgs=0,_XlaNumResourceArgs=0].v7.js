[
    {
        "name": "Function_173",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9228",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9228_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9227",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9227_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9226",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9226_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9226"
                ],
                "name": "Broadcast_9229",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9229_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9227",
                    "Broadcast_9229"
                ],
                "name": "Multiply_9230",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9230_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9230",
                    "Parameter_9228"
                ],
                "name": "Add_9231",
                "op": "Add",
                "outputs": [
                    "Add_9231_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9226",
            "Parameter_9227",
            "Parameter_9228"
        ],
        "result": [
            "Add_9231"
        ]
    }
]