[
    {
        "name": "Function_93",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5375",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5375_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5374",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5374_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5373",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5373_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5373"
                ],
                "name": "Broadcast_5376",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5376_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5374",
                    "Broadcast_5376"
                ],
                "name": "Multiply_5377",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5377_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5377",
                    "Parameter_5375"
                ],
                "name": "Add_5378",
                "op": "Add",
                "outputs": [
                    "Add_5378_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5373",
            "Parameter_5374",
            "Parameter_5375"
        ],
        "result": [
            "Add_5378"
        ]
    }
]