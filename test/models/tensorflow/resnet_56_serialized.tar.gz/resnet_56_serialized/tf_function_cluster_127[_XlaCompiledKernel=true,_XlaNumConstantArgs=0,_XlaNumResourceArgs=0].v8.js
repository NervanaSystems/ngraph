[
    {
        "name": "Function_37",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1705",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1705_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1704",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1704_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1703",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1703_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1706",
                "op": "Constant",
                "outputs": [
                    "Constant_1706_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1704"
                ],
                "name": "Reshape_1710",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1710_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1706"
                ],
                "name": "Broadcast_1707",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1707_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1707",
                    "Parameter_1703"
                ],
                "name": "Maximum_1708",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1708_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1708"
                ],
                "name": "Reshape_1709",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1709_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1709",
                    "Reshape_1710"
                ],
                "name": "Convolution_1711",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1711_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1711"
                ],
                "name": "Reshape_1712",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1712_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_1712",
                    "Parameter_1705"
                ],
                "name": "Add_1713",
                "op": "Add",
                "outputs": [
                    "Add_1713_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1703",
            "Parameter_1704",
            "Parameter_1705"
        ],
        "result": [
            "Add_1713",
            "Maximum_1708",
            "Reshape_1712"
        ]
    }
]