[
    {
        "name": "Function_84",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4946",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4946_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4945",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4945_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4944",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4944_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4943",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4943_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4942",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4942_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_4949",
                "op": "Constant",
                "outputs": [
                    "Constant_4949_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4946"
                ],
                "name": "Reshape_4961",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4961_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4944",
                    "Parameter_4945"
                ],
                "name": "Add_4947",
                "op": "Add",
                "outputs": [
                    "Add_4947_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4943"
                ],
                "name": "Reverse_4953",
                "op": "Reverse",
                "outputs": [
                    "Reverse_4953_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_4942"
                ],
                "name": "Broadcast_4959",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4959_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_4949"
                ],
                "name": "Broadcast_4950",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4950_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_4947"
                ],
                "name": "Reshape_4952",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4952_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_4947"
                ],
                "name": "Reshape_4948",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4948_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_4953"
                ],
                "name": "Reshape_4955",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_4955_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4943",
                    "Broadcast_4959"
                ],
                "name": "Multiply_4960",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4960_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4946",
                    "Broadcast_4950"
                ],
                "name": "Greater_4951",
                "op": "Greater",
                "outputs": [
                    "Greater_4951_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_4952"
                ],
                "name": "Reshape_4954",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4954_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_4952"
                ],
                "name": "Reshape_4962",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4962_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4954",
                    "Reshape_4955"
                ],
                "name": "Convolution_4956",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4956_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4961",
                    "Reshape_4962"
                ],
                "name": "Convolution_4963",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4963_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_4956"
                ],
                "name": "Reshape_4957",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4957_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_4963"
                ],
                "name": "Reshape_4964",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_4964_0"
                ]
            },
            {
                "inputs": [
                    "Greater_4951",
                    "Reshape_4957",
                    "Broadcast_4950"
                ],
                "name": "Select_4958",
                "op": "Select",
                "outputs": [
                    "Select_4958_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_4964"
                ],
                "name": "Reshape_4965",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_4965_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4960",
                    "Reshape_4965"
                ],
                "name": "Add_4966",
                "op": "Add",
                "outputs": [
                    "Add_4966_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4942",
            "Parameter_4943",
            "Parameter_4944",
            "Parameter_4945",
            "Parameter_4946"
        ],
        "result": [
            "Reshape_4948",
            "Select_4958",
            "Add_4966"
        ]
    }
]