[
    {
        "name": "Function_61",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3860",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3860_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3859",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3859_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_3861",
                "op": "Constant",
                "outputs": [
                    "Constant_3861_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3859",
                    "Parameter_3860"
                ],
                "name": "Divide_3863",
                "op": "Divide",
                "outputs": [
                    "Divide_3863_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3860",
                    "Constant_3861"
                ],
                "name": "Greater_3862",
                "op": "Greater",
                "outputs": [
                    "Greater_3862_0"
                ]
            },
            {
                "inputs": [
                    "Greater_3862",
                    "Divide_3863",
                    "Constant_3861"
                ],
                "name": "Select_3864",
                "op": "Select",
                "outputs": [
                    "Select_3864_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_3859",
            "Parameter_3860"
        ],
        "result": [
            "Select_3864",
            "Select_3864"
        ]
    }
]