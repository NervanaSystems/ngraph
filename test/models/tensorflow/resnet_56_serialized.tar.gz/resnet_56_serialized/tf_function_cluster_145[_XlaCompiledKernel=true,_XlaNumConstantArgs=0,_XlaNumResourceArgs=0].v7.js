[
    {
        "name": "Function_66",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4070",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4070_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4069",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4069_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4068",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4068_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4068"
                ],
                "name": "Broadcast_4071",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4071_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4069",
                    "Broadcast_4071"
                ],
                "name": "Multiply_4072",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4072_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4072",
                    "Parameter_4070"
                ],
                "name": "Add_4073",
                "op": "Add",
                "outputs": [
                    "Add_4073_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4068",
            "Parameter_4069",
            "Parameter_4070"
        ],
        "result": [
            "Add_4073"
        ]
    }
]