[
    {
        "name": "Function_139",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7597",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7597_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7596",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7596_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7590",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7590_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7590"
                ],
                "name": "Broadcast_7598",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7598_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7596",
                    "Broadcast_7598"
                ],
                "name": "Multiply_7599",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7599_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7599",
                    "Parameter_7597"
                ],
                "name": "Add_7600",
                "op": "Add",
                "outputs": [
                    "Add_7600_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7590",
            "Parameter_7596",
            "Parameter_7597"
        ],
        "result": [
            "Add_7600"
        ]
    }
]