[
    {
        "name": "Function_134",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7354",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7354_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7353",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7353_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7352",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7352_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7351",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7351_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_7355",
                "op": "Constant",
                "outputs": [
                    "Constant_7355_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7354"
                ],
                "name": "Reshape_7367",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7367_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7354"
                ],
                "name": "Reshape_7359",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7359_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7353"
                ],
                "name": "Reshape_7366",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7366_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7352"
                ],
                "name": "Reverse_7358",
                "op": "Reverse",
                "outputs": [
                    "Reverse_7358_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_7351"
                ],
                "name": "Broadcast_7364",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7364_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_7355"
                ],
                "name": "Broadcast_7356",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7356_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7366",
                    "Reshape_7367"
                ],
                "name": "Convolution_7368",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7368_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_7358"
                ],
                "name": "Reshape_7360",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_7360_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7352",
                    "Broadcast_7364"
                ],
                "name": "Multiply_7365",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7365_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7353",
                    "Broadcast_7356"
                ],
                "name": "Greater_7357",
                "op": "Greater",
                "outputs": [
                    "Greater_7357_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_7368"
                ],
                "name": "Reshape_7369",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_7369_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7359",
                    "Reshape_7360"
                ],
                "name": "Convolution_7361",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7361_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_7369"
                ],
                "name": "Reshape_7370",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_7370_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_7361"
                ],
                "name": "Reshape_7362",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7362_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7365",
                    "Reshape_7370"
                ],
                "name": "Add_7371",
                "op": "Add",
                "outputs": [
                    "Add_7371_0"
                ]
            },
            {
                "inputs": [
                    "Greater_7357",
                    "Reshape_7362",
                    "Broadcast_7356"
                ],
                "name": "Select_7363",
                "op": "Select",
                "outputs": [
                    "Select_7363_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7351",
            "Parameter_7352",
            "Parameter_7353",
            "Parameter_7354"
        ],
        "result": [
            "Select_7363",
            "Add_7371"
        ]
    }
]