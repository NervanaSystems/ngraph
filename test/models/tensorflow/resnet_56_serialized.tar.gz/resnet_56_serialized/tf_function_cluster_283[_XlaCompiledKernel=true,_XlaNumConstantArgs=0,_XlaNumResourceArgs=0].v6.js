[
    {
        "name": "Function_6",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_270",
                "op": "Parameter",
                "outputs": [
                    "Parameter_270_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_269",
                "op": "Parameter",
                "outputs": [
                    "Parameter_269_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_271",
                "op": "Constant",
                "outputs": [
                    "Constant_271_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_270"
                ],
                "name": "Reshape_275",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_275_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_271"
                ],
                "name": "Broadcast_272",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_272_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_272",
                    "Parameter_269"
                ],
                "name": "Maximum_273",
                "op": "Maximum",
                "outputs": [
                    "Maximum_273_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_273"
                ],
                "name": "Reshape_274",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_274_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_274",
                    "Reshape_275"
                ],
                "name": "Convolution_276",
                "op": "Convolution",
                "outputs": [
                    "Convolution_276_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_276"
                ],
                "name": "Reshape_277",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_277_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_269",
            "Parameter_270"
        ],
        "result": [
            "Reshape_277",
            "Maximum_273"
        ]
    }
]