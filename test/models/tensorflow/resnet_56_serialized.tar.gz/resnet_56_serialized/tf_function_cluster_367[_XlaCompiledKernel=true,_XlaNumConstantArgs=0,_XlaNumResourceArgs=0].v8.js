[
    {
        "name": "Function_27",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1245",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1245_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1244",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1244_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1243",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1243_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1246",
                "op": "Constant",
                "outputs": [
                    "Constant_1246_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1244"
                ],
                "name": "Reshape_1250",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1250_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1246"
                ],
                "name": "Broadcast_1247",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1247_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1247",
                    "Parameter_1243"
                ],
                "name": "Maximum_1248",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1248_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1248"
                ],
                "name": "Reshape_1249",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1249_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1249",
                    "Reshape_1250"
                ],
                "name": "Convolution_1251",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1251_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1251"
                ],
                "name": "Reshape_1252",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1252_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_1252",
                    "Parameter_1245"
                ],
                "name": "Add_1253",
                "op": "Add",
                "outputs": [
                    "Add_1253_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1243",
            "Parameter_1244",
            "Parameter_1245"
        ],
        "result": [
            "Add_1253",
            "Maximum_1248",
            "Reshape_1252"
        ]
    }
]