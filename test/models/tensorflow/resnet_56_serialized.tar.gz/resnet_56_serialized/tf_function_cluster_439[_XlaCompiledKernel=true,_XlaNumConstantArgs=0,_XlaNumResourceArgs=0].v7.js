[
    {
        "name": "Function_198",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10379",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10379_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10378",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10378_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10377",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10377_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10377"
                ],
                "name": "Broadcast_10380",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10380_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10378",
                    "Broadcast_10380"
                ],
                "name": "Multiply_10381",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10381_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10381",
                    "Parameter_10379"
                ],
                "name": "Add_10382",
                "op": "Add",
                "outputs": [
                    "Add_10382_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10377",
            "Parameter_10378",
            "Parameter_10379"
        ],
        "result": [
            "Add_10382"
        ]
    }
]