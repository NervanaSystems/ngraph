[
    {
        "name": "Function_135",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7375",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7375_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7374",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7374_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7373",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7373_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7373"
                ],
                "name": "Broadcast_7376",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7376_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7374",
                    "Broadcast_7376"
                ],
                "name": "Multiply_7377",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7377_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7377",
                    "Parameter_7375"
                ],
                "name": "Add_7378",
                "op": "Add",
                "outputs": [
                    "Add_7378_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7373",
            "Parameter_7374",
            "Parameter_7375"
        ],
        "result": [
            "Add_7378"
        ]
    }
]