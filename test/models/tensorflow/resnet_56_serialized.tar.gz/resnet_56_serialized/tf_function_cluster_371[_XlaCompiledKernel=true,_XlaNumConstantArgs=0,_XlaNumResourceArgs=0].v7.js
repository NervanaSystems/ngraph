[
    {
        "name": "Function_108",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6053",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6053_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6052",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6052_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6051",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6051_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6051"
                ],
                "name": "Broadcast_6054",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6054_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_6052",
                    "Broadcast_6054"
                ],
                "name": "Multiply_6055",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6055_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6055",
                    "Parameter_6053"
                ],
                "name": "Add_6056",
                "op": "Add",
                "outputs": [
                    "Add_6056_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6051",
            "Parameter_6052",
            "Parameter_6053"
        ],
        "result": [
            "Add_6056"
        ]
    }
]