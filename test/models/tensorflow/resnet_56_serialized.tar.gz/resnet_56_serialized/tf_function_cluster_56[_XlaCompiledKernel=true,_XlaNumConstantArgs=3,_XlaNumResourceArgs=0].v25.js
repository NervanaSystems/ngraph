[
    {
        "name": "Function_133",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7294",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7294_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7293",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7293_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7292",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7292_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7291",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7291_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7290",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7290_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_7295",
                "op": "Constant",
                "outputs": [
                    "Constant_7295_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7294"
                ],
                "name": "Reshape_7309",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7309_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7292",
                    "Parameter_7293"
                ],
                "name": "Add_7298",
                "op": "Add",
                "outputs": [
                    "Add_7298_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7291"
                ],
                "name": "Reverse_7300",
                "op": "Reverse",
                "outputs": [
                    "Reverse_7300_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_7290"
                ],
                "name": "Broadcast_7307",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7307_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_7295"
                ],
                "name": "Broadcast_7296",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7296_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_7298"
                ],
                "name": "Reshape_7306",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7306_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_7298"
                ],
                "name": "Reshape_7299",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7299_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_7300"
                ],
                "name": "Reshape_7302",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_7302_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7291",
                    "Broadcast_7307"
                ],
                "name": "Multiply_7308",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7308_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7294",
                    "Broadcast_7296"
                ],
                "name": "Greater_7297",
                "op": "Greater",
                "outputs": [
                    "Greater_7297_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_7299"
                ],
                "name": "Reshape_7310",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7310_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_7299"
                ],
                "name": "Reshape_7301",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7301_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7309",
                    "Reshape_7310"
                ],
                "name": "Convolution_7311",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7311_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7301",
                    "Reshape_7302"
                ],
                "name": "Convolution_7303",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7303_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_7311"
                ],
                "name": "Reshape_7312",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_7312_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_7303"
                ],
                "name": "Reshape_7304",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7304_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_7312"
                ],
                "name": "Reshape_7313",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_7313_0"
                ]
            },
            {
                "inputs": [
                    "Greater_7297",
                    "Reshape_7304",
                    "Broadcast_7296"
                ],
                "name": "Select_7305",
                "op": "Select",
                "outputs": [
                    "Select_7305_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7308",
                    "Reshape_7313"
                ],
                "name": "Add_7314",
                "op": "Add",
                "outputs": [
                    "Add_7314_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7290",
            "Parameter_7291",
            "Parameter_7292",
            "Parameter_7293",
            "Parameter_7294"
        ],
        "result": [
            "Select_7305",
            "Reshape_7306",
            "Add_7314"
        ]
    }
]