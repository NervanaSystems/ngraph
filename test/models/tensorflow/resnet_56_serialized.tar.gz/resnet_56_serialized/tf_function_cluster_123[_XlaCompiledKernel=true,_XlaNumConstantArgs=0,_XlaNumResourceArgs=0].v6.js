[
    {
        "name": "Function_42",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1944",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1944_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1943",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1943_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1945",
                "op": "Constant",
                "outputs": [
                    "Constant_1945_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1944"
                ],
                "name": "Reshape_1949",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1949_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1945"
                ],
                "name": "Broadcast_1946",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1946_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_1946",
                    "Parameter_1943"
                ],
                "name": "Maximum_1947",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1947_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1947"
                ],
                "name": "Reshape_1948",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_1948_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1948",
                    "Reshape_1949"
                ],
                "name": "Convolution_1950",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1950_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1950"
                ],
                "name": "Reshape_1951",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_1951_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1943",
            "Parameter_1944"
        ],
        "result": [
            "Reshape_1951",
            "Maximum_1947"
        ]
    }
]