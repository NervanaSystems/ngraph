[
    {
        "name": "Function_69",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4231",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4231_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4230",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4230_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4229",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4229_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4229"
                ],
                "name": "Broadcast_4232",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4232_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4230",
                    "Broadcast_4232"
                ],
                "name": "Multiply_4233",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4233_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4233",
                    "Parameter_4231"
                ],
                "name": "Add_4234",
                "op": "Add",
                "outputs": [
                    "Add_4234_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4229",
            "Parameter_4230",
            "Parameter_4231"
        ],
        "result": [
            "Add_4234"
        ]
    }
]