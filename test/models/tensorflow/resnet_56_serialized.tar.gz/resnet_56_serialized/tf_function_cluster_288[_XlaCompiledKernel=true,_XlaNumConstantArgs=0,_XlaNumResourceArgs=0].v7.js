[
    {
        "name": "Function_177",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9430",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9430_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9429",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9429_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9428",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9428_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9428"
                ],
                "name": "Broadcast_9431",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9431_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9429",
                    "Broadcast_9431"
                ],
                "name": "Multiply_9432",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9432_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9432",
                    "Parameter_9430"
                ],
                "name": "Add_9433",
                "op": "Add",
                "outputs": [
                    "Add_9433_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9428",
            "Parameter_9429",
            "Parameter_9430"
        ],
        "result": [
            "Add_9433"
        ]
    }
]