[
    {
        "name": "Function_153",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8218",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8218_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8217",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8217_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8216",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8216_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8216"
                ],
                "name": "Broadcast_8219",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8219_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8217",
                    "Broadcast_8219"
                ],
                "name": "Multiply_8220",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8220_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8220",
                    "Parameter_8218"
                ],
                "name": "Add_8221",
                "op": "Add",
                "outputs": [
                    "Add_8221_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8216",
            "Parameter_8217",
            "Parameter_8218"
        ],
        "result": [
            "Add_8221"
        ]
    }
]