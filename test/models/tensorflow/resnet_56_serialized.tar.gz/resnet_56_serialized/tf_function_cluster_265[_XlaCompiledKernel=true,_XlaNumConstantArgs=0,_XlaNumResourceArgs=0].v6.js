[
    {
        "name": "Function_24",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1107",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1107_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1106",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1106_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1108",
                "op": "Constant",
                "outputs": [
                    "Constant_1108_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1107"
                ],
                "name": "Reshape_1112",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1112_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1108"
                ],
                "name": "Broadcast_1109",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1109_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1109",
                    "Parameter_1106"
                ],
                "name": "Maximum_1110",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1110_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1110"
                ],
                "name": "Reshape_1111",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1111_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1111",
                    "Reshape_1112"
                ],
                "name": "Convolution_1113",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1113_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1113"
                ],
                "name": "Reshape_1114",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1114_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1106",
            "Parameter_1107"
        ],
        "result": [
            "Reshape_1114",
            "Maximum_1110"
        ]
    }
]