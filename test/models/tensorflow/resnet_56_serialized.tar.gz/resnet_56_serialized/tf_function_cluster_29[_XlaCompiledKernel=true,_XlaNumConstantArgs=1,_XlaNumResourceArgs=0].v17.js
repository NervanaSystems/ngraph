[
    {
        "name": "Function_184",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9744",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9744_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9743",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9743_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9742",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9742_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9741",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9741_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_9745",
                "op": "Constant",
                "outputs": [
                    "Constant_9745_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9744"
                ],
                "name": "Reshape_9757",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9757_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9744"
                ],
                "name": "Reshape_9749",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9749_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9743"
                ],
                "name": "Reshape_9756",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9756_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9742"
                ],
                "name": "Reverse_9748",
                "op": "Reverse",
                "outputs": [
                    "Reverse_9748_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_9741"
                ],
                "name": "Broadcast_9754",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9754_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_9745"
                ],
                "name": "Broadcast_9746",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9746_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9756",
                    "Reshape_9757"
                ],
                "name": "Convolution_9758",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9758_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_9748"
                ],
                "name": "Reshape_9750",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_9750_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9742",
                    "Broadcast_9754"
                ],
                "name": "Multiply_9755",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9755_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9743",
                    "Broadcast_9746"
                ],
                "name": "Greater_9747",
                "op": "Greater",
                "outputs": [
                    "Greater_9747_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_9758"
                ],
                "name": "Reshape_9759",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_9759_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9749",
                    "Reshape_9750"
                ],
                "name": "Convolution_9751",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9751_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_9759"
                ],
                "name": "Reshape_9760",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_9760_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_9751"
                ],
                "name": "Reshape_9752",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9752_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9755",
                    "Reshape_9760"
                ],
                "name": "Add_9761",
                "op": "Add",
                "outputs": [
                    "Add_9761_0"
                ]
            },
            {
                "inputs": [
                    "Greater_9747",
                    "Reshape_9752",
                    "Broadcast_9746"
                ],
                "name": "Select_9753",
                "op": "Select",
                "outputs": [
                    "Select_9753_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9741",
            "Parameter_9742",
            "Parameter_9743",
            "Parameter_9744"
        ],
        "result": [
            "Select_9753",
            "Add_9761"
        ]
    }
]