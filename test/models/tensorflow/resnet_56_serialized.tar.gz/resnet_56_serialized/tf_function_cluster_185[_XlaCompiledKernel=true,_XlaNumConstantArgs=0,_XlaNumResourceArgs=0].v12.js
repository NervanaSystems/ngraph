[
    {
        "name": "Function_20",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_914",
                "op": "Parameter",
                "outputs": [
                    "Parameter_914_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_913",
                "op": "Parameter",
                "outputs": [
                    "Parameter_913_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_918",
                "op": "Constant",
                "outputs": [
                    "Constant_918_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_915",
                "op": "Constant",
                "outputs": [
                    "Constant_915_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_924",
                "op": "Constant",
                "outputs": [
                    "Constant_924_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_914"
                ],
                "name": "Reshape_921",
                "op": "Reshape",
                "output_shape": [
                    32,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_921_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_915"
                ],
                "name": "Broadcast_916",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_916_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_916",
                    "Parameter_913"
                ],
                "name": "Maximum_917",
                "op": "Maximum",
                "outputs": [
                    "Maximum_917_0"
                ]
            },
            {
                "inputs": [
                    "Maximum_917",
                    "Constant_924"
                ],
                "name": "Pad_925",
                "op": "Pad",
                "outputs": [
                    "Pad_925_0"
                ],
                "padding_above": [
                    0,
                    0,
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0,
                    0,
                    0
                ],
                "padding_interior": [
                    0,
                    0,
                    0,
                    0
                ]
            },
            {
                "inputs": [
                    "Maximum_917",
                    "Constant_918"
                ],
                "name": "Pad_919",
                "op": "Pad",
                "outputs": [
                    "Pad_919_0"
                ],
                "padding_above": [
                    0,
                    1,
                    1,
                    0
                ],
                "padding_below": [
                    0,
                    1,
                    1,
                    0
                ],
                "padding_interior": [
                    0,
                    0,
                    0,
                    0
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Pad_919"
                ],
                "name": "Reshape_920",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    34,
                    34
                ],
                "outputs": [
                    "Reshape_920_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_920",
                    "Reshape_921"
                ],
                "name": "Convolution_922",
                "op": "Convolution",
                "outputs": [
                    "Convolution_922_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    2,
                    2
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_922"
                ],
                "name": "Reshape_923",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_923_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_913",
            "Parameter_914"
        ],
        "result": [
            "Reshape_923",
            "Pad_925",
            "Maximum_917",
            "Pad_919"
        ]
    }
]