[
    {
        "name": "Function_223",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11588",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11588_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11587",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11587_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11586",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11586_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_11586"
                ],
                "name": "Broadcast_11589",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11589_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_11587",
                    "Broadcast_11589"
                ],
                "name": "Multiply_11590",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11590_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11590",
                    "Parameter_11588"
                ],
                "name": "Add_11591",
                "op": "Add",
                "outputs": [
                    "Add_11591_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_11586",
            "Parameter_11587",
            "Parameter_11588"
        ],
        "result": [
            "Add_11591"
        ]
    }
]