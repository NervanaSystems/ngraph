[
    {
        "name": "Function_129",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7124",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7124_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7123",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7123_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7122",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7122_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7122"
                ],
                "name": "Broadcast_7125",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7125_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7123",
                    "Broadcast_7125"
                ],
                "name": "Multiply_7126",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7126_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7126",
                    "Parameter_7124"
                ],
                "name": "Add_7127",
                "op": "Add",
                "outputs": [
                    "Add_7127_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7122",
            "Parameter_7123",
            "Parameter_7124"
        ],
        "result": [
            "Add_7127"
        ]
    }
]