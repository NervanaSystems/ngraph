[
    {
        "name": "Function_157",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8438",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8438_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8437",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8437_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8436",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8436_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8435",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8435_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8434",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8434_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_8441",
                "op": "Constant",
                "outputs": [
                    "Constant_8441_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8438"
                ],
                "name": "Reshape_8453",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8453_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8436",
                    "Parameter_8437"
                ],
                "name": "Add_8439",
                "op": "Add",
                "outputs": [
                    "Add_8439_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8435"
                ],
                "name": "Reverse_8445",
                "op": "Reverse",
                "outputs": [
                    "Reverse_8445_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_8434"
                ],
                "name": "Broadcast_8451",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8451_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_8441"
                ],
                "name": "Broadcast_8442",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8442_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_8439"
                ],
                "name": "Reshape_8444",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8444_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_8439"
                ],
                "name": "Reshape_8440",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8440_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_8445"
                ],
                "name": "Reshape_8447",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_8447_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8435",
                    "Broadcast_8451"
                ],
                "name": "Multiply_8452",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8452_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8438",
                    "Broadcast_8442"
                ],
                "name": "Greater_8443",
                "op": "Greater",
                "outputs": [
                    "Greater_8443_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_8444"
                ],
                "name": "Reshape_8454",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8454_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_8444"
                ],
                "name": "Reshape_8446",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8446_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8453",
                    "Reshape_8454"
                ],
                "name": "Convolution_8455",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8455_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8446",
                    "Reshape_8447"
                ],
                "name": "Convolution_8448",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8448_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_8455"
                ],
                "name": "Reshape_8456",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_8456_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_8448"
                ],
                "name": "Reshape_8449",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8449_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_8456"
                ],
                "name": "Reshape_8457",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_8457_0"
                ]
            },
            {
                "inputs": [
                    "Greater_8443",
                    "Reshape_8449",
                    "Broadcast_8442"
                ],
                "name": "Select_8450",
                "op": "Select",
                "outputs": [
                    "Select_8450_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8452",
                    "Reshape_8457"
                ],
                "name": "Add_8458",
                "op": "Add",
                "outputs": [
                    "Add_8458_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8434",
            "Parameter_8435",
            "Parameter_8436",
            "Parameter_8437",
            "Parameter_8438"
        ],
        "result": [
            "Reshape_8440",
            "Select_8450",
            "Add_8458"
        ]
    }
]