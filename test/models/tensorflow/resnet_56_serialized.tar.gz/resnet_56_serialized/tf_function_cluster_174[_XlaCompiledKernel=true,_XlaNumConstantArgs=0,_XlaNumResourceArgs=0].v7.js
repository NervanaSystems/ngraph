[
    {
        "name": "Function_160",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8596",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8596_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8595",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8595_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8594",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8594_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8594"
                ],
                "name": "Broadcast_8597",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8597_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8595",
                    "Broadcast_8597"
                ],
                "name": "Multiply_8598",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8598_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8598",
                    "Parameter_8596"
                ],
                "name": "Add_8599",
                "op": "Add",
                "outputs": [
                    "Add_8599_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8594",
            "Parameter_8595",
            "Parameter_8596"
        ],
        "result": [
            "Add_8599"
        ]
    }
]