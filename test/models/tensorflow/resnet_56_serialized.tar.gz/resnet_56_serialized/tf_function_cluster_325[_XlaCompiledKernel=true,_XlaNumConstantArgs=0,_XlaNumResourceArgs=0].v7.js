[
    {
        "name": "Function_140",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7639",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7639_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7638",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7638_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7637",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7637_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7637"
                ],
                "name": "Broadcast_7640",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7640_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7638",
                    "Broadcast_7640"
                ],
                "name": "Multiply_7641",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7641_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7641",
                    "Parameter_7639"
                ],
                "name": "Add_7642",
                "op": "Add",
                "outputs": [
                    "Add_7642_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7637",
            "Parameter_7638",
            "Parameter_7639"
        ],
        "result": [
            "Add_7642"
        ]
    }
]