[
    {
        "name": "Function_118",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6559",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6559_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6558",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6558_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6557",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6557_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6557"
                ],
                "name": "Broadcast_6560",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6560_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6558",
                    "Broadcast_6560"
                ],
                "name": "Multiply_6561",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6561_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6561",
                    "Parameter_6559"
                ],
                "name": "Add_6562",
                "op": "Add",
                "outputs": [
                    "Add_6562_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6557",
            "Parameter_6558",
            "Parameter_6559"
        ],
        "result": [
            "Add_6562"
        ]
    }
]