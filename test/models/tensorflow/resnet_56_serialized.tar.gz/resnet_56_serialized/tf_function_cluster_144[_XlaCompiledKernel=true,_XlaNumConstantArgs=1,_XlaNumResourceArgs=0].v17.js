[
    {
        "name": "Function_116",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6496",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6496_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6495",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6495_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6494",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6494_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6493",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6493_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_6497",
                "op": "Constant",
                "outputs": [
                    "Constant_6497_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6496"
                ],
                "name": "Reshape_6501",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6501_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6496"
                ],
                "name": "Reshape_6509",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6509_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6495"
                ],
                "name": "Reshape_6508",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6508_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6494"
                ],
                "name": "Reverse_6500",
                "op": "Reverse",
                "outputs": [
                    "Reverse_6500_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_6493"
                ],
                "name": "Broadcast_6506",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6506_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_6497"
                ],
                "name": "Broadcast_6498",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6498_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6508",
                    "Reshape_6509"
                ],
                "name": "Convolution_6510",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6510_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_6500"
                ],
                "name": "Reshape_6502",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_6502_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6494",
                    "Broadcast_6506"
                ],
                "name": "Multiply_6507",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6507_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6495",
                    "Broadcast_6498"
                ],
                "name": "Greater_6499",
                "op": "Greater",
                "outputs": [
                    "Greater_6499_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_6510"
                ],
                "name": "Reshape_6511",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_6511_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6501",
                    "Reshape_6502"
                ],
                "name": "Convolution_6503",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6503_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_6511"
                ],
                "name": "Reshape_6512",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_6512_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_6503"
                ],
                "name": "Reshape_6504",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_6504_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6507",
                    "Reshape_6512"
                ],
                "name": "Add_6513",
                "op": "Add",
                "outputs": [
                    "Add_6513_0"
                ]
            },
            {
                "inputs": [
                    "Greater_6499",
                    "Reshape_6504",
                    "Broadcast_6498"
                ],
                "name": "Select_6505",
                "op": "Select",
                "outputs": [
                    "Select_6505_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6493",
            "Parameter_6494",
            "Parameter_6495",
            "Parameter_6496"
        ],
        "result": [
            "Select_6505",
            "Add_6513"
        ]
    }
]