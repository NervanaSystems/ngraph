[
    {
        "name": "Function_30",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1383",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1383_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1382",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1382_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1384",
                "op": "Constant",
                "outputs": [
                    "Constant_1384_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1383"
                ],
                "name": "Reshape_1388",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1388_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1384"
                ],
                "name": "Broadcast_1385",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1385_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1385",
                    "Parameter_1382"
                ],
                "name": "Maximum_1386",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1386_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1386"
                ],
                "name": "Reshape_1387",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1387_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1387",
                    "Reshape_1388"
                ],
                "name": "Convolution_1389",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1389_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1389"
                ],
                "name": "Reshape_1390",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1390_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1382",
            "Parameter_1383"
        ],
        "result": [
            "Reshape_1390",
            "Maximum_1386"
        ]
    }
]