[
    {
        "name": "Function_115",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6383",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6383_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6382",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6382_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6381",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6381_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6381"
                ],
                "name": "Broadcast_6384",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6384_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6382",
                    "Broadcast_6384"
                ],
                "name": "Multiply_6385",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6385_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6385",
                    "Parameter_6383"
                ],
                "name": "Add_6386",
                "op": "Add",
                "outputs": [
                    "Add_6386_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6381",
            "Parameter_6382",
            "Parameter_6383"
        ],
        "result": [
            "Add_6386"
        ]
    }
]