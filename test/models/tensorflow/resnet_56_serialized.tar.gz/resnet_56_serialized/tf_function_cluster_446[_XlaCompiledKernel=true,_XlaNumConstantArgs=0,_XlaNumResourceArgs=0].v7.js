[
    {
        "name": "Function_189",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9987",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9987_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9986",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9986_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9985",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9985_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9985"
                ],
                "name": "Broadcast_9988",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9988_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9986",
                    "Broadcast_9988"
                ],
                "name": "Multiply_9989",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9989_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9989",
                    "Parameter_9987"
                ],
                "name": "Add_9990",
                "op": "Add",
                "outputs": [
                    "Add_9990_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9985",
            "Parameter_9986",
            "Parameter_9987"
        ],
        "result": [
            "Add_9990"
        ]
    }
]