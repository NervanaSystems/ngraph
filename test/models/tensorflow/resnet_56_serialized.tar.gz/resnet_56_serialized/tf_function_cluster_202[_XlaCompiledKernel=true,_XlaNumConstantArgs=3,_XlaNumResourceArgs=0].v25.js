[
    {
        "name": "Function_150",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8110",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8110_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8109",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8109_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8108",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8108_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8107",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8107_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8106",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8106_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_8113",
                "op": "Constant",
                "outputs": [
                    "Constant_8113_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8110"
                ],
                "name": "Reshape_8125",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8125_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8108",
                    "Parameter_8109"
                ],
                "name": "Add_8111",
                "op": "Add",
                "outputs": [
                    "Add_8111_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8107"
                ],
                "name": "Reverse_8117",
                "op": "Reverse",
                "outputs": [
                    "Reverse_8117_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_8106"
                ],
                "name": "Broadcast_8123",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8123_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_8113"
                ],
                "name": "Broadcast_8114",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8114_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_8111"
                ],
                "name": "Reshape_8116",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8116_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_8111"
                ],
                "name": "Reshape_8112",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8112_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_8117"
                ],
                "name": "Reshape_8119",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_8119_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8107",
                    "Broadcast_8123"
                ],
                "name": "Multiply_8124",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8124_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8110",
                    "Broadcast_8114"
                ],
                "name": "Greater_8115",
                "op": "Greater",
                "outputs": [
                    "Greater_8115_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_8116"
                ],
                "name": "Reshape_8126",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8126_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_8116"
                ],
                "name": "Reshape_8118",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8118_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8125",
                    "Reshape_8126"
                ],
                "name": "Convolution_8127",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8127_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8118",
                    "Reshape_8119"
                ],
                "name": "Convolution_8120",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8120_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_8127"
                ],
                "name": "Reshape_8128",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_8128_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_8120"
                ],
                "name": "Reshape_8121",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8121_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_8128"
                ],
                "name": "Reshape_8129",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_8129_0"
                ]
            },
            {
                "inputs": [
                    "Greater_8115",
                    "Reshape_8121",
                    "Broadcast_8114"
                ],
                "name": "Select_8122",
                "op": "Select",
                "outputs": [
                    "Select_8122_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8124",
                    "Reshape_8129"
                ],
                "name": "Add_8130",
                "op": "Add",
                "outputs": [
                    "Add_8130_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8106",
            "Parameter_8107",
            "Parameter_8108",
            "Parameter_8109",
            "Parameter_8110"
        ],
        "result": [
            "Reshape_8112",
            "Select_8122",
            "Add_8130"
        ]
    }
]