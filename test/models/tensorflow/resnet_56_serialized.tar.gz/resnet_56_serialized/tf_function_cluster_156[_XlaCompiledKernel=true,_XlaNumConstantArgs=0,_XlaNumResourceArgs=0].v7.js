[
    {
        "name": "Function_208",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10832",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10832_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10831",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10831_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10830",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10830_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10830"
                ],
                "name": "Broadcast_10833",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10833_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10831",
                    "Broadcast_10833"
                ],
                "name": "Multiply_10834",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10834_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10834",
                    "Parameter_10832"
                ],
                "name": "Add_10835",
                "op": "Add",
                "outputs": [
                    "Add_10835_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10830",
            "Parameter_10831",
            "Parameter_10832"
        ],
        "result": [
            "Add_10835"
        ]
    }
]