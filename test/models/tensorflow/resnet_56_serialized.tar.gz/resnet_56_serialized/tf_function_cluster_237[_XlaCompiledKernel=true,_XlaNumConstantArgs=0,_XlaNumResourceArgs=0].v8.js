[
    {
        "name": "Function_7",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_316",
                "op": "Parameter",
                "outputs": [
                    "Parameter_316_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_315",
                "op": "Parameter",
                "outputs": [
                    "Parameter_315_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_314",
                "op": "Parameter",
                "outputs": [
                    "Parameter_314_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_317",
                "op": "Constant",
                "outputs": [
                    "Constant_317_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_315"
                ],
                "name": "Reshape_321",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_321_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_317"
                ],
                "name": "Broadcast_318",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_318_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_318",
                    "Parameter_314"
                ],
                "name": "Maximum_319",
                "op": "Maximum",
                "outputs": [
                    "Maximum_319_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_319"
                ],
                "name": "Reshape_320",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_320_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_320",
                    "Reshape_321"
                ],
                "name": "Convolution_322",
                "op": "Convolution",
                "outputs": [
                    "Convolution_322_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_322"
                ],
                "name": "Reshape_323",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_323_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_323",
                    "Parameter_316"
                ],
                "name": "Add_324",
                "op": "Add",
                "outputs": [
                    "Add_324_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_314",
            "Parameter_315",
            "Parameter_316"
        ],
        "result": [
            "Add_324",
            "Maximum_319",
            "Reshape_323"
        ]
    }
]