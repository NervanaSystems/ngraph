[
    {
        "name": "Function_8",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_362",
                "op": "Parameter",
                "outputs": [
                    "Parameter_362_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_361",
                "op": "Parameter",
                "outputs": [
                    "Parameter_361_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_363",
                "op": "Constant",
                "outputs": [
                    "Constant_363_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_362"
                ],
                "name": "Reshape_367",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_367_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_363"
                ],
                "name": "Broadcast_364",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_364_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_364",
                    "Parameter_361"
                ],
                "name": "Maximum_365",
                "op": "Maximum",
                "outputs": [
                    "Maximum_365_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_365"
                ],
                "name": "Reshape_366",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_366_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_366",
                    "Reshape_367"
                ],
                "name": "Convolution_368",
                "op": "Convolution",
                "outputs": [
                    "Convolution_368_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_368"
                ],
                "name": "Reshape_369",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_369_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_361",
            "Parameter_362"
        ],
        "result": [
            "Reshape_369",
            "Maximum_365"
        ]
    }
]