[
    {
        "name": "Function_120",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6662",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6662_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6661",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6661_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6660",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6660_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6660"
                ],
                "name": "Broadcast_6663",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6663_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6661",
                    "Broadcast_6663"
                ],
                "name": "Multiply_6664",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6664_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6664",
                    "Parameter_6662"
                ],
                "name": "Add_6665",
                "op": "Add",
                "outputs": [
                    "Add_6665_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6660",
            "Parameter_6661",
            "Parameter_6662"
        ],
        "result": [
            "Add_6665"
        ]
    }
]