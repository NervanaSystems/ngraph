[
    {
        "name": "Function_110",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6191",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6191_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6190",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6190_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6189",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6189_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6189"
                ],
                "name": "Broadcast_6192",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6192_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_6190",
                    "Broadcast_6192"
                ],
                "name": "Multiply_6193",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6193_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6193",
                    "Parameter_6191"
                ],
                "name": "Add_6194",
                "op": "Add",
                "outputs": [
                    "Add_6194_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6189",
            "Parameter_6190",
            "Parameter_6191"
        ],
        "result": [
            "Add_6194"
        ]
    }
]