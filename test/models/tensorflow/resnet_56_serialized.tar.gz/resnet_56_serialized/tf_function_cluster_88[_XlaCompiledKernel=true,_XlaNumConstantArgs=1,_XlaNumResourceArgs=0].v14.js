[
    {
        "name": "Function_222",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11576",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11576_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11575",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11575_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    3
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11574",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11574_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11573",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11573_0"
                ],
                "shape": [
                    3,
                    3,
                    3,
                    16
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11576"
                ],
                "name": "Reshape_11580",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11580_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11575"
                ],
                "name": "Reshape_11579",
                "op": "Reshape",
                "output_shape": [
                    3,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11579_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_11574"
                ],
                "name": "Broadcast_11577",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11577_0"
                ],
                "shape": [
                    3,
                    3,
                    3,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11579",
                    "Reshape_11580"
                ],
                "name": "Convolution_11581",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11581_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "inputs": [
                    "Parameter_11573",
                    "Broadcast_11577"
                ],
                "name": "Multiply_11578",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11578_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_11581"
                ],
                "name": "Reshape_11582",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_11582_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_11582"
                ],
                "name": "Reshape_11583",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_11583_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11578",
                    "Reshape_11583"
                ],
                "name": "Add_11584",
                "op": "Add",
                "outputs": [
                    "Add_11584_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_11573",
            "Parameter_11574",
            "Parameter_11575",
            "Parameter_11576"
        ],
        "result": [
            "Add_11584"
        ]
    }
]