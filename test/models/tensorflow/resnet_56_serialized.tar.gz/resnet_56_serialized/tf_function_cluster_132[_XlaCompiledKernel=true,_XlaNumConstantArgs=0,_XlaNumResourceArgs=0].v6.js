[
    {
        "name": "Function_34",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1567",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1567_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1566",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1566_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1568",
                "op": "Constant",
                "outputs": [
                    "Constant_1568_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1567"
                ],
                "name": "Reshape_1572",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1572_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1568"
                ],
                "name": "Broadcast_1569",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1569_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1569",
                    "Parameter_1566"
                ],
                "name": "Maximum_1570",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1570_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1570"
                ],
                "name": "Reshape_1571",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1571_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1571",
                    "Reshape_1572"
                ],
                "name": "Convolution_1573",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1573_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1573"
                ],
                "name": "Reshape_1574",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1574_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1566",
            "Parameter_1567"
        ],
        "result": [
            "Reshape_1574",
            "Maximum_1570"
        ]
    }
]