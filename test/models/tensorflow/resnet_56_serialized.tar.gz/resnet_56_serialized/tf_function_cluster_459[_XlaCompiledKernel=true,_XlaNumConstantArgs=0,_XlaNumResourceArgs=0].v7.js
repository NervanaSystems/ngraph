[
    {
        "name": "Function_221",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11533",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11533_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11532",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11532_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11531",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11531_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_11531"
                ],
                "name": "Broadcast_11534",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11534_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_11532",
                    "Broadcast_11534"
                ],
                "name": "Multiply_11535",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11535_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11535",
                    "Parameter_11533"
                ],
                "name": "Add_11536",
                "op": "Add",
                "outputs": [
                    "Add_11536_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_11531",
            "Parameter_11532",
            "Parameter_11533"
        ],
        "result": [
            "Add_11536"
        ]
    }
]