[
    {
        "name": "Function_28",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1291",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1291_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1290",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1290_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1292",
                "op": "Constant",
                "outputs": [
                    "Constant_1292_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1291"
                ],
                "name": "Reshape_1296",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1296_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1292"
                ],
                "name": "Broadcast_1293",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1293_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1293",
                    "Parameter_1290"
                ],
                "name": "Maximum_1294",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1294_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1294"
                ],
                "name": "Reshape_1295",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1295_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1295",
                    "Reshape_1296"
                ],
                "name": "Convolution_1297",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1297_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1297"
                ],
                "name": "Reshape_1298",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1298_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1290",
            "Parameter_1291"
        ],
        "result": [
            "Reshape_1298",
            "Maximum_1294"
        ]
    }
]