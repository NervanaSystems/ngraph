[
    {
        "name": "Function_131",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7208",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7208_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7207",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7207_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7206",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7206_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7206"
                ],
                "name": "Broadcast_7209",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7209_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7207",
                    "Broadcast_7209"
                ],
                "name": "Multiply_7210",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7210_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7210",
                    "Parameter_7208"
                ],
                "name": "Add_7211",
                "op": "Add",
                "outputs": [
                    "Add_7211_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7206",
            "Parameter_7207",
            "Parameter_7208"
        ],
        "result": [
            "Add_7211"
        ]
    }
]