[
    {
        "name": "Function_82",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4846",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4846_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4845",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4845_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4844",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4844_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4843",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4843_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_4847",
                "op": "Constant",
                "outputs": [
                    "Constant_4847_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4846"
                ],
                "name": "Reshape_4851",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4851_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4846"
                ],
                "name": "Reshape_4859",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4859_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4845"
                ],
                "name": "Reshape_4858",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4858_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4844"
                ],
                "name": "Reverse_4850",
                "op": "Reverse",
                "outputs": [
                    "Reverse_4850_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_4843"
                ],
                "name": "Broadcast_4856",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4856_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_4847"
                ],
                "name": "Broadcast_4848",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4848_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4858",
                    "Reshape_4859"
                ],
                "name": "Convolution_4860",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4860_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_4850"
                ],
                "name": "Reshape_4852",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_4852_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4844",
                    "Broadcast_4856"
                ],
                "name": "Multiply_4857",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4857_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4845",
                    "Broadcast_4848"
                ],
                "name": "Greater_4849",
                "op": "Greater",
                "outputs": [
                    "Greater_4849_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_4860"
                ],
                "name": "Reshape_4861",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_4861_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4851",
                    "Reshape_4852"
                ],
                "name": "Convolution_4853",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4853_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_4861"
                ],
                "name": "Reshape_4862",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_4862_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_4853"
                ],
                "name": "Reshape_4854",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4854_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4857",
                    "Reshape_4862"
                ],
                "name": "Add_4863",
                "op": "Add",
                "outputs": [
                    "Add_4863_0"
                ]
            },
            {
                "inputs": [
                    "Greater_4849",
                    "Reshape_4854",
                    "Broadcast_4848"
                ],
                "name": "Select_4855",
                "op": "Select",
                "outputs": [
                    "Select_4855_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4843",
            "Parameter_4844",
            "Parameter_4845",
            "Parameter_4846"
        ],
        "result": [
            "Select_4855",
            "Add_4863"
        ]
    }
]