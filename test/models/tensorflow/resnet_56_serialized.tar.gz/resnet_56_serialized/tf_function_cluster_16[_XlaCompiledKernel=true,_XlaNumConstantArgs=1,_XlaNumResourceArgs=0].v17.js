[
    {
        "name": "Function_202",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10567",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10567_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10566",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10566_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10565",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10565_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10564",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10564_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_10568",
                "op": "Constant",
                "outputs": [
                    "Constant_10568_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10567"
                ],
                "name": "Reshape_10580",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10580_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10567"
                ],
                "name": "Reshape_10572",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10572_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10566"
                ],
                "name": "Reshape_10579",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10579_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10565"
                ],
                "name": "Reverse_10571",
                "op": "Reverse",
                "outputs": [
                    "Reverse_10571_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_10564"
                ],
                "name": "Broadcast_10577",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10577_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_10568"
                ],
                "name": "Broadcast_10569",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10569_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10579",
                    "Reshape_10580"
                ],
                "name": "Convolution_10581",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10581_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_10571"
                ],
                "name": "Reshape_10573",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_10573_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10565",
                    "Broadcast_10577"
                ],
                "name": "Multiply_10578",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10578_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10566",
                    "Broadcast_10569"
                ],
                "name": "Greater_10570",
                "op": "Greater",
                "outputs": [
                    "Greater_10570_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_10581"
                ],
                "name": "Reshape_10582",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_10582_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10572",
                    "Reshape_10573"
                ],
                "name": "Convolution_10574",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10574_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_10582"
                ],
                "name": "Reshape_10583",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_10583_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_10574"
                ],
                "name": "Reshape_10575",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10575_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10578",
                    "Reshape_10583"
                ],
                "name": "Add_10584",
                "op": "Add",
                "outputs": [
                    "Add_10584_0"
                ]
            },
            {
                "inputs": [
                    "Greater_10570",
                    "Reshape_10575",
                    "Broadcast_10569"
                ],
                "name": "Select_10576",
                "op": "Select",
                "outputs": [
                    "Select_10576_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10564",
            "Parameter_10565",
            "Parameter_10566",
            "Parameter_10567"
        ],
        "result": [
            "Select_10576",
            "Add_10584"
        ]
    }
]