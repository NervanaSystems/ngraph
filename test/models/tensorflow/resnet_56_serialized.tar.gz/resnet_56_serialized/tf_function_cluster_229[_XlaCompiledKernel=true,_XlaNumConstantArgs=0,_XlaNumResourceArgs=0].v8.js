[
    {
        "name": "Function_5",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_224",
                "op": "Parameter",
                "outputs": [
                    "Parameter_224_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_223",
                "op": "Parameter",
                "outputs": [
                    "Parameter_223_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_222",
                "op": "Parameter",
                "outputs": [
                    "Parameter_222_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_225",
                "op": "Constant",
                "outputs": [
                    "Constant_225_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_223"
                ],
                "name": "Reshape_229",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_229_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_225"
                ],
                "name": "Broadcast_226",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_226_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_226",
                    "Parameter_222"
                ],
                "name": "Maximum_227",
                "op": "Maximum",
                "outputs": [
                    "Maximum_227_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_227"
                ],
                "name": "Reshape_228",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_228_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_228",
                    "Reshape_229"
                ],
                "name": "Convolution_230",
                "op": "Convolution",
                "outputs": [
                    "Convolution_230_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_230"
                ],
                "name": "Reshape_231",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_231_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_231",
                    "Parameter_224"
                ],
                "name": "Add_232",
                "op": "Add",
                "outputs": [
                    "Add_232_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_222",
            "Parameter_223",
            "Parameter_224"
        ],
        "result": [
            "Add_232",
            "Maximum_227",
            "Reshape_231"
        ]
    }
]