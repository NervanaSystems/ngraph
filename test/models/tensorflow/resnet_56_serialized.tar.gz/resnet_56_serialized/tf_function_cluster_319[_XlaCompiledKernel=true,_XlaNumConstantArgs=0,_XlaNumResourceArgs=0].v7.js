[
    {
        "name": "Function_126",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6964",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6964_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6963",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6963_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6962",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6962_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6962"
                ],
                "name": "Broadcast_6965",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6965_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6963",
                    "Broadcast_6965"
                ],
                "name": "Multiply_6966",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6966_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6966",
                    "Parameter_6964"
                ],
                "name": "Add_6967",
                "op": "Add",
                "outputs": [
                    "Add_6967_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6962",
            "Parameter_6963",
            "Parameter_6964"
        ],
        "result": [
            "Add_6967"
        ]
    }
]