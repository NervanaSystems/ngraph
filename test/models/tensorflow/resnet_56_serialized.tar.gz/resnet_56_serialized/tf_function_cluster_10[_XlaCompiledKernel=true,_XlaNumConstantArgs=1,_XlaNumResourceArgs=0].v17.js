[
    {
        "name": "Function_214",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11174",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11174_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11173",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11173_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11172",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11172_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11171",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11171_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_11175",
                "op": "Constant",
                "outputs": [
                    "Constant_11175_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11174"
                ],
                "name": "Reshape_11179",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11179_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11174"
                ],
                "name": "Reshape_11187",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11187_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11173"
                ],
                "name": "Reshape_11186",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11186_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_11172"
                ],
                "name": "Reverse_11178",
                "op": "Reverse",
                "outputs": [
                    "Reverse_11178_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_11171"
                ],
                "name": "Broadcast_11184",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11184_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_11175"
                ],
                "name": "Broadcast_11176",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11176_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11186",
                    "Reshape_11187"
                ],
                "name": "Convolution_11188",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11188_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_11178"
                ],
                "name": "Reshape_11180",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_11180_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_11172",
                    "Broadcast_11184"
                ],
                "name": "Multiply_11185",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11185_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_11173",
                    "Broadcast_11176"
                ],
                "name": "Greater_11177",
                "op": "Greater",
                "outputs": [
                    "Greater_11177_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_11188"
                ],
                "name": "Reshape_11189",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_11189_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11179",
                    "Reshape_11180"
                ],
                "name": "Convolution_11181",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11181_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_11189"
                ],
                "name": "Reshape_11190",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_11190_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_11181"
                ],
                "name": "Reshape_11182",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_11182_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11185",
                    "Reshape_11190"
                ],
                "name": "Add_11191",
                "op": "Add",
                "outputs": [
                    "Add_11191_0"
                ]
            },
            {
                "inputs": [
                    "Greater_11177",
                    "Reshape_11182",
                    "Broadcast_11176"
                ],
                "name": "Select_11183",
                "op": "Select",
                "outputs": [
                    "Select_11183_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_11171",
            "Parameter_11172",
            "Parameter_11173",
            "Parameter_11174"
        ],
        "result": [
            "Select_11183",
            "Add_11191"
        ]
    }
]