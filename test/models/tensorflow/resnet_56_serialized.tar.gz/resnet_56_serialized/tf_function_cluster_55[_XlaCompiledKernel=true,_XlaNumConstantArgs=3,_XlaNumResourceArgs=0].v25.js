[
    {
        "name": "Function_109",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6132",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6132_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6131",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6131_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6130",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6130_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6129",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6129_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6128",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6128_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_6135",
                "op": "Constant",
                "outputs": [
                    "Constant_6135_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6132"
                ],
                "name": "Reshape_6147",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_6147_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6130",
                    "Parameter_6131"
                ],
                "name": "Add_6133",
                "op": "Add",
                "outputs": [
                    "Add_6133_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6129"
                ],
                "name": "Reverse_6139",
                "op": "Reverse",
                "outputs": [
                    "Reverse_6139_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_6128"
                ],
                "name": "Broadcast_6145",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6145_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_6135"
                ],
                "name": "Broadcast_6136",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6136_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_6133"
                ],
                "name": "Reshape_6134",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_6134_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_6133"
                ],
                "name": "Reshape_6138",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_6138_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_6139"
                ],
                "name": "Reshape_6141",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_6141_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6129",
                    "Broadcast_6145"
                ],
                "name": "Multiply_6146",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6146_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6132",
                    "Broadcast_6136"
                ],
                "name": "Greater_6137",
                "op": "Greater",
                "outputs": [
                    "Greater_6137_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_6138"
                ],
                "name": "Reshape_6148",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_6148_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_6138"
                ],
                "name": "Reshape_6140",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_6140_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6147",
                    "Reshape_6148"
                ],
                "name": "Convolution_6149",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6149_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6140",
                    "Reshape_6141"
                ],
                "name": "Convolution_6142",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6142_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_6149"
                ],
                "name": "Reshape_6150",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_6150_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_6142"
                ],
                "name": "Reshape_6143",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_6143_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_6150"
                ],
                "name": "Reshape_6151",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_6151_0"
                ]
            },
            {
                "inputs": [
                    "Greater_6137",
                    "Reshape_6143",
                    "Broadcast_6136"
                ],
                "name": "Select_6144",
                "op": "Select",
                "outputs": [
                    "Select_6144_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6146",
                    "Reshape_6151"
                ],
                "name": "Add_6152",
                "op": "Add",
                "outputs": [
                    "Add_6152_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6128",
            "Parameter_6129",
            "Parameter_6130",
            "Parameter_6131",
            "Parameter_6132"
        ],
        "result": [
            "Reshape_6134",
            "Select_6144",
            "Add_6152"
        ]
    }
]