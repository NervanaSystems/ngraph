[
    {
        "name": "Function_106",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5969",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5969_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5968",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5968_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5967",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5967_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5967"
                ],
                "name": "Broadcast_5970",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5970_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5968",
                    "Broadcast_5970"
                ],
                "name": "Multiply_5971",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5971_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5971",
                    "Parameter_5969"
                ],
                "name": "Add_5972",
                "op": "Add",
                "outputs": [
                    "Add_5972_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5967",
            "Parameter_5968",
            "Parameter_5969"
        ],
        "result": [
            "Add_5972"
        ]
    }
]