[
    {
        "name": "Function_74",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4475",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4475_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4474",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4474_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4473",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4473_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4473"
                ],
                "name": "Broadcast_4476",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4476_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4474",
                    "Broadcast_4476"
                ],
                "name": "Multiply_4477",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4477_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4477",
                    "Parameter_4475"
                ],
                "name": "Add_4478",
                "op": "Add",
                "outputs": [
                    "Add_4478_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4473",
            "Parameter_4474",
            "Parameter_4475"
        ],
        "result": [
            "Add_4478"
        ]
    }
]