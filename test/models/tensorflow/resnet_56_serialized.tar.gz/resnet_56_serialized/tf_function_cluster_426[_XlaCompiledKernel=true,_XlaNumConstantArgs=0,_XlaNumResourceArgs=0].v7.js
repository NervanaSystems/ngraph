[
    {
        "name": "Function_147",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7982",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7982_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7981",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7981_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7980",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7980_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7980"
                ],
                "name": "Broadcast_7983",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7983_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7981",
                    "Broadcast_7983"
                ],
                "name": "Multiply_7984",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7984_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7984",
                    "Parameter_7982"
                ],
                "name": "Add_7985",
                "op": "Add",
                "outputs": [
                    "Add_7985_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7980",
            "Parameter_7981",
            "Parameter_7982"
        ],
        "result": [
            "Add_7985"
        ]
    }
]