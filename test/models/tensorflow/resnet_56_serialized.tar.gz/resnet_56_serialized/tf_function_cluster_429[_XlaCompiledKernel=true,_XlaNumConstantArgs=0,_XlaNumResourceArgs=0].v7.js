[
    {
        "name": "Function_196",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10295",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10295_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10294",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10294_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10293",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10293_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10293"
                ],
                "name": "Broadcast_10296",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10296_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10294",
                    "Broadcast_10296"
                ],
                "name": "Multiply_10297",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10297_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10297",
                    "Parameter_10295"
                ],
                "name": "Add_10298",
                "op": "Add",
                "outputs": [
                    "Add_10298_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10293",
            "Parameter_10294",
            "Parameter_10295"
        ],
        "result": [
            "Add_10298"
        ]
    }
]