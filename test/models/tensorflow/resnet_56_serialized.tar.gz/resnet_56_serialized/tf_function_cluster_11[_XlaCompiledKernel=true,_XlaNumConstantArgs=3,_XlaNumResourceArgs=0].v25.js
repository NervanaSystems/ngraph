[
    {
        "name": "Function_211",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10995",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10995_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10994",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10994_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10993",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10993_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10992",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10992_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10991",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10991_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_10998",
                "op": "Constant",
                "outputs": [
                    "Constant_10998_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10995"
                ],
                "name": "Reshape_11010",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11010_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10993",
                    "Parameter_10994"
                ],
                "name": "Add_10996",
                "op": "Add",
                "outputs": [
                    "Add_10996_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10992"
                ],
                "name": "Reverse_11002",
                "op": "Reverse",
                "outputs": [
                    "Reverse_11002_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_10991"
                ],
                "name": "Broadcast_11008",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11008_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_10998"
                ],
                "name": "Broadcast_10999",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10999_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_10996"
                ],
                "name": "Reshape_11001",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_11001_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_10996"
                ],
                "name": "Reshape_10997",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10997_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_11002"
                ],
                "name": "Reshape_11004",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_11004_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10992",
                    "Broadcast_11008"
                ],
                "name": "Multiply_11009",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11009_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10995",
                    "Broadcast_10999"
                ],
                "name": "Greater_11000",
                "op": "Greater",
                "outputs": [
                    "Greater_11000_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_11001"
                ],
                "name": "Reshape_11011",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11011_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_11001"
                ],
                "name": "Reshape_11003",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11003_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11010",
                    "Reshape_11011"
                ],
                "name": "Convolution_11012",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11012_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11003",
                    "Reshape_11004"
                ],
                "name": "Convolution_11005",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11005_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_11012"
                ],
                "name": "Reshape_11013",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_11013_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_11005"
                ],
                "name": "Reshape_11006",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_11006_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_11013"
                ],
                "name": "Reshape_11014",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_11014_0"
                ]
            },
            {
                "inputs": [
                    "Greater_11000",
                    "Reshape_11006",
                    "Broadcast_10999"
                ],
                "name": "Select_11007",
                "op": "Select",
                "outputs": [
                    "Select_11007_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11009",
                    "Reshape_11014"
                ],
                "name": "Add_11015",
                "op": "Add",
                "outputs": [
                    "Add_11015_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10991",
            "Parameter_10992",
            "Parameter_10993",
            "Parameter_10994",
            "Parameter_10995"
        ],
        "result": [
            "Reshape_10997",
            "Select_11007",
            "Add_11015"
        ]
    }
]