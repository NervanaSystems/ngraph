[
    {
        "name": "Function_162",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8664",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8664_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8663",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8663_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8662",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8662_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8662"
                ],
                "name": "Broadcast_8665",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8665_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8663",
                    "Broadcast_8665"
                ],
                "name": "Multiply_8666",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8666_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8666",
                    "Parameter_8664"
                ],
                "name": "Add_8667",
                "op": "Add",
                "outputs": [
                    "Add_8667_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8662",
            "Parameter_8663",
            "Parameter_8664"
        ],
        "result": [
            "Add_8667"
        ]
    }
]