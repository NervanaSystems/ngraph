[
    {
        "name": "Function_187",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9833",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9833_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9832",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9832_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9831",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9831_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9831"
                ],
                "name": "Broadcast_9834",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9834_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9832",
                    "Broadcast_9834"
                ],
                "name": "Multiply_9835",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9835_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9835",
                    "Parameter_9833"
                ],
                "name": "Add_9836",
                "op": "Add",
                "outputs": [
                    "Add_9836_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9831",
            "Parameter_9832",
            "Parameter_9833"
        ],
        "result": [
            "Add_9836"
        ]
    }
]