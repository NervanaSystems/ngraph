[
    {
        "name": "Function_117",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6517",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6517_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6516",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6516_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6515",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6515_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6515"
                ],
                "name": "Broadcast_6518",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6518_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6516",
                    "Broadcast_6518"
                ],
                "name": "Multiply_6519",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6519_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6519",
                    "Parameter_6517"
                ],
                "name": "Add_6520",
                "op": "Add",
                "outputs": [
                    "Add_6520_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6515",
            "Parameter_6516",
            "Parameter_6517"
        ],
        "result": [
            "Add_6520"
        ]
    }
]