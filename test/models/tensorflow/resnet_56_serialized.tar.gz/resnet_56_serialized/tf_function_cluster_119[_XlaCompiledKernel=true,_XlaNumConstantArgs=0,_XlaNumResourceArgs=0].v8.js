[
    {
        "name": "Function_47",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2174",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2174_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2173",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2173_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2172",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2172_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2175",
                "op": "Constant",
                "outputs": [
                    "Constant_2175_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2173"
                ],
                "name": "Reshape_2179",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2179_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2175"
                ],
                "name": "Broadcast_2176",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2176_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2176",
                    "Parameter_2172"
                ],
                "name": "Maximum_2177",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2177_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2177"
                ],
                "name": "Reshape_2178",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2178_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2178",
                    "Reshape_2179"
                ],
                "name": "Convolution_2180",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2180_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2180"
                ],
                "name": "Reshape_2181",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2181_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_2181",
                    "Parameter_2174"
                ],
                "name": "Add_2182",
                "op": "Add",
                "outputs": [
                    "Add_2182_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2172",
            "Parameter_2173",
            "Parameter_2174"
        ],
        "result": [
            "Add_2182",
            "Maximum_2177",
            "Reshape_2181"
        ]
    }
]