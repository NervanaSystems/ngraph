[
    {
        "name": "Function_46",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2128",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2128_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2127",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2127_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2129",
                "op": "Constant",
                "outputs": [
                    "Constant_2129_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2128"
                ],
                "name": "Reshape_2133",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2133_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2129"
                ],
                "name": "Broadcast_2130",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2130_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2130",
                    "Parameter_2127"
                ],
                "name": "Maximum_2131",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2131_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2131"
                ],
                "name": "Reshape_2132",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2132_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2132",
                    "Reshape_2133"
                ],
                "name": "Convolution_2134",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2134_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2134"
                ],
                "name": "Reshape_2135",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2135_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2127",
            "Parameter_2128"
        ],
        "result": [
            "Reshape_2135",
            "Maximum_2131"
        ]
    }
]