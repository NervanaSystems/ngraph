[
    {
        "name": "Function_163",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8741",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8741_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8740",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8740_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8739",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8739_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8739"
                ],
                "name": "Broadcast_8742",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8742_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8740",
                    "Broadcast_8742"
                ],
                "name": "Multiply_8743",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8743_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8743",
                    "Parameter_8741"
                ],
                "name": "Add_8744",
                "op": "Add",
                "outputs": [
                    "Add_8744_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8739",
            "Parameter_8740",
            "Parameter_8741"
        ],
        "result": [
            "Add_8744"
        ]
    }
]