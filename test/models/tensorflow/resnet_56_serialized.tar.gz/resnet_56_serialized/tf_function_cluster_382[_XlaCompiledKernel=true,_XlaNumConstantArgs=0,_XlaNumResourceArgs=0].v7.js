[
    {
        "name": "Function_92",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5333",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5333_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5332",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5332_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5331",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5331_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5331"
                ],
                "name": "Broadcast_5334",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5334_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5332",
                    "Broadcast_5334"
                ],
                "name": "Multiply_5335",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5335_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5335",
                    "Parameter_5333"
                ],
                "name": "Add_5336",
                "op": "Add",
                "outputs": [
                    "Add_5336_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5331",
            "Parameter_5332",
            "Parameter_5333"
        ],
        "result": [
            "Add_5336"
        ]
    }
]