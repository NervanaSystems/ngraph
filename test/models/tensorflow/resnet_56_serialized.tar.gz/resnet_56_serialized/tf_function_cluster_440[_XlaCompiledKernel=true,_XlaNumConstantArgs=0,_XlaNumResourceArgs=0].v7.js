[
    {
        "name": "Function_197",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10372",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10372_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10371",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10371_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10370",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10370_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10370"
                ],
                "name": "Broadcast_10373",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10373_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10371",
                    "Broadcast_10373"
                ],
                "name": "Multiply_10374",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10374_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10374",
                    "Parameter_10372"
                ],
                "name": "Add_10375",
                "op": "Add",
                "outputs": [
                    "Add_10375_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10370",
            "Parameter_10371",
            "Parameter_10372"
        ],
        "result": [
            "Add_10375"
        ]
    }
]