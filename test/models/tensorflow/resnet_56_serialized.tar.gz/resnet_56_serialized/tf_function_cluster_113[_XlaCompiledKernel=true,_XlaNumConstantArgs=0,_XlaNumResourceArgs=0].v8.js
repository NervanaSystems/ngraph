[
    {
        "name": "Function_53",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2450",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2450_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2449",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2449_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2448",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2448_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2451",
                "op": "Constant",
                "outputs": [
                    "Constant_2451_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2449"
                ],
                "name": "Reshape_2455",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2455_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2451"
                ],
                "name": "Broadcast_2452",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2452_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2452",
                    "Parameter_2448"
                ],
                "name": "Maximum_2453",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2453_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2453"
                ],
                "name": "Reshape_2454",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2454_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2454",
                    "Reshape_2455"
                ],
                "name": "Convolution_2456",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2456_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2456"
                ],
                "name": "Reshape_2457",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2457_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_2457",
                    "Parameter_2450"
                ],
                "name": "Add_2458",
                "op": "Add",
                "outputs": [
                    "Add_2458_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2448",
            "Parameter_2449",
            "Parameter_2450"
        ],
        "result": [
            "Add_2458",
            "Maximum_2453",
            "Reshape_2457"
        ]
    }
]