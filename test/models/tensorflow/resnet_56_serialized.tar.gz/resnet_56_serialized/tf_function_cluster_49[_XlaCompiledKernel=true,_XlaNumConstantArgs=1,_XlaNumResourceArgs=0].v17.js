[
    {
        "name": "Function_99",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5630",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5630_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5628",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5628_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5626",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5626_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5624",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5624_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_5634",
                "op": "Constant",
                "outputs": [
                    "Constant_5634_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5630"
                ],
                "name": "Reshape_5659",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5659_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5630"
                ],
                "name": "Reshape_5675",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5675_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5628"
                ],
                "name": "Reshape_5674",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5674_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5626"
                ],
                "name": "Reverse_5654",
                "op": "Reverse",
                "outputs": [
                    "Reverse_5654_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_5624"
                ],
                "name": "Broadcast_5672",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5672_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_5634"
                ],
                "name": "Broadcast_5643",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5643_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5674",
                    "Reshape_5675"
                ],
                "name": "Convolution_5676",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5676_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_5654"
                ],
                "name": "Reshape_5661",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_5661_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5626",
                    "Broadcast_5672"
                ],
                "name": "Multiply_5673",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5673_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5628",
                    "Broadcast_5643"
                ],
                "name": "Greater_5648",
                "op": "Greater",
                "outputs": [
                    "Greater_5648_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_5676"
                ],
                "name": "Reshape_5677",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_5677_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5659",
                    "Reshape_5661"
                ],
                "name": "Convolution_5664",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5664_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_5677"
                ],
                "name": "Reshape_5678",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_5678_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_5664"
                ],
                "name": "Reshape_5667",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5667_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5673",
                    "Reshape_5678"
                ],
                "name": "Add_5679",
                "op": "Add",
                "outputs": [
                    "Add_5679_0"
                ]
            },
            {
                "inputs": [
                    "Greater_5648",
                    "Reshape_5667",
                    "Broadcast_5643"
                ],
                "name": "Select_5671",
                "op": "Select",
                "outputs": [
                    "Select_5671_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5624",
            "Parameter_5626",
            "Parameter_5628",
            "Parameter_5630"
        ],
        "result": [
            "Select_5671",
            "Add_5679"
        ]
    }
]