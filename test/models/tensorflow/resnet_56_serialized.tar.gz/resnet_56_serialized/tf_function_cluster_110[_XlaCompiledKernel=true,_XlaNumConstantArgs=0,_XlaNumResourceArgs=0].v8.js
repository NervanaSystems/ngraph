[
    {
        "name": "Function_55",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2542",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2542_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2541",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2541_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2540",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2540_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2543",
                "op": "Constant",
                "outputs": [
                    "Constant_2543_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2541"
                ],
                "name": "Reshape_2547",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2547_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2543"
                ],
                "name": "Broadcast_2544",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2544_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2544",
                    "Parameter_2540"
                ],
                "name": "Maximum_2545",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2545_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2545"
                ],
                "name": "Reshape_2546",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2546_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2546",
                    "Reshape_2547"
                ],
                "name": "Convolution_2548",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2548_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2548"
                ],
                "name": "Reshape_2549",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2549_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_2549",
                    "Parameter_2542"
                ],
                "name": "Add_2550",
                "op": "Add",
                "outputs": [
                    "Add_2550_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2540",
            "Parameter_2541",
            "Parameter_2542"
        ],
        "result": [
            "Add_2550",
            "Maximum_2545",
            "Reshape_2549"
        ]
    }
]