[
    {
        "name": "Function_4",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_178",
                "op": "Parameter",
                "outputs": [
                    "Parameter_178_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_177",
                "op": "Parameter",
                "outputs": [
                    "Parameter_177_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_179",
                "op": "Constant",
                "outputs": [
                    "Constant_179_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_178"
                ],
                "name": "Reshape_183",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_183_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_179"
                ],
                "name": "Broadcast_180",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_180_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_180",
                    "Parameter_177"
                ],
                "name": "Maximum_181",
                "op": "Maximum",
                "outputs": [
                    "Maximum_181_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_181"
                ],
                "name": "Reshape_182",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_182_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_182",
                    "Reshape_183"
                ],
                "name": "Convolution_184",
                "op": "Convolution",
                "outputs": [
                    "Convolution_184_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_184"
                ],
                "name": "Reshape_185",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_185_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_177",
            "Parameter_178"
        ],
        "result": [
            "Reshape_185",
            "Maximum_181"
        ]
    }
]