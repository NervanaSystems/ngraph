[
    {
        "name": "Function_103",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5828",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5828_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5827",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5827_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5826",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5826_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5826"
                ],
                "name": "Broadcast_5829",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5829_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5827",
                    "Broadcast_5829"
                ],
                "name": "Multiply_5830",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5830_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5830",
                    "Parameter_5828"
                ],
                "name": "Add_5831",
                "op": "Add",
                "outputs": [
                    "Add_5831_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5826",
            "Parameter_5827",
            "Parameter_5828"
        ],
        "result": [
            "Add_5831"
        ]
    }
]