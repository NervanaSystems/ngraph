[
    {
        "name": "Function_89",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5188",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5188_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5187",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5187_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5186",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5186_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5186"
                ],
                "name": "Broadcast_5189",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5189_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5187",
                    "Broadcast_5189"
                ],
                "name": "Multiply_5190",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5190_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5190",
                    "Parameter_5188"
                ],
                "name": "Add_5191",
                "op": "Add",
                "outputs": [
                    "Add_5191_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5186",
            "Parameter_5187",
            "Parameter_5188"
        ],
        "result": [
            "Add_5191"
        ]
    }
]