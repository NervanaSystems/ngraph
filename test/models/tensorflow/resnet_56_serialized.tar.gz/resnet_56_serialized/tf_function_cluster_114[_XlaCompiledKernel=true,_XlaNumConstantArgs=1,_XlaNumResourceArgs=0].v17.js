[
    {
        "name": "Function_86",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5048",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5048_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5047",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5047_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5046",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5046_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5045",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5045_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_5049",
                "op": "Constant",
                "outputs": [
                    "Constant_5049_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5048"
                ],
                "name": "Reshape_5061",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5061_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5048"
                ],
                "name": "Reshape_5053",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5053_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5047"
                ],
                "name": "Reshape_5060",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5060_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5046"
                ],
                "name": "Reverse_5052",
                "op": "Reverse",
                "outputs": [
                    "Reverse_5052_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_5045"
                ],
                "name": "Broadcast_5058",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5058_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_5049"
                ],
                "name": "Broadcast_5050",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5050_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5060",
                    "Reshape_5061"
                ],
                "name": "Convolution_5062",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5062_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_5052"
                ],
                "name": "Reshape_5054",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_5054_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5046",
                    "Broadcast_5058"
                ],
                "name": "Multiply_5059",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5059_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5047",
                    "Broadcast_5050"
                ],
                "name": "Greater_5051",
                "op": "Greater",
                "outputs": [
                    "Greater_5051_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_5062"
                ],
                "name": "Reshape_5063",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_5063_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5053",
                    "Reshape_5054"
                ],
                "name": "Convolution_5055",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5055_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_5063"
                ],
                "name": "Reshape_5064",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_5064_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_5055"
                ],
                "name": "Reshape_5056",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5056_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5059",
                    "Reshape_5064"
                ],
                "name": "Add_5065",
                "op": "Add",
                "outputs": [
                    "Add_5065_0"
                ]
            },
            {
                "inputs": [
                    "Greater_5051",
                    "Reshape_5056",
                    "Broadcast_5050"
                ],
                "name": "Select_5057",
                "op": "Select",
                "outputs": [
                    "Select_5057_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5045",
            "Parameter_5046",
            "Parameter_5047",
            "Parameter_5048"
        ],
        "result": [
            "Select_5057",
            "Add_5065"
        ]
    }
]