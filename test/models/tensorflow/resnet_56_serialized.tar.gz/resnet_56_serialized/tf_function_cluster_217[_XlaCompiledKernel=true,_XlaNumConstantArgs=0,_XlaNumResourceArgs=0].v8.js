[
    {
        "name": "Function_17",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_776",
                "op": "Parameter",
                "outputs": [
                    "Parameter_776_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_775",
                "op": "Parameter",
                "outputs": [
                    "Parameter_775_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_774",
                "op": "Parameter",
                "outputs": [
                    "Parameter_774_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_777",
                "op": "Constant",
                "outputs": [
                    "Constant_777_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_775"
                ],
                "name": "Reshape_781",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_781_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_777"
                ],
                "name": "Broadcast_778",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_778_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_778",
                    "Parameter_774"
                ],
                "name": "Maximum_779",
                "op": "Maximum",
                "outputs": [
                    "Maximum_779_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_779"
                ],
                "name": "Reshape_780",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_780_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_780",
                    "Reshape_781"
                ],
                "name": "Convolution_782",
                "op": "Convolution",
                "outputs": [
                    "Convolution_782_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_782"
                ],
                "name": "Reshape_783",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_783_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_783",
                    "Parameter_776"
                ],
                "name": "Add_784",
                "op": "Add",
                "outputs": [
                    "Add_784_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_774",
            "Parameter_775",
            "Parameter_776"
        ],
        "result": [
            "Add_784",
            "Maximum_779",
            "Reshape_783"
        ]
    }
]