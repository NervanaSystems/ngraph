[
    {
        "name": "Function_144",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7806",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7806_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7805",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7805_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7804",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7804_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7804"
                ],
                "name": "Broadcast_7807",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7807_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7805",
                    "Broadcast_7807"
                ],
                "name": "Multiply_7808",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7808_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7808",
                    "Parameter_7806"
                ],
                "name": "Add_7809",
                "op": "Add",
                "outputs": [
                    "Add_7809_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7804",
            "Parameter_7805",
            "Parameter_7806"
        ],
        "result": [
            "Add_7809"
        ]
    }
]