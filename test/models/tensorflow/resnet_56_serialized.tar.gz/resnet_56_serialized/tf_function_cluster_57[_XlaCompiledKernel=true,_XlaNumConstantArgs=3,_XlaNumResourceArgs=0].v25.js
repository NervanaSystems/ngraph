[
    {
        "name": "Function_101",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5762",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5762_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5761",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5761_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5760",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5760_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5759",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5759_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5758",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5758_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_5763",
                "op": "Constant",
                "outputs": [
                    "Constant_5763_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5762"
                ],
                "name": "Reshape_5777",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5777_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5760",
                    "Parameter_5761"
                ],
                "name": "Add_5766",
                "op": "Add",
                "outputs": [
                    "Add_5766_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5759"
                ],
                "name": "Reverse_5768",
                "op": "Reverse",
                "outputs": [
                    "Reverse_5768_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_5758"
                ],
                "name": "Broadcast_5775",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5775_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_5763"
                ],
                "name": "Broadcast_5764",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5764_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_5766"
                ],
                "name": "Reshape_5774",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5774_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_5766"
                ],
                "name": "Reshape_5767",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5767_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_5768"
                ],
                "name": "Reshape_5770",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_5770_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5759",
                    "Broadcast_5775"
                ],
                "name": "Multiply_5776",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5776_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5762",
                    "Broadcast_5764"
                ],
                "name": "Greater_5765",
                "op": "Greater",
                "outputs": [
                    "Greater_5765_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_5767"
                ],
                "name": "Reshape_5769",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5769_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_5767"
                ],
                "name": "Reshape_5778",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5778_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5769",
                    "Reshape_5770"
                ],
                "name": "Convolution_5771",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5771_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5777",
                    "Reshape_5778"
                ],
                "name": "Convolution_5779",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5779_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_5771"
                ],
                "name": "Reshape_5772",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5772_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_5779"
                ],
                "name": "Reshape_5780",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_5780_0"
                ]
            },
            {
                "inputs": [
                    "Greater_5765",
                    "Reshape_5772",
                    "Broadcast_5764"
                ],
                "name": "Select_5773",
                "op": "Select",
                "outputs": [
                    "Select_5773_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_5780"
                ],
                "name": "Reshape_5781",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_5781_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5776",
                    "Reshape_5781"
                ],
                "name": "Add_5782",
                "op": "Add",
                "outputs": [
                    "Add_5782_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5758",
            "Parameter_5759",
            "Parameter_5760",
            "Parameter_5761",
            "Parameter_5762"
        ],
        "result": [
            "Select_5773",
            "Reshape_5774",
            "Add_5782"
        ]
    }
]