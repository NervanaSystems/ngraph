[
    {
        "name": "Function_212",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11089",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11089_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11088",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11088_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11087",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11087_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_11087"
                ],
                "name": "Broadcast_11090",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11090_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_11088",
                    "Broadcast_11090"
                ],
                "name": "Multiply_11091",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11091_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11091",
                    "Parameter_11089"
                ],
                "name": "Add_11092",
                "op": "Add",
                "outputs": [
                    "Add_11092_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_11087",
            "Parameter_11088",
            "Parameter_11089"
        ],
        "result": [
            "Add_11092"
        ]
    }
]