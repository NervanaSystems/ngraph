[
    {
        "name": "Function_176",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9374",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9374_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9373",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9373_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9372",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9372_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9371",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9371_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_9375",
                "op": "Constant",
                "outputs": [
                    "Constant_9375_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9374"
                ],
                "name": "Reshape_9379",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9379_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9374"
                ],
                "name": "Reshape_9387",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9387_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_9373"
                ],
                "name": "Reshape_9386",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_9386_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9372"
                ],
                "name": "Reverse_9378",
                "op": "Reverse",
                "outputs": [
                    "Reverse_9378_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_9371"
                ],
                "name": "Broadcast_9384",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9384_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_9375"
                ],
                "name": "Broadcast_9376",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9376_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9386",
                    "Reshape_9387"
                ],
                "name": "Convolution_9388",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9388_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_9378"
                ],
                "name": "Reshape_9380",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_9380_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9372",
                    "Broadcast_9384"
                ],
                "name": "Multiply_9385",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9385_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_9373",
                    "Broadcast_9376"
                ],
                "name": "Greater_9377",
                "op": "Greater",
                "outputs": [
                    "Greater_9377_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_9388"
                ],
                "name": "Reshape_9389",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_9389_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_9379",
                    "Reshape_9380"
                ],
                "name": "Convolution_9381",
                "op": "Convolution",
                "outputs": [
                    "Convolution_9381_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_9389"
                ],
                "name": "Reshape_9390",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_9390_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_9381"
                ],
                "name": "Reshape_9382",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_9382_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9385",
                    "Reshape_9390"
                ],
                "name": "Add_9391",
                "op": "Add",
                "outputs": [
                    "Add_9391_0"
                ]
            },
            {
                "inputs": [
                    "Greater_9377",
                    "Reshape_9382",
                    "Broadcast_9376"
                ],
                "name": "Select_9383",
                "op": "Select",
                "outputs": [
                    "Select_9383_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9371",
            "Parameter_9372",
            "Parameter_9373",
            "Parameter_9374"
        ],
        "result": [
            "Select_9383",
            "Add_9391"
        ]
    }
]