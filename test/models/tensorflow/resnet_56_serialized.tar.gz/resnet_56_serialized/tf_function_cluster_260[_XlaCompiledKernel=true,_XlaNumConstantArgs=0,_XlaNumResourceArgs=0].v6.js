[
    {
        "name": "Function_18",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_822",
                "op": "Parameter",
                "outputs": [
                    "Parameter_822_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_821",
                "op": "Parameter",
                "outputs": [
                    "Parameter_821_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_823",
                "op": "Constant",
                "outputs": [
                    "Constant_823_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_822"
                ],
                "name": "Reshape_827",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_827_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_823"
                ],
                "name": "Broadcast_824",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_824_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_824",
                    "Parameter_821"
                ],
                "name": "Maximum_825",
                "op": "Maximum",
                "outputs": [
                    "Maximum_825_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_825"
                ],
                "name": "Reshape_826",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_826_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_826",
                    "Reshape_827"
                ],
                "name": "Convolution_828",
                "op": "Convolution",
                "outputs": [
                    "Convolution_828_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_828"
                ],
                "name": "Reshape_829",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_829_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_821",
            "Parameter_822"
        ],
        "result": [
            "Reshape_829",
            "Maximum_825"
        ]
    }
]