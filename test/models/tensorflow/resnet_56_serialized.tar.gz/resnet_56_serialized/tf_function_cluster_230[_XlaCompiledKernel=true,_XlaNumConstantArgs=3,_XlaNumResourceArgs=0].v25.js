[
    {
        "name": "Function_143",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7782",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7782_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7781",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7781_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7780",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7780_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7779",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7779_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7778",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7778_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_7785",
                "op": "Constant",
                "outputs": [
                    "Constant_7785_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_7782"
                ],
                "name": "Reshape_7797",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7797_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7780",
                    "Parameter_7781"
                ],
                "name": "Add_7783",
                "op": "Add",
                "outputs": [
                    "Add_7783_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7779"
                ],
                "name": "Reverse_7789",
                "op": "Reverse",
                "outputs": [
                    "Reverse_7789_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_7778"
                ],
                "name": "Broadcast_7795",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7795_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_7785"
                ],
                "name": "Broadcast_7786",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7786_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_7783"
                ],
                "name": "Reshape_7784",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7784_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_7783"
                ],
                "name": "Reshape_7788",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7788_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_7789"
                ],
                "name": "Reshape_7791",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_7791_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7779",
                    "Broadcast_7795"
                ],
                "name": "Multiply_7796",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7796_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_7782",
                    "Broadcast_7786"
                ],
                "name": "Greater_7787",
                "op": "Greater",
                "outputs": [
                    "Greater_7787_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_7788"
                ],
                "name": "Reshape_7790",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7790_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_7788"
                ],
                "name": "Reshape_7798",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_7798_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7790",
                    "Reshape_7791"
                ],
                "name": "Convolution_7792",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7792_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_7797",
                    "Reshape_7798"
                ],
                "name": "Convolution_7799",
                "op": "Convolution",
                "outputs": [
                    "Convolution_7799_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_7792"
                ],
                "name": "Reshape_7793",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_7793_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_7799"
                ],
                "name": "Reshape_7800",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_7800_0"
                ]
            },
            {
                "inputs": [
                    "Greater_7787",
                    "Reshape_7793",
                    "Broadcast_7786"
                ],
                "name": "Select_7794",
                "op": "Select",
                "outputs": [
                    "Select_7794_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_7800"
                ],
                "name": "Reshape_7801",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_7801_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7796",
                    "Reshape_7801"
                ],
                "name": "Add_7802",
                "op": "Add",
                "outputs": [
                    "Add_7802_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7778",
            "Parameter_7779",
            "Parameter_7780",
            "Parameter_7781",
            "Parameter_7782"
        ],
        "result": [
            "Reshape_7784",
            "Select_7794",
            "Add_7802"
        ]
    }
]