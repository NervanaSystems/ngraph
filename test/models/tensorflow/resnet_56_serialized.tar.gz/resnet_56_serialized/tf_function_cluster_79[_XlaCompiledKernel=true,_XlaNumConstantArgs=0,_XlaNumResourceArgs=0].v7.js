[
    {
        "name": "Function_159",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8519",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8519_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8518",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8518_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8517",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8517_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_8517"
                ],
                "name": "Broadcast_8520",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8520_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_8518",
                    "Broadcast_8520"
                ],
                "name": "Multiply_8521",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8521_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8521",
                    "Parameter_8519"
                ],
                "name": "Add_8522",
                "op": "Add",
                "outputs": [
                    "Add_8522_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8517",
            "Parameter_8518",
            "Parameter_8519"
        ],
        "result": [
            "Add_8522"
        ]
    }
]