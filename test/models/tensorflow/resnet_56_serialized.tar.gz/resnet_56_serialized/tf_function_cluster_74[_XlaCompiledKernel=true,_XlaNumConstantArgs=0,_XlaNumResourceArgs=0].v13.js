[
    {
        "name": "Function_39",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1800",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1800_0"
                ],
                "shape": [
                    1,
                    1,
                    32,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1799",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1799_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1798",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1798_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1797",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1797_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1801",
                "op": "Constant",
                "outputs": [
                    "Constant_1801_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1808",
                "op": "Constant",
                "outputs": [
                    "Constant_1808_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1800"
                ],
                "name": "Reshape_1811",
                "op": "Reshape",
                "output_shape": [
                    64,
                    32,
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_1811_0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1798"
                ],
                "name": "Reshape_1805",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1805_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1801"
                ],
                "name": "Broadcast_1802",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1802_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_1799",
                    "Constant_1808"
                ],
                "name": "Pad_1809",
                "op": "Pad",
                "outputs": [
                    "Pad_1809_0"
                ],
                "padding_above": [
                    0,
                    0,
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0,
                    0,
                    0
                ],
                "padding_interior": [
                    0,
                    0,
                    0,
                    0
                ]
            },
            {
                "inputs": [
                    "Broadcast_1802",
                    "Parameter_1797"
                ],
                "name": "Maximum_1803",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1803_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Pad_1809"
                ],
                "name": "Reshape_1810",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1810_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1803"
                ],
                "name": "Reshape_1804",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_1804_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1810",
                    "Reshape_1811"
                ],
                "name": "Convolution_1812",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1812_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    2,
                    2
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1804",
                    "Reshape_1805"
                ],
                "name": "Convolution_1806",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1806_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1812"
                ],
                "name": "Reshape_1813",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_1813_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1806"
                ],
                "name": "Reshape_1807",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_1807_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_1807",
                    "Reshape_1813"
                ],
                "name": "Add_1814",
                "op": "Add",
                "outputs": [
                    "Add_1814_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1797",
            "Parameter_1798",
            "Parameter_1799",
            "Parameter_1800"
        ],
        "result": [
            "Add_1814",
            "Pad_1809",
            "Maximum_1803",
            "Reshape_1813",
            "Reshape_1807"
        ]
    }
]