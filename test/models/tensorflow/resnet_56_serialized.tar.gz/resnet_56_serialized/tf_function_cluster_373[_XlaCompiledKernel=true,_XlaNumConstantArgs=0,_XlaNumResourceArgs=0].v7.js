[
    {
        "name": "Function_107",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6046",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6046_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6045",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6045_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6044",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6044_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6044"
                ],
                "name": "Broadcast_6047",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6047_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_6045",
                    "Broadcast_6047"
                ],
                "name": "Multiply_6048",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6048_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6048",
                    "Parameter_6046"
                ],
                "name": "Add_6049",
                "op": "Add",
                "outputs": [
                    "Add_6049_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6044",
            "Parameter_6045",
            "Parameter_6046"
        ],
        "result": [
            "Add_6049"
        ]
    }
]