[
    {
        "name": "Function_21",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_965",
                "op": "Parameter",
                "outputs": [
                    "Parameter_965_0"
                ],
                "shape": [
                    1,
                    1,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_964",
                "op": "Parameter",
                "outputs": [
                    "Parameter_964_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_963",
                "op": "Parameter",
                "outputs": [
                    "Parameter_963_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_962",
                "op": "Parameter",
                "outputs": [
                    "Parameter_962_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_966",
                "op": "Constant",
                "outputs": [
                    "Constant_966_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_965"
                ],
                "name": "Reshape_974",
                "op": "Reshape",
                "output_shape": [
                    32,
                    16,
                    1,
                    1
                ],
                "outputs": [
                    "Reshape_974_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_964"
                ],
                "name": "Reshape_973",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_973_0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_963"
                ],
                "name": "Reshape_970",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_970_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_966"
                ],
                "name": "Broadcast_967",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_967_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_973",
                    "Reshape_974"
                ],
                "name": "Convolution_975",
                "op": "Convolution",
                "outputs": [
                    "Convolution_975_0"
                ],
                "padding_above": [
                    0,
                    0
                ],
                "padding_below": [
                    0,
                    0
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    2,
                    2
                ]
            },
            {
                "inputs": [
                    "Broadcast_967",
                    "Parameter_962"
                ],
                "name": "Maximum_968",
                "op": "Maximum",
                "outputs": [
                    "Maximum_968_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_975"
                ],
                "name": "Reshape_976",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_976_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_968"
                ],
                "name": "Reshape_969",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_969_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_969",
                    "Reshape_970"
                ],
                "name": "Convolution_971",
                "op": "Convolution",
                "outputs": [
                    "Convolution_971_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_971"
                ],
                "name": "Reshape_972",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_972_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_972",
                    "Reshape_976"
                ],
                "name": "Add_977",
                "op": "Add",
                "outputs": [
                    "Add_977_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_962",
            "Parameter_963",
            "Parameter_964",
            "Parameter_965"
        ],
        "result": [
            "Add_977",
            "Maximum_968",
            "Reshape_976",
            "Reshape_972"
        ]
    }
]