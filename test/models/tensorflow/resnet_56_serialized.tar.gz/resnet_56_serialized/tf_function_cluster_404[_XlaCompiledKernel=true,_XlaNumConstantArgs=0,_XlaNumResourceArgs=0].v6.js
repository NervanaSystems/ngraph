[
    {
        "name": "Function_22",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1015",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1015_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1014",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1014_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1016",
                "op": "Constant",
                "outputs": [
                    "Constant_1016_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1015"
                ],
                "name": "Reshape_1020",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1020_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1016"
                ],
                "name": "Broadcast_1017",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1017_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1017",
                    "Parameter_1014"
                ],
                "name": "Maximum_1018",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1018_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1018"
                ],
                "name": "Reshape_1019",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1019_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1019",
                    "Reshape_1020"
                ],
                "name": "Convolution_1021",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1021_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1021"
                ],
                "name": "Reshape_1022",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1022_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1014",
            "Parameter_1015"
        ],
        "result": [
            "Reshape_1022",
            "Maximum_1018"
        ]
    }
]