[
    {
        "name": "Function_70",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4239",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4239_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4238",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4238_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4237",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4237_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4236",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4236_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_4240",
                "op": "Constant",
                "outputs": [
                    "Constant_4240_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4239"
                ],
                "name": "Reshape_4252",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4252_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4239"
                ],
                "name": "Reshape_4244",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4244_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4238"
                ],
                "name": "Reshape_4251",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4251_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4237"
                ],
                "name": "Reverse_4243",
                "op": "Reverse",
                "outputs": [
                    "Reverse_4243_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_4236"
                ],
                "name": "Broadcast_4249",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4249_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_4240"
                ],
                "name": "Broadcast_4241",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4241_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4251",
                    "Reshape_4252"
                ],
                "name": "Convolution_4253",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4253_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_4243"
                ],
                "name": "Reshape_4245",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_4245_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4237",
                    "Broadcast_4249"
                ],
                "name": "Multiply_4250",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4250_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4238",
                    "Broadcast_4241"
                ],
                "name": "Greater_4242",
                "op": "Greater",
                "outputs": [
                    "Greater_4242_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_4253"
                ],
                "name": "Reshape_4254",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_4254_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4244",
                    "Reshape_4245"
                ],
                "name": "Convolution_4246",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4246_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_4254"
                ],
                "name": "Reshape_4255",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_4255_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_4246"
                ],
                "name": "Reshape_4247",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4247_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4250",
                    "Reshape_4255"
                ],
                "name": "Add_4256",
                "op": "Add",
                "outputs": [
                    "Add_4256_0"
                ]
            },
            {
                "inputs": [
                    "Greater_4242",
                    "Reshape_4247",
                    "Broadcast_4241"
                ],
                "name": "Select_4248",
                "op": "Select",
                "outputs": [
                    "Select_4248_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4236",
            "Parameter_4237",
            "Parameter_4238",
            "Parameter_4239"
        ],
        "result": [
            "Select_4248",
            "Add_4256"
        ]
    }
]