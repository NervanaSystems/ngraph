[
    {
        "name": "Function_142",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7668",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7668_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7667",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7667_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7666",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7666_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7666"
                ],
                "name": "Broadcast_7669",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7669_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7667",
                    "Broadcast_7669"
                ],
                "name": "Multiply_7670",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7670_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7670",
                    "Parameter_7668"
                ],
                "name": "Add_7671",
                "op": "Add",
                "outputs": [
                    "Add_7671_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7666",
            "Parameter_7667",
            "Parameter_7668"
        ],
        "result": [
            "Add_7671"
        ]
    }
]