[
    {
        "name": "Function_95",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5474",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5474_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5473",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5473_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5472",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5472_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5472"
                ],
                "name": "Broadcast_5475",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5475_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5473",
                    "Broadcast_5475"
                ],
                "name": "Multiply_5476",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5476_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5476",
                    "Parameter_5474"
                ],
                "name": "Add_5477",
                "op": "Add",
                "outputs": [
                    "Add_5477_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5472",
            "Parameter_5473",
            "Parameter_5474"
        ],
        "result": [
            "Add_5477"
        ]
    }
]