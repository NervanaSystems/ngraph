[
    {
        "name": "Function_87",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5104",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5104_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5103",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5103_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5102",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5102_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5102"
                ],
                "name": "Broadcast_5105",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5105_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5103",
                    "Broadcast_5105"
                ],
                "name": "Multiply_5106",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5106_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5106",
                    "Parameter_5104"
                ],
                "name": "Add_5107",
                "op": "Add",
                "outputs": [
                    "Add_5107_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5102",
            "Parameter_5103",
            "Parameter_5104"
        ],
        "result": [
            "Add_5107"
        ]
    }
]