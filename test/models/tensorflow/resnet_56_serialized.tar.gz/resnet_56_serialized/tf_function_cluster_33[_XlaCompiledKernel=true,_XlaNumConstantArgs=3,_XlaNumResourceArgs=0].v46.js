[
    {
        "name": "Function_60",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3789",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3789_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3788",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3788_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3787",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3787_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3786",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3786_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3785",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3785_0"
                ],
                "shape": [
                    64,
                    10
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3784",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3784_0"
                ],
                "shape": [
                    10
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3783",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3783_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3782",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3782_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3781",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3781_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3780",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3780_0"
                ],
                "shape": [
                    64,
                    10
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3779",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3779_0"
                ],
                "shape": [
                    10
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3778",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3778_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3777",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3777_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3776",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3776_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_3792",
                "op": "Constant",
                "outputs": [
                    "Constant_3792_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_3789"
                ],
                "name": "Reshape_3817",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_3817_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_3788"
                ],
                "name": "Reshape_3795",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_3795_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_3788"
                ],
                "name": "Reshape_3802",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_3802_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3783"
                ],
                "name": "Reverse_3796",
                "op": "Reverse",
                "outputs": [
                    "Reverse_3796_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "inputs": [
                    "Parameter_3776",
                    "Parameter_3777"
                ],
                "name": "Multiply_3790",
                "op": "Multiply",
                "outputs": [
                    "Multiply_3790_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_3792"
                ],
                "name": "Broadcast_3793",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3793_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_3795"
                ],
                "name": "Reshape_3797",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_3797_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_3795"
                ],
                "name": "Reshape_3818",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_3818_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_3796"
                ],
                "name": "Reshape_3798",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_3798_0"
                ]
            },
            {
                "input_order": [],
                "inputs": [
                    "Multiply_3790"
                ],
                "name": "Reshape_3791",
                "op": "Reshape",
                "output_shape": [],
                "outputs": [
                    "Reshape_3791_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3789",
                    "Broadcast_3793"
                ],
                "name": "Greater_3794",
                "op": "Greater",
                "outputs": [
                    "Greater_3794_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_3817",
                    "Reshape_3818"
                ],
                "name": "Convolution_3819",
                "op": "Convolution",
                "outputs": [
                    "Convolution_3819_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_3797",
                    "Reshape_3798"
                ],
                "name": "Convolution_3799",
                "op": "Convolution",
                "outputs": [
                    "Convolution_3799_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1
                ],
                "inputs": [
                    "Reshape_3791"
                ],
                "name": "Broadcast_3806",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3806_0"
                ],
                "shape": [
                    64,
                    10
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Reshape_3791"
                ],
                "name": "Broadcast_3815",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3815_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Reshape_3791"
                ],
                "name": "Broadcast_3803",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3803_0"
                ],
                "shape": [
                    10
                ]
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Reshape_3791"
                ],
                "name": "Broadcast_3812",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3812_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Reshape_3791"
                ],
                "name": "Broadcast_3809",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3809_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_3819"
                ],
                "name": "Reshape_3820",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_3820_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_3799"
                ],
                "name": "Reshape_3800",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_3800_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3780",
                    "Broadcast_3806"
                ],
                "name": "Multiply_3807",
                "op": "Multiply",
                "outputs": [
                    "Multiply_3807_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3783",
                    "Broadcast_3815"
                ],
                "name": "Multiply_3816",
                "op": "Multiply",
                "outputs": [
                    "Multiply_3816_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3779",
                    "Broadcast_3803"
                ],
                "name": "Multiply_3804",
                "op": "Multiply",
                "outputs": [
                    "Multiply_3804_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3782",
                    "Broadcast_3812"
                ],
                "name": "Multiply_3813",
                "op": "Multiply",
                "outputs": [
                    "Multiply_3813_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_3781",
                    "Broadcast_3809"
                ],
                "name": "Multiply_3810",
                "op": "Multiply",
                "outputs": [
                    "Multiply_3810_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_3820"
                ],
                "name": "Reshape_3821",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_3821_0"
                ]
            },
            {
                "inputs": [
                    "Greater_3794",
                    "Reshape_3800",
                    "Broadcast_3793"
                ],
                "name": "Select_3801",
                "op": "Select",
                "outputs": [
                    "Select_3801_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_3807",
                    "Parameter_3785"
                ],
                "name": "Add_3808",
                "op": "Add",
                "outputs": [
                    "Add_3808_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_3804",
                    "Parameter_3784"
                ],
                "name": "Add_3805",
                "op": "Add",
                "outputs": [
                    "Add_3805_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_3813",
                    "Parameter_3786"
                ],
                "name": "Add_3814",
                "op": "Add",
                "outputs": [
                    "Add_3814_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_3810",
                    "Parameter_3787"
                ],
                "name": "Add_3811",
                "op": "Add",
                "outputs": [
                    "Add_3811_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_3816",
                    "Reshape_3821"
                ],
                "name": "Add_3822",
                "op": "Add",
                "outputs": [
                    "Add_3822_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_3776",
            "Parameter_3777",
            "Parameter_3778",
            "Parameter_3779",
            "Parameter_3780",
            "Parameter_3781",
            "Parameter_3782",
            "Parameter_3783",
            "Parameter_3784",
            "Parameter_3785",
            "Parameter_3786",
            "Parameter_3787",
            "Parameter_3788",
            "Parameter_3789"
        ],
        "result": [
            "Reshape_3791",
            "Reshape_3791",
            "Select_3801",
            "Reshape_3802",
            "Add_3805",
            "Add_3808",
            "Add_3811",
            "Add_3814",
            "Add_3822"
        ]
    }
]