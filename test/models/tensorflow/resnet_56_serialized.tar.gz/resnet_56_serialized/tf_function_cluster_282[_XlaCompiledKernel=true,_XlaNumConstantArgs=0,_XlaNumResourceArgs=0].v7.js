[
    {
        "name": "Function_137",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7494",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7494_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7493",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7493_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7492",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7492_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7492"
                ],
                "name": "Broadcast_7495",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7495_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7493",
                    "Broadcast_7495"
                ],
                "name": "Multiply_7496",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7496_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7496",
                    "Parameter_7494"
                ],
                "name": "Add_7497",
                "op": "Add",
                "outputs": [
                    "Add_7497_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7492",
            "Parameter_7493",
            "Parameter_7494"
        ],
        "result": [
            "Add_7497"
        ]
    }
]