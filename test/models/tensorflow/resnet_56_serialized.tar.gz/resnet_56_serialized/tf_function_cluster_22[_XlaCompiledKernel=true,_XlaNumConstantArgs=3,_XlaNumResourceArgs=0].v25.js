[
    {
        "name": "Function_193",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10172",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10172_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10171",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10171_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10170",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10170_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10169",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10169_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10168",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10168_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_10175",
                "op": "Constant",
                "outputs": [
                    "Constant_10175_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_10172"
                ],
                "name": "Reshape_10187",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10187_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10170",
                    "Parameter_10171"
                ],
                "name": "Add_10173",
                "op": "Add",
                "outputs": [
                    "Add_10173_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10169"
                ],
                "name": "Reverse_10179",
                "op": "Reverse",
                "outputs": [
                    "Reverse_10179_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_10168"
                ],
                "name": "Broadcast_10185",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10185_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_10175"
                ],
                "name": "Broadcast_10176",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10176_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_10173"
                ],
                "name": "Reshape_10178",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10178_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_10173"
                ],
                "name": "Reshape_10174",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10174_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_10179"
                ],
                "name": "Reshape_10181",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_10181_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10169",
                    "Broadcast_10185"
                ],
                "name": "Multiply_10186",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10186_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_10172",
                    "Broadcast_10176"
                ],
                "name": "Greater_10177",
                "op": "Greater",
                "outputs": [
                    "Greater_10177_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_10178"
                ],
                "name": "Reshape_10180",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10180_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_10178"
                ],
                "name": "Reshape_10188",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_10188_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10180",
                    "Reshape_10181"
                ],
                "name": "Convolution_10182",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10182_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_10187",
                    "Reshape_10188"
                ],
                "name": "Convolution_10189",
                "op": "Convolution",
                "outputs": [
                    "Convolution_10189_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_10182"
                ],
                "name": "Reshape_10183",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_10183_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_10189"
                ],
                "name": "Reshape_10190",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_10190_0"
                ]
            },
            {
                "inputs": [
                    "Greater_10177",
                    "Reshape_10183",
                    "Broadcast_10176"
                ],
                "name": "Select_10184",
                "op": "Select",
                "outputs": [
                    "Select_10184_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_10190"
                ],
                "name": "Reshape_10191",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_10191_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10186",
                    "Reshape_10191"
                ],
                "name": "Add_10192",
                "op": "Add",
                "outputs": [
                    "Add_10192_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10168",
            "Parameter_10169",
            "Parameter_10170",
            "Parameter_10171",
            "Parameter_10172"
        ],
        "result": [
            "Reshape_10174",
            "Select_10184",
            "Add_10192"
        ]
    }
]