[
    {
        "name": "Function_23",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1061",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1061_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1060",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1060_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_1059",
                "op": "Parameter",
                "outputs": [
                    "Parameter_1059_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_1062",
                "op": "Constant",
                "outputs": [
                    "Constant_1062_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_1060"
                ],
                "name": "Reshape_1066",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_1066_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_1062"
                ],
                "name": "Broadcast_1063",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_1063_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "inputs": [
                    "Broadcast_1063",
                    "Parameter_1059"
                ],
                "name": "Maximum_1064",
                "op": "Maximum",
                "outputs": [
                    "Maximum_1064_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_1064"
                ],
                "name": "Reshape_1065",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_1065_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_1065",
                    "Reshape_1066"
                ],
                "name": "Convolution_1067",
                "op": "Convolution",
                "outputs": [
                    "Convolution_1067_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_1067"
                ],
                "name": "Reshape_1068",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_1068_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_1068",
                    "Parameter_1061"
                ],
                "name": "Add_1069",
                "op": "Add",
                "outputs": [
                    "Add_1069_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_1059",
            "Parameter_1060",
            "Parameter_1061"
        ],
        "result": [
            "Add_1069",
            "Maximum_1064",
            "Reshape_1068"
        ]
    }
]