[
    {
        "name": "Function_79",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4719",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4719_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4718",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4718_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4717",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4717_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4717"
                ],
                "name": "Broadcast_4720",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4720_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4718",
                    "Broadcast_4720"
                ],
                "name": "Multiply_4721",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4721_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4721",
                    "Parameter_4719"
                ],
                "name": "Add_4722",
                "op": "Add",
                "outputs": [
                    "Add_4722_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4717",
            "Parameter_4718",
            "Parameter_4719"
        ],
        "result": [
            "Add_4722"
        ]
    }
]