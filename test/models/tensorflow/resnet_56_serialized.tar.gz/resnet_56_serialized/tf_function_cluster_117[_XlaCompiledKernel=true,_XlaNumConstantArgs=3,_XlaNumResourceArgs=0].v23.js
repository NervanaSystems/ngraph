[
    {
        "name": "Function_113",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6353",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6353_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6352",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6352_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6351",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6351_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6350",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6350_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_6355",
                "op": "Constant",
                "outputs": [
                    "Constant_6355_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_6353"
                ],
                "name": "Reshape_6367",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6367_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_6352"
                ],
                "name": "Reshape_6358",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_6358_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_6352"
                ],
                "name": "Reshape_6354",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_6354_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6351"
                ],
                "name": "Reverse_6359",
                "op": "Reverse",
                "outputs": [
                    "Reverse_6359_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_6350"
                ],
                "name": "Broadcast_6365",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6365_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_6355"
                ],
                "name": "Broadcast_6356",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6356_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_6358"
                ],
                "name": "Reshape_6360",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6360_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_6358"
                ],
                "name": "Reshape_6368",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_6368_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_6359"
                ],
                "name": "Reshape_6361",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_6361_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6351",
                    "Broadcast_6365"
                ],
                "name": "Multiply_6366",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6366_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_6353",
                    "Broadcast_6356"
                ],
                "name": "Greater_6357",
                "op": "Greater",
                "outputs": [
                    "Greater_6357_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6367",
                    "Reshape_6368"
                ],
                "name": "Convolution_6369",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6369_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_6360",
                    "Reshape_6361"
                ],
                "name": "Convolution_6362",
                "op": "Convolution",
                "outputs": [
                    "Convolution_6362_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_6369"
                ],
                "name": "Reshape_6370",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_6370_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_6362"
                ],
                "name": "Reshape_6363",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_6363_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_6370"
                ],
                "name": "Reshape_6371",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_6371_0"
                ]
            },
            {
                "inputs": [
                    "Greater_6357",
                    "Reshape_6363",
                    "Broadcast_6356"
                ],
                "name": "Select_6364",
                "op": "Select",
                "outputs": [
                    "Select_6364_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6366",
                    "Reshape_6371"
                ],
                "name": "Add_6372",
                "op": "Add",
                "outputs": [
                    "Add_6372_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6350",
            "Parameter_6351",
            "Parameter_6352",
            "Parameter_6353"
        ],
        "result": [
            "Reshape_6354",
            "Select_6364",
            "Add_6372"
        ]
    }
]