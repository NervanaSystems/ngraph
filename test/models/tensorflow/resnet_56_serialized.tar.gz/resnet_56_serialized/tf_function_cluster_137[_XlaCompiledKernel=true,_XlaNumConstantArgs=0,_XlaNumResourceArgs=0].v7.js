[
    {
        "name": "Function_68",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4189",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4189_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4188",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4188_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4187",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4187_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_4187"
                ],
                "name": "Broadcast_4190",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4190_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_4188",
                    "Broadcast_4190"
                ],
                "name": "Multiply_4191",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4191_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4191",
                    "Parameter_4189"
                ],
                "name": "Add_4192",
                "op": "Add",
                "outputs": [
                    "Add_4192_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4187",
            "Parameter_4188",
            "Parameter_4189"
        ],
        "result": [
            "Add_4192"
        ]
    }
]