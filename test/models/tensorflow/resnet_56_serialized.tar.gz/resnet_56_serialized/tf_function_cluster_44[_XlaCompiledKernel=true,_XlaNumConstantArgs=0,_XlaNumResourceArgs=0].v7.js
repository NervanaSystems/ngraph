[
    {
        "name": "Function_191",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10086",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10086_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10085",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10085_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10084",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10084_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10084"
                ],
                "name": "Broadcast_10087",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10087_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10085",
                    "Broadcast_10087"
                ],
                "name": "Multiply_10088",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10088_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10088",
                    "Parameter_10086"
                ],
                "name": "Add_10089",
                "op": "Add",
                "outputs": [
                    "Add_10089_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10084",
            "Parameter_10085",
            "Parameter_10086"
        ],
        "result": [
            "Add_10089"
        ]
    }
]