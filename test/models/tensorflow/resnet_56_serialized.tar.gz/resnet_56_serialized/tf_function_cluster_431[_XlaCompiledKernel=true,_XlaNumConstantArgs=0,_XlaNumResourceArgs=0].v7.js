[
    {
        "name": "Function_194",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10231",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10231_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10230",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10230_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_10229",
                "op": "Parameter",
                "outputs": [
                    "Parameter_10229_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_10229"
                ],
                "name": "Broadcast_10232",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_10232_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_10230",
                    "Broadcast_10232"
                ],
                "name": "Multiply_10233",
                "op": "Multiply",
                "outputs": [
                    "Multiply_10233_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_10233",
                    "Parameter_10231"
                ],
                "name": "Add_10234",
                "op": "Add",
                "outputs": [
                    "Add_10234_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_10229",
            "Parameter_10230",
            "Parameter_10231"
        ],
        "result": [
            "Add_10234"
        ]
    }
]