[
    {
        "name": "Function_174",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9235",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9235_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9234",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9234_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_9233",
                "op": "Parameter",
                "outputs": [
                    "Parameter_9233_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_9233"
                ],
                "name": "Broadcast_9236",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_9236_0"
                ],
                "shape": [
                    16
                ]
            },
            {
                "inputs": [
                    "Parameter_9234",
                    "Broadcast_9236"
                ],
                "name": "Multiply_9237",
                "op": "Multiply",
                "outputs": [
                    "Multiply_9237_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_9237",
                    "Parameter_9235"
                ],
                "name": "Add_9238",
                "op": "Add",
                "outputs": [
                    "Add_9238_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_9233",
            "Parameter_9234",
            "Parameter_9235"
        ],
        "result": [
            "Add_9238"
        ]
    }
]