[
    {
        "name": "Function_90",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5197",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5197_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5196",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5196_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5195",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5195_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5194",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5194_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5193",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5193_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_5200",
                "op": "Constant",
                "outputs": [
                    "Constant_5200_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_5197"
                ],
                "name": "Reshape_5212",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5212_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5195",
                    "Parameter_5196"
                ],
                "name": "Add_5198",
                "op": "Add",
                "outputs": [
                    "Add_5198_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5194"
                ],
                "name": "Reverse_5204",
                "op": "Reverse",
                "outputs": [
                    "Reverse_5204_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_5193"
                ],
                "name": "Broadcast_5210",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5210_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_5200"
                ],
                "name": "Broadcast_5201",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5201_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_5198"
                ],
                "name": "Reshape_5203",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5203_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_5198"
                ],
                "name": "Reshape_5199",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5199_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_5204"
                ],
                "name": "Reshape_5206",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_5206_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5194",
                    "Broadcast_5210"
                ],
                "name": "Multiply_5211",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5211_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_5197",
                    "Broadcast_5201"
                ],
                "name": "Greater_5202",
                "op": "Greater",
                "outputs": [
                    "Greater_5202_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_5203"
                ],
                "name": "Reshape_5205",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5205_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_5203"
                ],
                "name": "Reshape_5213",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_5213_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5205",
                    "Reshape_5206"
                ],
                "name": "Convolution_5207",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5207_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_5212",
                    "Reshape_5213"
                ],
                "name": "Convolution_5214",
                "op": "Convolution",
                "outputs": [
                    "Convolution_5214_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_5207"
                ],
                "name": "Reshape_5208",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_5208_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_5214"
                ],
                "name": "Reshape_5215",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_5215_0"
                ]
            },
            {
                "inputs": [
                    "Greater_5202",
                    "Reshape_5208",
                    "Broadcast_5201"
                ],
                "name": "Select_5209",
                "op": "Select",
                "outputs": [
                    "Select_5209_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_5215"
                ],
                "name": "Reshape_5216",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_5216_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5211",
                    "Reshape_5216"
                ],
                "name": "Add_5217",
                "op": "Add",
                "outputs": [
                    "Add_5217_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5193",
            "Parameter_5194",
            "Parameter_5195",
            "Parameter_5196",
            "Parameter_5197"
        ],
        "result": [
            "Reshape_5199",
            "Select_5209",
            "Add_5217"
        ]
    }
]