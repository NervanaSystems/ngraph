[
    {
        "name": "Function_48",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2220",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2220_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_2219",
                "op": "Parameter",
                "outputs": [
                    "Parameter_2219_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_2221",
                "op": "Constant",
                "outputs": [
                    "Constant_2221_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_2220"
                ],
                "name": "Reshape_2225",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_2225_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_2221"
                ],
                "name": "Broadcast_2222",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_2222_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "inputs": [
                    "Broadcast_2222",
                    "Parameter_2219"
                ],
                "name": "Maximum_2223",
                "op": "Maximum",
                "outputs": [
                    "Maximum_2223_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_2223"
                ],
                "name": "Reshape_2224",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_2224_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_2224",
                    "Reshape_2225"
                ],
                "name": "Convolution_2226",
                "op": "Convolution",
                "outputs": [
                    "Convolution_2226_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_2226"
                ],
                "name": "Reshape_2227",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_2227_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_2219",
            "Parameter_2220"
        ],
        "result": [
            "Reshape_2227",
            "Maximum_2223"
        ]
    }
]