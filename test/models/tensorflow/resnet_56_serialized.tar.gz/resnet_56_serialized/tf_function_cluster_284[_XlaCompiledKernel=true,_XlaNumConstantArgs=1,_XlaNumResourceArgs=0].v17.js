[
    {
        "name": "Function_154",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8261",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8261_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8260",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8260_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8259",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8259_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_8258",
                "op": "Parameter",
                "outputs": [
                    "Parameter_8258_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_8262",
                "op": "Constant",
                "outputs": [
                    "Constant_8262_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8261"
                ],
                "name": "Reshape_8266",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8266_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8261"
                ],
                "name": "Reshape_8274",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8274_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_8260"
                ],
                "name": "Reshape_8273",
                "op": "Reshape",
                "output_shape": [
                    32,
                    2,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_8273_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8259"
                ],
                "name": "Reverse_8265",
                "op": "Reverse",
                "outputs": [
                    "Reverse_8265_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_8258"
                ],
                "name": "Broadcast_8271",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8271_0"
                ],
                "shape": [
                    3,
                    3,
                    32,
                    32
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_8262"
                ],
                "name": "Broadcast_8263",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_8263_0"
                ],
                "shape": [
                    2,
                    16,
                    16,
                    32
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8273",
                    "Reshape_8274"
                ],
                "name": "Convolution_8275",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8275_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_8265"
                ],
                "name": "Reshape_8267",
                "op": "Reshape",
                "output_shape": [
                    32,
                    32,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_8267_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8259",
                    "Broadcast_8271"
                ],
                "name": "Multiply_8272",
                "op": "Multiply",
                "outputs": [
                    "Multiply_8272_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_8260",
                    "Broadcast_8263"
                ],
                "name": "Greater_8264",
                "op": "Greater",
                "outputs": [
                    "Greater_8264_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_8275"
                ],
                "name": "Reshape_8276",
                "op": "Reshape",
                "output_shape": [
                    32,
                    3,
                    3,
                    32
                ],
                "outputs": [
                    "Reshape_8276_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_8266",
                    "Reshape_8267"
                ],
                "name": "Convolution_8268",
                "op": "Convolution",
                "outputs": [
                    "Convolution_8268_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_8276"
                ],
                "name": "Reshape_8277",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_8277_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_8268"
                ],
                "name": "Reshape_8269",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    16,
                    32
                ],
                "outputs": [
                    "Reshape_8269_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_8272",
                    "Reshape_8277"
                ],
                "name": "Add_8278",
                "op": "Add",
                "outputs": [
                    "Add_8278_0"
                ]
            },
            {
                "inputs": [
                    "Greater_8264",
                    "Reshape_8269",
                    "Broadcast_8263"
                ],
                "name": "Select_8270",
                "op": "Select",
                "outputs": [
                    "Select_8270_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_8258",
            "Parameter_8259",
            "Parameter_8260",
            "Parameter_8261"
        ],
        "result": [
            "Select_8270",
            "Add_8278"
        ]
    }
]