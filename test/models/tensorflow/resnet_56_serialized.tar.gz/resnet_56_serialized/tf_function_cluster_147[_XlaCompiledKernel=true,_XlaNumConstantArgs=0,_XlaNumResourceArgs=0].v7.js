[
    {
        "name": "Function_62",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3903",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3903_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3902",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3902_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_3901",
                "op": "Parameter",
                "outputs": [
                    "Parameter_3901_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_3901"
                ],
                "name": "Broadcast_3904",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_3904_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_3902",
                    "Broadcast_3904"
                ],
                "name": "Multiply_3905",
                "op": "Multiply",
                "outputs": [
                    "Multiply_3905_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_3905",
                    "Parameter_3903"
                ],
                "name": "Add_3906",
                "op": "Add",
                "outputs": [
                    "Add_3906_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_3901",
            "Parameter_3902",
            "Parameter_3903"
        ],
        "result": [
            "Add_3906"
        ]
    }
]