[
    {
        "name": "Function_215",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11232",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11232_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11231",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11231_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11230",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11230_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11229",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11229_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_11228",
                "op": "Parameter",
                "outputs": [
                    "Parameter_11228_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_11235",
                "op": "Constant",
                "outputs": [
                    "Constant_11235_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_11232"
                ],
                "name": "Reshape_11247",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11247_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_11230",
                    "Parameter_11231"
                ],
                "name": "Add_11233",
                "op": "Add",
                "outputs": [
                    "Add_11233_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_11229"
                ],
                "name": "Reverse_11239",
                "op": "Reverse",
                "outputs": [
                    "Reverse_11239_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_11228"
                ],
                "name": "Broadcast_11245",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11245_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_11235"
                ],
                "name": "Broadcast_11236",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_11236_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_11233"
                ],
                "name": "Reshape_11238",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_11238_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_11233"
                ],
                "name": "Reshape_11234",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_11234_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_11239"
                ],
                "name": "Reshape_11241",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_11241_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_11229",
                    "Broadcast_11245"
                ],
                "name": "Multiply_11246",
                "op": "Multiply",
                "outputs": [
                    "Multiply_11246_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_11232",
                    "Broadcast_11236"
                ],
                "name": "Greater_11237",
                "op": "Greater",
                "outputs": [
                    "Greater_11237_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_11238"
                ],
                "name": "Reshape_11240",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11240_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_11238"
                ],
                "name": "Reshape_11248",
                "op": "Reshape",
                "output_shape": [
                    16,
                    2,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_11248_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11240",
                    "Reshape_11241"
                ],
                "name": "Convolution_11242",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11242_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_11247",
                    "Reshape_11248"
                ],
                "name": "Convolution_11249",
                "op": "Convolution",
                "outputs": [
                    "Convolution_11249_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_11242"
                ],
                "name": "Reshape_11243",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_11243_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_11249"
                ],
                "name": "Reshape_11250",
                "op": "Reshape",
                "output_shape": [
                    16,
                    3,
                    3,
                    16
                ],
                "outputs": [
                    "Reshape_11250_0"
                ]
            },
            {
                "inputs": [
                    "Greater_11237",
                    "Reshape_11243",
                    "Broadcast_11236"
                ],
                "name": "Select_11244",
                "op": "Select",
                "outputs": [
                    "Select_11244_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_11250"
                ],
                "name": "Reshape_11251",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    16,
                    16
                ],
                "outputs": [
                    "Reshape_11251_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_11246",
                    "Reshape_11251"
                ],
                "name": "Add_11252",
                "op": "Add",
                "outputs": [
                    "Add_11252_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_11228",
            "Parameter_11229",
            "Parameter_11230",
            "Parameter_11231",
            "Parameter_11232"
        ],
        "result": [
            "Reshape_11234",
            "Select_11244",
            "Add_11252"
        ]
    }
]