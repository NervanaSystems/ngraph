[
    {
        "name": "Function_73",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4416",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4416_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4415",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4415_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4414",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4414_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4413",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4413_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_4412",
                "op": "Parameter",
                "outputs": [
                    "Parameter_4412_0"
                ],
                "shape": []
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_4417",
                "op": "Constant",
                "outputs": [
                    "Constant_4417_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Parameter_4416"
                ],
                "name": "Reshape_4431",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4431_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4414",
                    "Parameter_4415"
                ],
                "name": "Add_4420",
                "op": "Add",
                "outputs": [
                    "Add_4420_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4413"
                ],
                "name": "Reverse_4422",
                "op": "Reverse",
                "outputs": [
                    "Reverse_4422_0"
                ],
                "reversed_axes": [
                    0,
                    1
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Parameter_4412"
                ],
                "name": "Broadcast_4429",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4429_0"
                ],
                "shape": [
                    3,
                    3,
                    64,
                    64
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_4417"
                ],
                "name": "Broadcast_4418",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_4418_0"
                ],
                "shape": [
                    2,
                    8,
                    8,
                    64
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_4420"
                ],
                "name": "Reshape_4421",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4421_0"
                ]
            },
            {
                "input_order": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Add_4420"
                ],
                "name": "Reshape_4428",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4428_0"
                ]
            },
            {
                "input_order": [
                    2,
                    3,
                    0,
                    1
                ],
                "inputs": [
                    "Reverse_4422"
                ],
                "name": "Reshape_4424",
                "op": "Reshape",
                "output_shape": [
                    64,
                    64,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_4424_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4413",
                    "Broadcast_4429"
                ],
                "name": "Multiply_4430",
                "op": "Multiply",
                "outputs": [
                    "Multiply_4430_0"
                ]
            },
            {
                "inputs": [
                    "Parameter_4416",
                    "Broadcast_4418"
                ],
                "name": "Greater_4419",
                "op": "Greater",
                "outputs": [
                    "Greater_4419_0"
                ]
            },
            {
                "input_order": [
                    3,
                    0,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_4421"
                ],
                "name": "Reshape_4432",
                "op": "Reshape",
                "output_shape": [
                    64,
                    2,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4432_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Reshape_4421"
                ],
                "name": "Reshape_4423",
                "op": "Reshape",
                "output_shape": [
                    2,
                    64,
                    8,
                    8
                ],
                "outputs": [
                    "Reshape_4423_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4431",
                    "Reshape_4432"
                ],
                "name": "Convolution_4433",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4433_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_4423",
                    "Reshape_4424"
                ],
                "name": "Convolution_4425",
                "op": "Convolution",
                "outputs": [
                    "Convolution_4425_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Convolution_4433"
                ],
                "name": "Reshape_4434",
                "op": "Reshape",
                "output_shape": [
                    64,
                    3,
                    3,
                    64
                ],
                "outputs": [
                    "Reshape_4434_0"
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_4425"
                ],
                "name": "Reshape_4426",
                "op": "Reshape",
                "output_shape": [
                    2,
                    8,
                    8,
                    64
                ],
                "outputs": [
                    "Reshape_4426_0"
                ]
            },
            {
                "input_order": [
                    1,
                    2,
                    3,
                    0
                ],
                "inputs": [
                    "Reshape_4434"
                ],
                "name": "Reshape_4435",
                "op": "Reshape",
                "output_shape": [
                    3,
                    3,
                    64,
                    64
                ],
                "outputs": [
                    "Reshape_4435_0"
                ]
            },
            {
                "inputs": [
                    "Greater_4419",
                    "Reshape_4426",
                    "Broadcast_4418"
                ],
                "name": "Select_4427",
                "op": "Select",
                "outputs": [
                    "Select_4427_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_4430",
                    "Reshape_4435"
                ],
                "name": "Add_4436",
                "op": "Add",
                "outputs": [
                    "Add_4436_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_4412",
            "Parameter_4413",
            "Parameter_4414",
            "Parameter_4415",
            "Parameter_4416"
        ],
        "result": [
            "Select_4427",
            "Reshape_4428",
            "Add_4436"
        ]
    }
]