[
    {
        "name": "Function_130",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7131",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7131_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7130",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7130_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_7129",
                "op": "Parameter",
                "outputs": [
                    "Parameter_7129_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_7129"
                ],
                "name": "Broadcast_7132",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_7132_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_7130",
                    "Broadcast_7132"
                ],
                "name": "Multiply_7133",
                "op": "Multiply",
                "outputs": [
                    "Multiply_7133_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_7133",
                    "Parameter_7131"
                ],
                "name": "Add_7134",
                "op": "Add",
                "outputs": [
                    "Add_7134_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_7129",
            "Parameter_7130",
            "Parameter_7131"
        ],
        "result": [
            "Add_7134"
        ]
    }
]