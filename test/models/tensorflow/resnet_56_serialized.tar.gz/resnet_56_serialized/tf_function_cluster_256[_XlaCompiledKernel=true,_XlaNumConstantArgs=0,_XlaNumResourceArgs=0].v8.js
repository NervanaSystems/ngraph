[
    {
        "name": "Function_13",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_592",
                "op": "Parameter",
                "outputs": [
                    "Parameter_592_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_591",
                "op": "Parameter",
                "outputs": [
                    "Parameter_591_0"
                ],
                "shape": [
                    3,
                    3,
                    16,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_590",
                "op": "Parameter",
                "outputs": [
                    "Parameter_590_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_593",
                "op": "Constant",
                "outputs": [
                    "Constant_593_0"
                ],
                "shape": [],
                "value": [
                    "0"
                ]
            },
            {
                "input_order": [
                    3,
                    2,
                    0,
                    1
                ],
                "inputs": [
                    "Parameter_591"
                ],
                "name": "Reshape_597",
                "op": "Reshape",
                "output_shape": [
                    16,
                    16,
                    3,
                    3
                ],
                "outputs": [
                    "Reshape_597_0"
                ]
            },
            {
                "axes": [
                    0,
                    1,
                    2,
                    3
                ],
                "inputs": [
                    "Constant_593"
                ],
                "name": "Broadcast_594",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_594_0"
                ],
                "shape": [
                    2,
                    32,
                    32,
                    16
                ]
            },
            {
                "inputs": [
                    "Broadcast_594",
                    "Parameter_590"
                ],
                "name": "Maximum_595",
                "op": "Maximum",
                "outputs": [
                    "Maximum_595_0"
                ]
            },
            {
                "input_order": [
                    0,
                    3,
                    1,
                    2
                ],
                "inputs": [
                    "Maximum_595"
                ],
                "name": "Reshape_596",
                "op": "Reshape",
                "output_shape": [
                    2,
                    16,
                    32,
                    32
                ],
                "outputs": [
                    "Reshape_596_0"
                ]
            },
            {
                "data_dilation_strides": [
                    1,
                    1
                ],
                "inputs": [
                    "Reshape_596",
                    "Reshape_597"
                ],
                "name": "Convolution_598",
                "op": "Convolution",
                "outputs": [
                    "Convolution_598_0"
                ],
                "padding_above": [
                    1,
                    1
                ],
                "padding_below": [
                    1,
                    1
                ],
                "window_dilation_strides": [
                    1,
                    1
                ],
                "window_movement_strides": [
                    1,
                    1
                ]
            },
            {
                "input_order": [
                    0,
                    2,
                    3,
                    1
                ],
                "inputs": [
                    "Convolution_598"
                ],
                "name": "Reshape_599",
                "op": "Reshape",
                "output_shape": [
                    2,
                    32,
                    32,
                    16
                ],
                "outputs": [
                    "Reshape_599_0"
                ]
            },
            {
                "inputs": [
                    "Reshape_599",
                    "Parameter_592"
                ],
                "name": "Add_600",
                "op": "Add",
                "outputs": [
                    "Add_600_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_590",
            "Parameter_591",
            "Parameter_592"
        ],
        "result": [
            "Add_600",
            "Maximum_595",
            "Reshape_599"
        ]
    }
]