[
    {
        "name": "Function_102",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5786",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5786_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5785",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5785_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_5784",
                "op": "Parameter",
                "outputs": [
                    "Parameter_5784_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_5784"
                ],
                "name": "Broadcast_5787",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_5787_0"
                ],
                "shape": [
                    64
                ]
            },
            {
                "inputs": [
                    "Parameter_5785",
                    "Broadcast_5787"
                ],
                "name": "Multiply_5788",
                "op": "Multiply",
                "outputs": [
                    "Multiply_5788_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_5788",
                    "Parameter_5786"
                ],
                "name": "Add_5789",
                "op": "Add",
                "outputs": [
                    "Add_5789_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_5784",
            "Parameter_5785",
            "Parameter_5786"
        ],
        "result": [
            "Add_5789"
        ]
    }
]