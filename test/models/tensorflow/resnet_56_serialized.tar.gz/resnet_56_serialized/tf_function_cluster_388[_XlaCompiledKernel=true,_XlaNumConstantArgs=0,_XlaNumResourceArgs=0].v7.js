[
    {
        "name": "Function_123",
        "ops": [
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6803",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6803_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6802",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6802_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Parameter_6801",
                "op": "Parameter",
                "outputs": [
                    "Parameter_6801_0"
                ],
                "shape": []
            },
            {
                "axes": [
                    0
                ],
                "inputs": [
                    "Parameter_6801"
                ],
                "name": "Broadcast_6804",
                "op": "Broadcast",
                "outputs": [
                    "Broadcast_6804_0"
                ],
                "shape": [
                    32
                ]
            },
            {
                "inputs": [
                    "Parameter_6802",
                    "Broadcast_6804"
                ],
                "name": "Multiply_6805",
                "op": "Multiply",
                "outputs": [
                    "Multiply_6805_0"
                ]
            },
            {
                "inputs": [
                    "Multiply_6805",
                    "Parameter_6803"
                ],
                "name": "Add_6806",
                "op": "Add",
                "outputs": [
                    "Add_6806_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_6801",
            "Parameter_6802",
            "Parameter_6803"
        ],
        "result": [
            "Add_6806"
        ]
    }
]