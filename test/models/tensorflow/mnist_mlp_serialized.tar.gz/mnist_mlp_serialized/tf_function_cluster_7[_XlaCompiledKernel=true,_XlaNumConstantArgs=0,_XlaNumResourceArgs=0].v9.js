[
    {
        "name": "Function_2",
        "ops": [
            {
                "element_type": "char",
                "inputs": [],
                "name": "Parameter_139",
                "op": "Parameter",
                "outputs": [
                    "Parameter_139_0"
                ],
                "shape": [
                    10000
                ]
            },
            {
                "element_type": "float",
                "inputs": [],
                "name": "Constant_142",
                "op": "Constant",
                "outputs": [
                    "Constant_142_0"
                ],
                "shape": [],
                "value": [
                    "10000"
                ]
            },
            {
                "inputs": [
                    "Parameter_139"
                ],
                "name": "Convert_140",
                "op": "Convert",
                "outputs": [
                    "Convert_140_0"
                ],
                "target_type": "float"
            },
            {
                "inputs": [
                    "Convert_140"
                ],
                "name": "Sum_141",
                "op": "Sum",
                "outputs": [
                    "Sum_141_0"
                ],
                "reduction_axes": [
                    0
                ]
            },
            {
                "inputs": [
                    "Sum_141",
                    "Constant_142"
                ],
                "name": "Divide_143",
                "op": "Divide",
                "outputs": [
                    "Divide_143_0"
                ]
            }
        ],
        "parameters": [
            "Parameter_139"
        ],
        "result": [
            "Divide_143"
        ]
    }
]