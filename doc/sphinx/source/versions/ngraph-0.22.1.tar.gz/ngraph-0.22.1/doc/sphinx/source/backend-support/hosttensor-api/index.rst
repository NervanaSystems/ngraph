.. backend-support/hosttensor-api/index.rst:


HostTensor
==========

.. doxygenclass:: ngraph::runtime::HostTensor
   :project: ngraph
   :members:
