format_release_notes.rst


Release Notes
#############


This is the `Release Notes` template for latest nGraph Compiler stack 
release versioning.

We are pleased to announce the release of version |version|.


What's new?
-----------

Additional functionality included with this release:




What's updated?
---------------

The following sections provide detailed lists of major updates/removals 
by component:


Core
~~~~



Frameworks
~~~~~~~~~~



Backends
~~~~~~~~



Visualization Tools
~~~~~~~~~~~~~~~~~~~



Other
~~~~~


