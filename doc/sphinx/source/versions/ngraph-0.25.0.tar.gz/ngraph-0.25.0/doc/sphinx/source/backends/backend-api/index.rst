.. backends/backend-api/index.rst:


Backend
=======

.. doxygenclass:: ngraph::runtime::Backend
   :project: ngraph
   :members:
