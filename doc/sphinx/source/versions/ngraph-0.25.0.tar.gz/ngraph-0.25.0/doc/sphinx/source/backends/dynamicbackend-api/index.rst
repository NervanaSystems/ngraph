.. backends/hosttensor-api/index.rst:


DynamicBackend
==============

.. doxygenclass:: ngraph::runtime::dynamic::DynamicBackend
   :project: ngraph
   :members:
