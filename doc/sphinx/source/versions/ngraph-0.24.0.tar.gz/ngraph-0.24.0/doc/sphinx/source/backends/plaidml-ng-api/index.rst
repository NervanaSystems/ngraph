.. backends/plaidml-ng-api/index.rst:


PlaidML from nGraph
===================

.. doxygenclass:: ngraph::runtime::plaidml::PlaidML_Backend
   :project: ngraph
   :members:
   